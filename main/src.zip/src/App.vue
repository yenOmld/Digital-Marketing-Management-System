<template>
  <router-view />
</template>

<script setup>
// 无需引入页面组件，路由自动渲染
</script>
