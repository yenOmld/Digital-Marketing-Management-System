<template>
  <div class="login-container">
    <!-- 背景装饰 -->
    <div class="background-decoration">
      <div class="grid-pattern"></div>
    </div>
    
    <!-- 登录卡片 -->
    <div class="login-card">
      <!-- 标题区域 -->
      <div class="login-header">
        <h1 class="login-title">欢迎登录</h1>
        <p class="login-subtitle">登录您的账户</p>
      </div>

      <!-- 表单区域 -->
      <form @submit.prevent="handleLogin" class="login-form">
        <!-- 用户名/邮箱输入框 -->
        <div class="input-group">
          <div class="input-wrapper">
            <div class="input-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                <polyline points="22,6 12,13 2,6"/>
              </svg>
            </div>
            <input
              v-model="formData.email"
              type="email"
              placeholder="请输入邮箱地址"
              class="form-input"
              :class="{ 'error': errors.email }"
              @focus="clearError"
            />
          </div>
          <span v-if="errors.email" class="error-text">{{ errors.email }}</span>
        </div>

        <!-- 密码输入框 -->
        <div class="input-group">
          <div class="input-wrapper">
            <div class="input-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <circle cx="12" cy="16" r="1"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
            </div>
            <input
              v-model="formData.password"
              :type="showPassword ? 'text' : 'password'"
              placeholder="请输入密码"
              class="form-input"
              :class="{ 'error': errors.password }"
              @focus="clearError"
            />
            <button
              type="button"
              class="password-toggle"
              @click="togglePassword"
            >
              <svg v-if="showPassword" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
              <svg v-else width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                <line x1="1" y1="1" x2="23" y2="23"/>
              </svg>
            </button>
          </div>
          <span v-if="errors.password" class="error-text">{{ errors.password }}</span>
        </div>

        <!-- 记住我和忘记密码 -->
        <div class="form-options">
          <label class="remember-me">
            <input
              v-model="formData.rememberMe"
              type="checkbox"
              class="checkbox-input"
            />
            <span class="checkbox-custom"></span>
            <span class="checkbox-text">记住我</span>
          </label>
          <a href="#" class="forgot-password" @click.prevent="handleForgotPassword">
            忘记密码？
          </a>
        </div>

        <!-- 登录按钮 -->
        <button
          type="submit"
          class="login-button"
          :disabled="isLoading"
          :class="{ 'loading': isLoading }"
        >
          <span v-if="!isLoading">登录</span>
          <div v-else class="loading-spinner">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 12a9 9 0 11-6.219-8.56"/>
            </svg>
          </div>
        </button>
      </form>
    </div>

    <!-- 底部信息 -->
    <div class="footer-info">
      <div class="footer-content">
        <div class="company-logo">
          <svg t="1754552916466" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="6337" width="48" height="48"><path fill="currentColor" d="M917 737.6c-15.8-22.8-35.8-40.4-60.2-52.4 22.8-23.4 36.8-55.4 36.8-90.6 0-71.8-58.4-130.4-130.4-130.4s-130.4 58.4-130.4 130.4c0 35 14 66.8 36.6 90.4-24.8 12-45 29.6-60.8 52.8-26.2 38.4-39 90.6-39 159.6 0 16.6 13.4 30 30 30s30-13.4 30-30c0-55.8 9.6-98 28.6-125.8 21-31 55.4-46 105.2-46 57.4 0 133.6 17.8 133.6 171.8 0 16.6 13.4 30 30 30s30-13.4 30-30c0-67.6-13.4-121.4-40-159.8z m-153.6-213.4c38.8 0 70.4 31.6 70.4 70.4s-31.6 70.4-70.4 70.4-70.4-31.6-70.4-70.4 31.6-70.4 70.4-70.4zM521.8 857.6c0 16.6-13.4 30-30 30H193.6c-65 0-117.8-52.8-117.8-117.8v-578C75.8 126.8 128.6 74 193.6 74h558.2c65 0 117.8 52.8 117.8 117.8V400c0 16.6-13.4 30-30 30s-30-13.4-30-30V191.6c0-31.8-26-57.8-57.8-57.8H193.6c-31.8 0-57.8 26-57.8 57.8v578c0 31.8 26 57.8 57.8 57.8h298.2c16.6 0.2 30 13.6 30 30.2z m180-566.2l-174 105c-7.4 4.6-16.6 5.6-24.8 2.8l-134-44.2-116.6 75.4c-5 3.2-10.6 4.8-16.2 4.8-9.8 0-19.4-4.8-25.2-13.8-9-14-5-32.4 8.8-41.4l128.6-83.2c7.6-5 17-6.2 25.6-3.2l134.6 44.4 162.2-97.8c14.2-8.6 32.6-4 41.2 10.2s4 32.6-10.2 41zM254.4 749c-16.6 0-30-13.4-30-30v-143.8c0-16.6 13.4-30 30-30s30 13.4 30 30v143.8c0 16.6-13.6 30-30 30z m224.8 0c-16.6 0-30-13.4-30-30v-91.4c0-16.6 13.4-30 30-30s30 13.4 30 30v91.4c0 16.6-13.6 30-30 30z m-112.4 0c-16.6 0-30-13.4-30-30V494.2c0-16.6 13.4-30 30-30s30 13.4 30 30v225c0 16.4-13.6 29.8-30 29.8z" p-id="6338"></path></svg>
          <div class="logo-text">
            <span class="company-name">营销自动化系统</span>
            <span class="company-slogan">创新科技，引领未来</span>
          </div>
        </div>
        
        <div class="footer-links">
          <a href="#" class="footer-link">关于我们</a>
          <a href="#" class="footer-link">服务条款</a>
          <a href="#" class="footer-link">隐私政策</a>
          <a href="#" class="footer-link">联系我们</a>
        </div>
        
        <div class="footer-bottom">
          <p class="copyright">© 2025 营销自动化系统 Precise online marketing to attract customers</p>
          <p class="version-info">版本 v0.0.0</p>
        </div>
      </div>
    </div>

    <!-- 消息提示对话框 -->
    <div v-if="showMessageDialog" class="confirm-dialog-overlay" @click="closeMessageDialog">
      <div class="confirm-dialog" @click.stop>
        <div class="dialog-header">
          <h3>{{ messageDialog.title }}</h3>
        </div>
        <div class="dialog-content">
          <p>{{ messageDialog.message }}</p>
        </div>
        <div class="dialog-actions">
          <button class="btn-confirm" @click="closeMessageDialog">确定</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'

// 表单数据
const formData = reactive({
  email: 'admin@example.com',
  password: '123456',
  rememberMe: false
})

// 状态管理
const isLoading = ref(false)
const showPassword = ref(false)
const errors = reactive({
  email: '',
  password: ''
})

// 消息对话框状态
const showMessageDialog = ref(false)
const messageDialog = reactive({
  title: '',
  message: ''
})

// 切换密码显示
const togglePassword = () => {
  showPassword.value = !showPassword.value
}

// 清除错误信息
const clearError = () => {
  errors.email = ''
  errors.password = ''
}

// 表单验证
const validateForm = () => {
  let isValid = true
  errors.email = ''
  errors.password = ''

  if (!formData.email) {
    errors.email = '请输入邮箱地址'
    isValid = false
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = '请输入有效的邮箱地址'
    isValid = false
  }

  if (!formData.password) {
    errors.password = '请输入密码'
    isValid = false
  } else if (formData.password.length < 6) {
    errors.password = '密码长度至少6位'
    isValid = false
  }

  return isValid
}

// 显示消息对话框
const showMessage = (title: string, message: string, autoClose = false, delay = 2000) => {
  messageDialog.title = title
  messageDialog.message = message
  showMessageDialog.value = true
  
  if (autoClose) {
    setTimeout(() => {
      closeMessageDialog()
    }, delay)
  }
}

// 关闭消息对话框
const closeMessageDialog = () => {
  showMessageDialog.value = false
}

// 处理登录
const handleLogin = async () => {
  if (!validateForm()) {
    return
  }
  isLoading.value = true
  try {
    // 模拟登录请求
    await new Promise(resolve => setTimeout(resolve, 500))
    // 账号密码校验
    if (formData.email === 'admin@example.com' && formData.password === '123456') {
      showMessage('登录成功', '欢迎回来！正在跳转到主页面...', true, 1500)
      // 登录成功后自动跳转
      setTimeout(() => {
        window.location.hash = '#/dashboard'
      }, 1500)
    } else {
      showMessage('登录失败', '账号或密码错误，请检查后重试', true, 2000)
    }
  } catch (error) {
    showMessage('登录失败', '网络连接异常，请检查网络后重试', true, 2000)
  } finally {
    isLoading.value = false
  }
}

// 处理忘记密码
const handleForgotPassword = () => {
  showMessage('功能提示', '忘记密码功能正在开发中，请联系管理员', true, 2000)
}
</script>

<style scoped>
.login-container {
  min-height: 100vh;
  height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #2D3748 0%, #1A202C 100%);
  position: relative;
  overflow: hidden;
  margin: 0;
  padding: 0;
}

.background-decoration {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1;
}

.grid-pattern {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: 
    radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.1) 1px, transparent 0);
  background-size: 20px 20px;
  opacity: 0.3;
}

.login-card {
  background: #FFFFFF;
  border-radius: 12px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
  padding: 20px 50px 20px 50px;
  width: 400px;
  max-width: 95vw;
  position: relative;
  z-index: 2;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.login-title {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 700;
  font-size: 30px;
  color: #2D3748;
  margin-bottom: 10px;
}

.login-subtitle {
  color: #718096;
  font-size: 16px;
}

.login-form {
  margin-bottom: 20px;
}

.input-group {
  margin-bottom: 30px;
}

.input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.input-icon {
  position: absolute;
  left: 16px;
  color: #718096;
  z-index: 1;
}

.form-input {
  width: 100%;
  height: 48px;
  padding: 0 16px 0 48px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 16px;
  transition: all 0.3s ease;
  background: #FFFFFF;
}

.form-input:focus {
  outline: none;
  border-color: #2C6FD1;
  box-shadow: 0 0 0 3px rgba(44, 111, 209, 0.1);
}

.form-input.error {
  border-color: #E53E3E;
}

.form-input::placeholder {
  color: #A0AEC0;
}

.password-toggle {
  position: absolute;
  right: 16px;
  background: none;
  border: none;
  color: #718096;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
}

.password-toggle:hover {
  color: #2C6FD1;
}

.error-text {
  color: #E53E3E;
  font-size: 12px;
  margin-top: 4px;
  display: block;
}

.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 50px;
  margin-bottom: 20px;
}

.remember-me {
  display: flex;
  align-items: center;
  cursor: pointer;
  user-select: none;
}

.checkbox-input {
  display: none;
}

.checkbox-custom {
  width: 16px;
  height: 16px;
  border: 2px solid #E2E8F0;
  border-radius: 3px;
  margin-right: 8px;
  position: relative;
  transition: all 0.3s ease;
}

.checkbox-input:checked + .checkbox-custom {
  background: #2C6FD1;
  border-color: #2C6FD1;
}

.checkbox-input:checked + .checkbox-custom::after {
  content: '';
  position: absolute;
  left: 4px;
  top: 1px;
  width: 4px;
  height: 8px;
  border: solid white;
  border-width: 0 2px 2px 0;
  transform: rotate(45deg);
}

.checkbox-text {
  color: #4A5568;
  font-size: 14px;
}

.forgot-password {
  color: #2C6FD1;
  text-decoration: none;
  font-size: 14px;
  transition: all 0.3s ease;
}

.forgot-password:hover {
  color: #1E5AB9;
  text-decoration: underline;
}

.login-button {
  width: 100%;
  height: 48px;
  background: #2C6FD1;
  color: white;
  border: none;
  border-radius: 6px;
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 500;
  font-size: 18px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-button:hover:not(:disabled) {
  background: #1E5AB9;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(44, 111, 209, 0.3);
}

.login-button:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.loading-spinner {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.footer-info {
  margin-top: 40px;
  text-align: center;
  position: relative;
  z-index: 2;
  width: 100%;
  max-width: 1200px;
}

.footer-content {
  background: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(10px);
  border-radius: 12px;
  padding: 15px 30px 10px 30px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
}

.company-logo {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
  color: #2C6FD1;
  transition: all 0.3s ease;
}

.company-logo:hover {
  color: #FF6B35;
  transform: scale(1.05);
}

.logo-text {
  margin-left: 16px;
  text-align: left;
}

.company-name {
  display: block;
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 700;
  font-size: 18px;
  color: #FFFFFF;
  margin-bottom: 4px;
}

.company-slogan {
  display: block;
  font-size: 12px;
  color: #A0AEC0;
  font-weight: 400;
}

.footer-links {
  display: flex;
  justify-content: center;
  gap: 24px;
  margin-bottom: 10px;
  flex-wrap: wrap;
}

.footer-link {
  color: #A0AEC0;
  text-decoration: none;
  font-size: 14px;
  transition: all 0.3s ease;
  position: relative;
  padding: 4px 0;
}

.footer-link::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 0;
  height: 2px;
  background: linear-gradient(90deg, #2C6FD1, #FF6B35);
  transition: width 0.3s ease;
}

.footer-link:hover {
  color: #FFFFFF;
}

.footer-link:hover::after {
  width: 100%;
}

.footer-bottom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 15px;
  border-top: 1px solid rgba(160, 174, 192, 0.2);
}

.copyright {
  color: #A0AEC0;
  font-size: 12px;
  margin: 0;
}

.version-info {
  color: #718096;
  font-size: 11px;
  margin: 0;
  font-family: 'Courier New', monospace;
}

/* 确认对话框样式 - 与Layout.vue保持一致 */
.confirm-dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}

.confirm-dialog {
  background: white;
  border-radius: 8px;
  padding: 24px;
  min-width: 400px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.dialog-header {
  margin-bottom: 16px;
}

.dialog-header h3 {
  margin: 0;
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 18px;
  color: #2D3748;
}

.dialog-content {
  margin-bottom: 24px;
}

.dialog-content p {
  margin: 0;
  font-size: 14px;
  color: #4A5568;
  line-height: 1.5;
}

.dialog-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}

.btn-confirm {
  background: #E53E3E;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 8px 16px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-confirm:hover {
  background: #C53030;
}

/* 响应式设计 */
@media (max-width: 480px) {
  .login-container {
    padding: 10px;
    height: 100vh;
    min-height: 100vh;
  }
  
  .login-card {
    padding: 30px 25px;
    width: 95vw;
  }
  
  .form-options {
    flex-direction: column;
    gap: 12px;
    align-items: flex-start;
  }
  
  .footer-content {
    padding: 20px;
    margin: 0 10px;
  }
  
  .footer-links {
    gap: 16px;
  }
  
  .footer-bottom {
    flex-direction: column;
    gap: 8px;
  }
  
  .company-logo {
    flex-direction: column;
    text-align: center;
  }
  
  .logo-text {
    margin-left: 0;
    margin-top: 12px;
    text-align: center;
  }
  
  .confirm-dialog {
    min-width: 90vw;
    margin: 0 20px;
  }
}
</style> 