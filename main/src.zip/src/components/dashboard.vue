<template>
  <div class="dashboard-container">
    <!-- 欢迎横幅 -->
    <section class="welcome-banner">
      <div class="welcome-text">
        <h1>{{ greeting }}，{{ userName }}！今天是{{ currentDate }}</h1>
      </div>
      <div class="quick-stats">
        <div class="stat-item">
          <span class="stat-label">总用户数</span>
          <span class="stat-value">124,580</span>
          <span class="stat-trend positive">↑8%</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">昨日新增</span>
          <span class="stat-value">1,245</span>
          <span class="stat-trend positive">↑12%</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">转化率</span>
          <span class="stat-value">12.8%</span>
          <span class="stat-trend positive">↑2.1%</span>
        </div>
      </div>
      <button class="create-btn" @click="showCreateActivityModal = true">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="13,2 3,14 12,14 11,22 21,10 12,10 13,2"/>
        </svg>
        新建活动
        <div class="btn-ripple" v-if="btnRipple"></div>
      </button>
    </section>

    <!-- KPI指标卡片 -->
    <section class="kpi-section">
      <div class="kpi-grid">
        <div class="kpi-card" v-for="kpi in kpiData" :key="kpi.id">
          <div class="kpi-header">
            <div class="kpi-icon" :style="{ backgroundColor: kpi.color }" v-html="kpi.icon"></div>
            <div class="kpi-info">
              <h3 class="kpi-title">{{ kpi.title }}</h3>
              <p class="kpi-value">{{ kpi.value }}</p>
              <p class="kpi-trend" :class="kpi.trendType">{{ kpi.trend }}</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 数据可视化区域 -->
    <section class="charts-section">
      <div class="chart-container">
        <div class="chart-card">
          <h3 class="chart-title">最近30天流量趋势</h3>
          <div class="chart-toolbar">
            <div class="chart-range">
              <button class="range-btn active">天</button>
              <button class="range-btn">周</button>
              <button class="range-btn">月</button>
            </div>
            <div class="chart-legend">
              <span class="legend-dot" style="background:#FF6B35"></span> 转化率 <span class="legend-value">0-15%</span>
            </div>
          </div>
          <div class="chart-placeholder traffic-chart">
            <svg width="420" height="220" viewBox="0 0 420 220" fill="none" xmlns="http://www.w3.org/2000/svg">
              <!-- Y轴刻度线和文字 -->
              <g font-size="12" fill="#A0AEC0">
                <text x="10" y="200">0</text>
                <text x="0" y="160">100</text>
                <text x="0" y="120">200</text>
                <text x="0" y="80">300</text>
                <text x="0" y="40">400</text>
              </g>
              <g stroke="#E2E8F0" stroke-width="1">
                <line x1="40" y1="200" x2="400" y2="200"/>
                <line x1="40" y1="160" x2="400" y2="160"/>
                <line x1="40" y1="120" x2="400" y2="120"/>
                <line x1="40" y1="80" x2="400" y2="80"/>
                <line x1="40" y1="40" x2="400" y2="40"/>
              </g>
              <!-- X轴刻度 -->
              <g font-size="12" fill="#A0AEC0">
                <text x="55" y="215">23</text>
                <text x="95" y="215">24</text>
                <text x="135" y="215">25</text>
                <text x="175" y="215">26</text>
                <text x="215" y="215">27</text>
                <text x="255" y="215">28</text>
                <text x="295" y="215">29</text>
                <text x="335" y="215">30</text>
                <text x="375" y="215">31</text>
              </g>
              <!-- 柱状图 -->
              <rect x="55" y="140" width="20" height="60" rx="4" fill="#2C6FD1"/>
              <rect x="95" y="120" width="20" height="80" rx="4" fill="#2C6FD1"/>
              <rect x="135" y="100" width="20" height="100" rx="4" fill="#2C6FD1"/>
              <rect x="175" y="80" width="20" height="120" rx="4" fill="#2C6FD1"/>
              <rect x="215" y="120" width="20" height="80" rx="4" fill="#2C6FD1"/>
              <rect x="255" y="100" width="20" height="100" rx="4" fill="#2C6FD1"/>
              <rect x="295" y="60" width="20" height="140" rx="4" fill="#2C6FD1"/>
              <rect x="335" y="40" width="20" height="160" rx="4" fill="#2C6FD1"/>
              <rect x="375" y="80" width="20" height="120" rx="4" fill="#2C6FD1"/>
              <!-- 折线图渐变 -->
              <defs>
                <linearGradient id="lineArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="#FF6B35" stop-opacity="0.18"/>
                  <stop offset="100%" stop-color="#FF6B35" stop-opacity="0"/>
                </linearGradient>
              </defs>
              <polygon points="65,180 105,160 145,140 185,120 225,140 265,120 305,100 345,60 385,80 385,200 65,200" fill="url(#lineArea)"/>
              <!-- 折线图 -->
              <polyline points="65,180 105,160 145,140 185,120 225,140 265,120 305,100 345,60 385,80" fill="none" stroke="#FF6B35" stroke-width="3"/>
              <!-- 数据点 -->
              <circle cx="65" cy="180" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
              <circle cx="105" cy="160" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
              <circle cx="145" cy="140" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
              <circle cx="185" cy="120" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
              <circle cx="225" cy="140" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
              <circle cx="265" cy="120" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
              <circle cx="305" cy="100" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
              <circle cx="345" cy="60" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
              <circle cx="385" cy="80" r="6" fill="#fff" stroke="#FF6B35" stroke-width="3"/>
            </svg>
          </div>
        </div>
      </div>
      <div class="chart-container">
        <div class="chart-card">
          <h3 style="margin-bottom: 40px;">各渠道转化率对比</h3>
          <div class="chart-placeholder">
            <img :src="chartImage" alt="chart" height="100%" width="100%">
          </div>
        </div>
      </div>
    </section>

    <!-- 实时监控面板 -->
    <section class="monitor-section">
      <div class="monitor-card">
        <!-- 监控面板容器 -->
        <div class="monitor-panel">
          <!-- 左侧活动看板 -->
          <div class="activity-board">
            <div class="panel-header">
              <h3>进行中的营销活动</h3>
              <div class="view-all">查看全部</div>
            </div>
            
            <div class="activity-list">
              <!-- 活动卡片1 -->
              <div class="activity-card">
                <div class="activity-header">
                  <h4>618年中大促活动</h4>
                  <span class="status-tag normal">正常</span>
                </div>
                <div class="progress-container">
                  <div class="progress-bar" style="width: 72%"></div>
                </div>
                <div class="activity-footer">
                  <span class="conversion">转化数：1,245</span>
                  <button class="view-btn">查看详情</button>
                </div>
              </div>
              
              <!-- 活动卡片2 -->
              <div class="activity-card">
                <div class="activity-header">
                  <h4>夏季新品推广</h4>
                  <span class="status-tag warning">预警</span>
                </div>
                <div class="progress-container">
                  <div class="progress-bar" style="width: 45%"></div>
                </div>
                <div class="activity-footer">
                  <span class="conversion">转化数：842</span>
                  <button class="view-btn">查看详情</button>
                </div>
              </div>
              
              <!-- 活动卡片3 -->
              <div class="activity-card">
                <div class="activity-header">
                  <h4>会员忠诚度计划</h4>
                  <span class="status-tag timeout">超时</span>
                </div>
                <div class="progress-container">
                  <div class="progress-bar" style="width: 92%"></div>
                </div>
                <div class="activity-footer">
                  <span class="conversion">转化数：2,156</span>
                  <button class="view-btn">查看详情</button>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 右侧系统状态 -->
          <div class="system-status">
            <div class="panel-header">
              <h3>服务健康监测</h3>
              <div class="last-check">最近检测：5分钟前</div>
            </div>
            
            <div class="status-grid">
              <!-- 状态卡片1 -->
              <div class="status-card">
                <div class="status-icon">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="#38A169" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div class="status-info">
                  <div class="status-name">数据采集</div>
                  <div class="status-value normal">正常 ✓</div>
                </div>
              </div>
              
              <!-- 状态卡片2 -->
              <div class="status-card">
                <div class="status-icon">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22 12H18L15 21L9 3L6 12H2" stroke="#2C6FD1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div class="status-info">
                  <div class="status-name">API服务</div>
                  <div class="status-value">负载67%</div>
                </div>
                <div class="progress-container">
                  <div class="load-bar" style="width: 67%"></div>
                </div>
              </div>
              
              <!-- 状态卡片3 -->
              <div class="status-card">
                <div class="status-icon">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 6H5H21" stroke="#805AD5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M19 6V20C19 20.5304 18.7893 21.0391 18.4142 21.4142C18.0391 21.7893 17.5304 22 17 22H7C6.46957 22 5.96086 21.7893 5.58579 21.4142C5.21071 21.0391 5 20.5304 5 20V6" stroke="#805AD5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M8 6V4C8 3.46957 8.21071 2.96086 8.58579 2.58579C8.96086 2.21071 9.46957 2 10 2H14C14.5304 2 15.0391 2.21071 15.4142 2.58579C15.7893 2.96086 16 3.46957 16 4V6" stroke="#805AD5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div class="status-info">
                  <div class="status-name">存储空间</div>
                  <div class="status-value">1.2T/2T</div>
                </div>
                <div class="progress-container">
                  <div class="storage-bar" style="width: 60%"></div>
                </div>
              </div>
              
              <!-- 状态卡片4 -->
              <div class="status-card">
                <div class="status-icon">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="#FF6B35" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div class="status-info">
                  <div class="status-name">安全防护</div>
                  <div class="status-value enabled">已启用</div>
                </div>
              </div>
              
              <!-- 仪表盘可视化 -->
              <div class="dashboard-visual">
                <div class="gauge">
                  <svg width="180" height="180" viewBox="0 0 180 180">
                    <!-- 底部灰色圆环 -->
                    <circle 
                      cx="90" 
                      cy="90" 
                      r="80" 
                      fill="none" 
                      stroke="#E2E8F0" 
                      stroke-width="15"
                    ></circle>
                    <!-- 进度条绿色部分 -->
                    <circle 
                      cx="90" 
                      cy="90" 
                      r="80" 
                      fill="none" 
                      stroke="#38A169" 
                      stroke-width="15"
                      stroke-linecap="round"
                      stroke-dasharray="502.4" 
                      stroke-dashoffset="125.6"
                      transform="rotate(-90 90 90)"
                    ></circle>
                  </svg>
                  <div class="gauge-center">
                    <span>75%</span>
                    <small>整体健康度</small>
                  </div>
                </div>
                <div class="gauge-labels">
                  <div class="gauge-label">低风险</div>
                  <div class="gauge-label medium-risk">中风险</div>
                  <div class="gauge-label">高风险</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 新建活动模态框 -->
    <div v-if="showCreateActivityModal" class="modal-overlay" @click="closeCreateActivityModal">
      <div class="modal-content create-activity-modal" @click.stop>
        <div class="modal-header">
          <h3>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="header-icon">
              <polyline points="13,2 3,14 12,14 11,22 21,10 12,10 13,2"/>
            </svg>
            新建营销活动
          </h3>
          <button class="modal-close" @click="closeCreateActivityModal">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
        
        <div class="modal-body">
          <!-- 活动类型选择 -->
          <div class="step-section">
            <h4 class="section-title">
              <span class="step-number">1</span>
              选择活动类型
            </h4>
            <div class="activity-types">
              <div 
                v-for="type in activityTypes" 
                :key="type.id"
                class="activity-type-card"
                :class="{ 'selected': newActivity.type === type.id }"
                @click="selectActivityType(type.id)"
              >
                <div class="type-icon" v-html="type.icon"></div>
                <div class="type-info">
                  <h5>{{ type.name }}</h5>
                  <p>{{ type.description }}</p>
                </div>
                <div class="type-selector">
                  <div class="radio-dot"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- 基本信息 -->
          <div class="step-section">
            <h4 class="section-title">
              <span class="step-number">2</span>
              基本信息
            </h4>
            <div class="form-row">
              <div class="form-group">
                <label>活动名称 *</label>
                <input 
                  type="text" 
                  v-model="newActivity.name" 
                  placeholder="请输入活动名称"
                  class="form-input"
                  :class="{ 'error': activityErrors.name }"
                />
                <span v-if="activityErrors.name" class="error-text">{{ activityErrors.name }}</span>
              </div>
              <div class="form-group">
                <label>活动标签</label>
                <select v-model="newActivity.tag" class="form-select">
                  <option value="">请选择标签</option>
                  <option value="promotion">促销活动</option>
                  <option value="brand">品牌推广</option>
                  <option value="product">产品推广</option>
                  <option value="seasonal">季节营销</option>
                </select>
              </div>
            </div>
            
            <div class="form-row">
              <div class="form-group">
                <label>开始时间 *</label>
                <input 
                  type="datetime-local" 
                  v-model="newActivity.startTime" 
                  class="form-input"
                  :class="{ 'error': activityErrors.startTime }"
                />
                <span v-if="activityErrors.startTime" class="error-text">{{ activityErrors.startTime }}</span>
              </div>
              <div class="form-group">
                <label>结束时间 *</label>
                <input 
                  type="datetime-local" 
                  v-model="newActivity.endTime" 
                  class="form-input"
                  :class="{ 'error': activityErrors.endTime }"
                />
                <span v-if="activityErrors.endTime" class="error-text">{{ activityErrors.endTime }}</span>
              </div>
            </div>

            <div class="form-group">
              <label>活动描述</label>
              <textarea 
                v-model="newActivity.description" 
                placeholder="请描述活动内容和目标..."
                class="form-textarea"
                rows="4"
              ></textarea>
            </div>
          </div>

          <!-- 目标设置 -->
          <div class="step-section">
            <h4 class="section-title">
              <span class="step-number">3</span>
              目标设置
            </h4>
            <div class="form-row">
              <div class="form-group">
                <label>目标用户数</label>
                <input 
                  type="number" 
                  v-model="newActivity.targetUsers" 
                  placeholder="预期触达用户数"
                  class="form-input"
                />
              </div>
              <div class="form-group">
                <label>目标转化率 (%)</label>
                <input 
                  type="number" 
                  v-model="newActivity.targetConversion" 
                  placeholder="预期转化率"
                  class="form-input"
                  step="0.1"
                />
              </div>
            </div>
            
            <div class="form-row">
              <div class="form-group">
                <label>预算 (元)</label>
                <input 
                  type="number" 
                  v-model="newActivity.budget" 
                  placeholder="活动预算"
                  class="form-input"
                />
              </div>
              <div class="form-group">
                <label>优先级</label>
                <select v-model="newActivity.priority" class="form-select">
                  <option value="low">低</option>
                  <option value="medium">中</option>
                  <option value="high">高</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        
        <div class="modal-footer">
          <button class="btn-cancel" @click="closeCreateActivityModal">取消</button>
          <button class="btn-confirm" @click="createActivity" :disabled="!canCreateActivity">
            <svg v-if="isCreating" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spinning">
              <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
            </svg>
            {{ isCreating ? '创建中...' : '创建活动' }}
          </button>
        </div>
      </div>
    </div>

    <!-- 创建成功提示 -->
    <div v-if="showSuccessToast" class="toast-notification success">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M20 6L9 17L4 12"/>
      </svg>
      <span>活动创建成功！</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

// 导入图片
const chartImage = new URL('../assets/chart.jpg', import.meta.url).href

// 响应式数据
const userName = ref('张经理')

// 新建活动相关状态
const showCreateActivityModal = ref(false)
const isCreating = ref(false)
const showSuccessToast = ref(false)
const btnRipple = ref(false)

// 新建活动表单数据
const newActivity = ref({
  type: '',
  name: '',
  tag: '',
  startTime: '',
  endTime: '',
  description: '',
  targetUsers: '',
  targetConversion: '',
  budget: '',
  priority: 'medium'
})

// 表单验证错误
const activityErrors = ref<Record<string, string>>({})

// 活动类型选项
const activityTypes = ref([
  {
    id: 'email',
    name: '邮件营销',
    description: '通过邮件推送触达目标用户',
    icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
             <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
             <polyline points="22,6 12,13 2,6"/>
           </svg>`
  },
  {
    id: 'social',
    name: '社交媒体',
    description: '在社交平台发布推广内容',
    icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
             <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
           </svg>`
  },
  {
    id: 'sms',
    name: '短信营销',
    description: '发送短信给目标用户群体',
    icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
             <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
           </svg>`
  },
  {
    id: 'promotion',
    name: '促销活动',
    description: '设置优惠券或折扣活动',
    icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
             <path d="M21 12c0 1.66-1.34 3-3 3H6c-1.66 0-3-1.34-3-3s1.34-3 3-3h12c1.66 0 3 1.34 3 3z"/>
             <path d="M7 12h10"/>
           </svg>`
  }
])

// KPI数据
const kpiData = [
  {
    id: 1,
    title: '潜在客户数',
    value: '24,580',
    trend: '↑12%',
    trendType: 'positive',
    color: '#2C6FD1',
    icon: `<svg t="1754571211427" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="96868" width="35" height="35"><path d="M405.504 415.701333a208.213333 208.213333 0 0 1-4.010667-72.704 104.064 104.064 0 1 1 104.021334-155.989333 205.354667 205.354667 0 0 1 68.693333-24.192 176 176 0 1 0-168.704 252.885333z m356.181333 163.584A352 352 0 0 0 256 896a35.968 35.968 0 1 0 72.021333 0 280.064 280.064 0 0 1 336.384-274.304 223.061333 223.061333 0 0 1 97.28-42.410667z m132.224 164.608h-87.808v-87.808a36.138667 36.138667 0 0 0-72.192 0v87.808h-87.808a36.138667 36.138667 0 0 0 0 72.192h87.808v87.808a36.138667 36.138667 0 0 0 72.192 0v-87.808h87.808a36.138667 36.138667 0 0 0 0-72.192z m-109.909333-375.893333a176 176 0 1 0-352 0 176 176 0 0 0 352 0z m-176 104.021333a104.064 104.064 0 0 1 0-208 104.064 104.064 0 0 1 0 208z m-169.301333 16.896a207.018667 207.018667 0 0 1-33.109334-72.832A352.128 352.128 0 0 0 64 768a35.968 35.968 0 1 0 72.021333 0 280.064 280.064 0 0 1 302.677334-279.082667z" fill="#ffffff" opacity=".65" p-id="96869"></path></svg>`
  },
  {
    id: 2,
    title: '营销活动数',
    value: '18',
    trend: '6个进行中',
    trendType: 'neutral',
    color: '#FF6B35',
    icon: `<svg t="1754571073633" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="90277" width="35" height="35"><path d="M729.258667 555.306667c53.290667 0 98.602667 18.688 135.978666 56.064 37.333333 37.333333 56.021333 82.688 56.021334 135.936 0 53.333333-18.688 98.602667-56.021334 135.978666-37.376 37.376-82.688 56.021333-135.978666 56.021334-53.248 0-98.56-18.645333-135.936-56.021334-37.376-37.376-56.064-82.688-56.064-135.978666 0-53.248 18.688-98.56 56.064-135.936 37.333333-37.376 82.688-56.064 135.936-56.064zM659.541333 81.066667c9.045333 0 16.64 3.072 22.784 9.173333a30.976 30.976 0 0 1 9.216 22.826667v58.24h59.050667c21.546667 0 39.808 7.466667 54.741333 22.4 14.933333 14.933333 22.4 33.194667 22.4 54.741333v233.088a207.573333 207.573333 0 0 0-31.36-10.837333 298.709333 298.709333 0 0 0-32.64-6.528V419.114667h-597.333333v400.426666c0 3.285333 1.365333 6.272 4.096 9.002667a12.544 12.544 0 0 0 9.045333 4.096h277.418667c3.584 11.818667 7.936 23.04 13.056 33.536 5.12 10.538667 10.922667 20.693333 17.450667 30.464H179.541333c-21.546667 0-39.808-7.466667-54.741333-22.4a74.453333 74.453333 0 0 1-22.4-54.698667V248.448c0-21.546667 7.466667-39.808 22.4-54.741333 14.933333-14.933333 33.194667-22.4 54.741333-22.4h59.050667V113.92c0-9.344 3.157333-17.152 9.386667-23.424a31.786667 31.786667 0 0 1 23.466666-9.386667c9.344 0 17.152 3.114667 23.424 9.386667 6.229333 6.272 9.386667 14.08 9.386667 23.466667v57.386666h323.285333V113.066667c0-9.088 3.029333-16.682667 9.173334-22.826667a30.976 30.976 0 0 1 22.826666-9.173333z m69.717334 525.44c-39.68 0-72.021333 13.312-99.754667 41.045333-27.733333 27.733333-41.045333 60.032-41.045333 99.754667 0 39.765333 13.312 72.021333 41.045333 99.754666 27.733333 27.733333 60.032 41.045333 99.754667 41.045334s72.021333-13.312 99.754666-41.045334c27.733333-27.733333 41.045333-59.989333 41.045334-99.754666 0-39.68-13.312-72.021333-41.045334-99.754667-27.733333-27.733333-60.032-41.045333-99.754666-41.045333z m0 25.941333a25.6 25.6 0 0 1 25.258666 21.461333l0.341334 4.138667v77.44l55.978666 47.786667a25.6 25.6 0 0 1 5.546667 32.298666l-2.688 3.797334a25.6 25.6 0 0 1-32.341333 5.546666l-3.754667-2.688-73.941333-63.104v-101.12a25.6 25.6 0 0 1 25.6-25.6z m21.333333-397.141333H179.541333a12.544 12.544 0 0 0-9.045333 4.138666 12.544 12.544 0 0 0-4.096 9.002667v106.666667h597.333333v-106.666667a12.544 12.544 0 0 0-4.096-9.045333 12.544 12.544 0 0 0-9.045333-4.096z" p-id="90278" fill="#ffffff"></path></svg>`
  },
  {
    id: 3,
    title: '内容发布量',
    value: '128',
    trend: '本周新增12个',
    trendType: 'positive',
    color: '#38A169',
    icon: `<svg t="1754571496624" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="20026" width="35" height="35"><path d="M812.9 698.2V332.5c0-30.8-25.1-56-55.7-56H397.5c-0.3 0-0.6-0.1-0.8-0.4l-71.1-101.9c-7.5-10.7-19.7-17.1-32.8-17.1H151c-30.6 0-55.7 25.2-55.7 56v485c0 30.8 25.1 56 55.7 56h606.2c30.6 0 55.7-25.1 55.7-55.9zM282.4 217.1l65.1 93.3c11.4 16.3 30.1 26.1 50 26.1h355.4v46.4H155.3V217.1h127.1z m-127.1 477V442.9h597.5v251.2H155.3z" p-id="20027" fill="#ffffff"></path><path d="M898.8 382.9c-0.1 0-0.1 0 0 0-16.6 0-30 13.4-30.1 29.9l-0.9 394H296.4c-16.6 0-30 13.4-30 30s13.4 30 30 30h601.4c16.5 0 30-13.4 30-29.9l1-423.9c-0.1-16.6-13.5-30-30-30.1z" p-id="20028" fill="#ffffff"></path></svg>`
  },
  {
    id: 4,
    title: '渠道连接',
    value: '6/8',
    trend: '正常连接数：6个',
    trendType: 'warning',
    color: '#805AD5',
    icon: `<svg t="1754571604846" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="26554" width="35" height="35"><path d="M0 0h1024v1024H0z" fill="#ffffff" fill-opacity="0" p-id="26555"></path><path d="M291.147294 676.382118H150.588235a26.352941 26.352941 0 0 0-26.352941 26.352941V843.294118c0 14.546824 11.806118 26.352941 26.352941 26.352941h140.559059a26.352941 26.352941 0 0 0 26.352941-26.352941v-140.559059a26.352941 26.352941 0 0 0-26.352941-26.352941z m-26.383059 52.705882v87.853176H176.941176v-87.853176h87.823059zM783.058824 184.470588H220.852706A26.352941 26.352941 0 0 0 194.499765 210.823529v210.82353c0 14.546824 11.806118 26.352941 26.352941 26.352941H783.058824a26.352941 26.352941 0 0 0 26.352941-26.352941V210.823529A26.352941 26.352941 0 0 0 783.058824 184.470588z m-26.352942 52.705883v158.117647H247.205647v-158.117647h509.500235z" fill="#ffffff" p-id="26556"></path><path d="M501.970824 395.294118c13.432471 0 24.515765 10.059294 26.142117 23.04l0.210824 3.312941v281.088a26.352941 26.352941 0 0 1-52.525177 3.312941l-0.180706-3.312941V421.647059c0-14.546824 11.776-26.352941 26.352942-26.352941z" fill="#ffffff" p-id="26557"></path><path d="M783.058824 535.853176c13.432471 0 24.515765 10.029176 26.142117 23.04l0.210824 3.312942v140.528941a26.352941 26.352941 0 0 1-52.495059 3.312941l-0.210824-3.312941v-114.206118H247.205647v114.206118a26.352941 26.352941 0 0 1-23.04 26.172235l-3.312941 0.180706a26.352941 26.352941 0 0 1-26.142118-23.04l-0.210823-3.312941v-140.528941c0-13.432471 10.059294-24.545882 23.070117-26.172236l3.312942-0.180706H783.058824z" fill="#ffffff" p-id="26558"></path><path d="M853.323294 676.382118h-140.528941a26.352941 26.352941 0 0 0-26.352941 26.352941V843.294118c0 14.546824 11.776 26.352941 26.352941 26.352941h140.528941a26.352941 26.352941 0 0 0 26.352941-26.352941v-140.559059a26.352941 26.352941 0 0 0-26.352941-26.352941z m-26.352941 52.705882v87.853176h-87.853177v-87.853176h87.853177zM572.235294 676.382118h-140.559059a26.352941 26.352941 0 0 0-26.352941 26.352941V843.294118c0 14.546824 11.806118 26.352941 26.352941 26.352941H572.235294a26.352941 26.352941 0 0 0 26.352941-26.352941v-140.559059a26.352941 26.352941 0 0 0-26.352941-26.352941z m-26.352941 52.705882v87.853176h-87.853177v-87.853176h87.853177zM361.411765 289.882353a26.352941 26.352941 0 0 1 3.312941 52.495059l-3.312941 0.210823h-35.147294a26.352941 26.352941 0 0 1-3.312942-52.495059l3.312942-0.210823H361.411765z" fill="#ffffff" p-id="26559"></path></svg>`
  }
]

// 计算属性
const greeting = computed(() => {
  const hour = new Date().getHours()
  if (hour < 12) return '上午好'
  if (hour < 18) return '下午好'
  return '晚上好'
})

const currentDate = computed(() => {
  return new Date().toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
})

// 新建活动相关计算属性和方法
const canCreateActivity = computed(() => {
  return newActivity.value.type && 
         newActivity.value.name && 
         newActivity.value.startTime && 
         newActivity.value.endTime &&
         !isCreating.value
})

// 选择活动类型
const selectActivityType = (typeId: string) => {
  newActivity.value.type = typeId
  activityErrors.value = {} // 清除错误
}

// 关闭模态框
const closeCreateActivityModal = () => {
  showCreateActivityModal.value = false
  resetActivityForm()
}

// 重置表单
const resetActivityForm = () => {
  newActivity.value = {
    type: '',
    name: '',
    tag: '',
    startTime: '',
    endTime: '',
    description: '',
    targetUsers: '',
    targetConversion: '',
    budget: '',
    priority: 'medium'
  }
  activityErrors.value = {}
}

// 验证表单
const validateActivityForm = () => {
  const errors: any = {}
  
  if (!newActivity.value.type) {
    errors.type = '请选择活动类型'
  }
  
  if (!newActivity.value.name.trim()) {
    errors.name = '请输入活动名称'
  }
  
  if (!newActivity.value.startTime) {
    errors.startTime = '请选择开始时间'
  }
  
  if (!newActivity.value.endTime) {
    errors.endTime = '请选择结束时间'
  }
  
  if (newActivity.value.startTime && newActivity.value.endTime) {
    const startDate = new Date(newActivity.value.startTime)
    const endDate = new Date(newActivity.value.endTime)
    const now = new Date()
    
    if (startDate <= now) {
      errors.startTime = '开始时间必须晚于当前时间'
    }
    
    if (endDate <= startDate) {
      errors.endTime = '结束时间必须晚于开始时间'
    }
  }
  
  activityErrors.value = errors
  return Object.keys(errors).length === 0
}

// 创建活动
const createActivity = async () => {
  if (!validateActivityForm()) {
    return
  }
  
  isCreating.value = true
  
  try {
    // 模拟API调用
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // 关闭模态框
    closeCreateActivityModal()
    
    // 显示成功提示
    showSuccessToast.value = true
    setTimeout(() => {
      showSuccessToast.value = false
    }, 3000)
    
    console.log('活动创建成功:', newActivity.value)
  } catch (error) {
    console.error('创建活动失败:', error)
  } finally {
    isCreating.value = false
  }
}

</script>

<style scoped>
.dashboard-container {
  padding: 24px;
  background: #F7FAFC;
  min-height: 100vh;
}

/* 欢迎横幅 */
.welcome-banner {
  background: linear-gradient(135deg, #2C6FD1 0%, #1E5AB9 100%);
  color: white;
  padding: 24px;
  border-radius: 12px;
  margin-bottom: 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.welcome-text h1 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 700;
  font-size: 24px;
  margin: 0;
}

.quick-stats {
  display: flex;
  gap: 32px;
}

.stat-item {
  text-align: center;
}

.stat-label {
  display: block;
  font-size: 12px;
  opacity: 0.8;
  margin-bottom: 4px;
}

.stat-value {
  display: block;
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 4px;
}

.stat-trend {
  font-size: 12px;
  padding: 2px 8px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.2);
}

.stat-trend.positive {
  background: rgba(72, 187, 120, 0.2);
  color: #48BB78;
}

.create-btn {
  background: linear-gradient(135deg, #FF6B35, #FF5722);
  color: #FFFFFF;
  border: none;
  border-radius: 8px;
  padding: 12px 20px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(255, 107, 53, 0.3);
}

.create-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(255, 107, 53, 0.4);
}

.create-btn:active {
  transform: translateY(0);
}

.btn-ripple {
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.3);
  animation: ripple 0.6s ease-out;
}

@keyframes ripple {
  0% {
    width: 0;
    height: 0;
    opacity: 1;
  }
  100% {
    width: 100px;
    height: 100px;
    opacity: 0;
  }
}

/* KPI卡片 */
.kpi-section {
  margin-bottom: 24px;
}

.kpi-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}

.kpi-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  border: 1px solid #E2E8F0;
}

.kpi-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
}

.kpi-header {
  display: flex;
  align-items: center;
  gap: 16px;
}

.kpi-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.kpi-title {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-size: 14px;
  color: #718096;
  margin: 0 0 4px 0;
}

.kpi-value {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 700;
  font-size: 24px;
  color: #2D3748;
  margin: 0 0 4px 0;
}

.kpi-trend {
  font-size: 12px;
  margin: 0;
}

.kpi-trend.positive {
  color: #38A169;
}

.kpi-trend.negative {
  color: #E53E3E;
}

.stat-trend.neutral {
  color: #718096;
}

.stat-trend.warning {
  color: #D69E2E;
}

/* 图表区域 */
.charts-section {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 24px;
}

.chart-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.chart-card h3 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 16px;
  color: #2D3748;
  margin: 0 0 10px 0;
}

.chart-placeholder {
  height: 250px;
  background: #F7FAFC;
  border: 2px dashed #CBD5E0;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #718096;
  font-size: 14px;
}

/* 监控面板 */
.monitor-section {
  margin-bottom: 24px;
}

.monitor-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .kpi-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .charts-section {
    grid-template-columns: 1fr;
  }
  
  .status-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .kpi-grid {
    grid-template-columns: 1fr;
  }
  
  .quick-stats {
    flex-direction: column;
    gap: 16px;
  }
  
  .welcome-banner {
    flex-direction: column;
    gap: 16px;
    text-align: center;
  }
}

.chart-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.chart-legend {
  display: flex;
  align-items: center;
  gap: 16px;
  font-size: 13px;
  color: #718096;
}

.legend-dot {
  display: inline-block;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  margin-right: 4px;
}

.legend-value {
  color: #A0AEC0;
  font-size: 12px;
  margin-left: 4px;
}

.chart-range {
  display: flex;
  gap: 8px;
}

.range-btn {
  background: #F7FAFC;
  border: 1px solid #E2E8F0;
  color: #2C6FD1;
  border-radius: 20px;
  padding: 2px 22px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.range-btn.active, .range-btn:hover {
  background: #2C6FD1;
  color: #fff;
  border-color: #2C6FD1;
}

.traffic-chart {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 220px;
  background: #fff;
  border-radius: 12px;
  border: 1.5px solid #E2E8F0;
  margin-top: 8px;
  box-shadow: 0 2px 8px rgba(44,111,209,0.04);
}

.chart-title {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 700;
  font-size: 20px;
  color: #222;
  margin-bottom: 8px;
}

/* 监控面板容器 */
.monitor-panel {
  display: flex;
  gap: 24px;
}

/* 左右列基本样式 */
.activity-board, 
.system-status {
  flex: 1;
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
}

/* 面板标题区域 */
.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 1px solid #EDF2F7;
}

.panel-header h3 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 18px;
  color: #2D3748;
  margin: 0;
}

.view-all, .last-check {
  color: #2C6FD1;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}

/* 活动卡片样式 */
.activity-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.activity-card {
  padding: 16px;
  border-radius: 8px;
  border: 1px solid #E2E8F0;
  background: #F7FAFC;
  transition: all 0.3s ease;
}

.activity-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.activity-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.activity-header h4 {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin: 0;
}

.status-tag {
  font-size: 12px;
  padding: 4px 10px;
  border-radius: 12px;
  font-weight: 600;
}

.status-tag.normal {
  background: #C6F6D5;
  color: #22543D;
}

.status-tag.warning {
  background: #FEFCBF;
  color: #744210;
}

.status-tag.timeout {
  background: #FED7D7;
  color: #822727;
}

.progress-container {
  height: 8px;
  background: #E2E8F0;
  border-radius: 4px;
  margin-bottom: 12px;
  overflow: hidden;
}

.progress-bar {
  height: 100%;
  background: #2C6FD1;
  border-radius: 4px;
}

.activity-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.conversion {
  font-size: 14px;
  color: #718096;
}

.view-btn {
  background: #FFFFFF;
  border: 1px solid #2C6FD1;
  color: #2C6FD1;
  border-radius: 4px;
  padding: 6px 12px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.view-btn:hover {
  background: #EBF4FF;
}

/* 系统状态区域 */
.status-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.status-card {
  padding: 16px;
  border-radius: 8px;
  border: 1px solid #E2E8F0;
  background: #F7FAFC;
  display: flex;
  flex-direction: column;
  position: relative;
}

.status-icon {
  width: 36px;
  height: 36px;
  background: #EBF4FF;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 12px;
}

.status-info {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}

.status-name {
  font-size: 14px;
  color: #718096;
}

.status-value {
  font-size: 14px;
  font-weight: 600;
  color: #2D3748;
}

.status-value.normal {
  color: #38A169;
}

.status-value.enabled {
  color: #2C6FD1;
}

.load-bar {
  height: 100%;
  background: #2C6FD1;
  border-radius: 4px;
}

.storage-bar {
  height: 100%;
  background: #805AD5;
  border-radius: 4px;
}

/* 仪表盘可视化 */
.dashboard-visual {
  grid-column: span 2;
  padding: 20px;
  background: #F7FAFC;
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.gauge {
  width: 200px;
  height: 200px;
  position: relative;
  margin-bottom: 30px;
}

/* SVG仪表盘样式 */
.gauge-svg {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

.gauge-svg circle {
  fill: none;
  stroke-width: 15;
  transform-origin: center;
  transform: rotate(-90deg);
}

.gauge-bg {
  stroke: #E2E8F0;
}

.gauge-arc {
  stroke: #38A169;
  stroke-linecap: round;
  transition: stroke-dasharray 0.3s ease;
}

.gauge-text {
  text-anchor: middle;
  dominant-baseline: middle;
}

.gauge-center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  z-index: 2;
}

.gauge-center span {
  font-size: 24px;
  font-weight: 700;
  color: #2D3748;
  display: block;
}

.gauge-center small {
  font-size: 12px;
  color: #718096;
}

.gauge-labels {
  display: flex;
  justify-content: space-between;
  width: 100%;
  max-width: 220px;
  font-size: 12px;
  color: #718096;
}

.medium-risk {
  background-color: #DD6B20;
  color: white;
  padding: 4px 8px;
  border-radius: 12px;
}

/* 新建活动模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.create-activity-modal {
  background: white;
  border-radius: 16px;
  width: 90%;
  max-width: 800px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
  animation: slideUp 0.3s ease-out;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 32px;
  border-bottom: 1px solid #E2E8F0;
}

.modal-header h3 {
  font-size: 20px;
  font-weight: 700;
  color: #1A202C;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-icon {
  color: #FF6B35;
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  padding: 8px;
  border-radius: 8px;
  color: #718096;
  transition: all 0.3s ease;
}

.modal-close:hover {
  background: #F7FAFC;
  color: #1A202C;
}

.modal-body {
  padding: 32px;
  max-height: 60vh;
  overflow-y: auto;
}

.step-section {
  margin-bottom: 32px;
}

.section-title {
  font-size: 18px;
  font-weight: 600;
  color: #2D3748;
  margin: 0 0 20px 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.step-number {
  background: linear-gradient(135deg, #FF6B35, #FF5722);
  color: white;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 700;
}

/* 活动类型选择 */
.activity-types {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 16px;
}

.activity-type-card {
  border: 2px solid #E2E8F0;
  border-radius: 12px;
  padding: 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 16px;
  position: relative;
}

.activity-type-card:hover {
  border-color: #FF6B35;
  box-shadow: 0 4px 12px rgba(255, 107, 53, 0.1);
}

.activity-type-card.selected {
  border-color: #FF6B35;
  background: linear-gradient(135deg, #FFF5F0, #FFEEE6);
}

.type-icon {
  width: 48px;
  height: 48px;
  background: #F7FAFC;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #4A5568;
  flex-shrink: 0;
}

.activity-type-card.selected .type-icon {
  background: #FF6B35;
  color: white;
}

.type-info {
  flex: 1;
}

.type-info h5 {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin: 0 0 4px 0;
}

.type-info p {
  font-size: 14px;
  color: #718096;
  margin: 0;
}

.type-selector {
  width: 20px;
  height: 20px;
  border: 2px solid #E2E8F0;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.activity-type-card.selected .type-selector {
  border-color: #FF6B35;
  background: #FF6B35;
}

.radio-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: transparent;
  transition: background 0.3s ease;
}

.activity-type-card.selected .radio-dot {
  background: white;
}

/* 表单样式 */
.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-group label {
  font-size: 14px;
  font-weight: 600;
  color: #2D3748;
}

.form-input,
.form-select,
.form-textarea {
  padding: 12px 16px;
  border: 2px solid #E2E8F0;
  border-radius: 8px;
  font-size: 14px;
  transition: all 0.3s ease;
  font-family: inherit;
}

.form-input:focus,
.form-select:focus,
.form-textarea:focus {
  outline: none;
  border-color: #FF6B35;
  box-shadow: 0 0 0 3px rgba(255, 107, 53, 0.1);
}

.form-input.error,
.form-select.error,
.form-textarea.error {
  border-color: #E53E3E;
}

.form-textarea {
  resize: vertical;
  min-height: 100px;
}

.error-text {
  color: #E53E3E;
  font-size: 12px;
  font-weight: 500;
}

/* 模态框底部 */
.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 16px;
  padding: 24px 32px;
  border-top: 1px solid #E2E8F0;
}

.btn-cancel {
  background: #F7FAFC;
  color: #4A5568;
  border: 2px solid #E2E8F0;
  border-radius: 8px;
  padding: 12px 24px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-cancel:hover {
  background: #EDF2F7;
  border-color: #CBD5E0;
}

.btn-confirm {
  background: linear-gradient(135deg, #FF6B35, #FF5722);
  color: white;
  border: none;
  border-radius: 8px;
  padding: 12px 24px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 8px;
  box-shadow: 0 4px 12px rgba(255, 107, 53, 0.3);
}

.btn-confirm:hover:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: 0 6px 16px rgba(255, 107, 53, 0.4);
}

.btn-confirm:disabled {
  background: #A0AEC0;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.spinning {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* Toast通知 */
.toast-notification {
  position: fixed;
  top: 24px;
  right: 24px;
  background: #38A169;
  color: white;
  padding: 16px 20px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  z-index: 3000;
  animation: slideInRight 0.3s ease-out;
  font-weight: 500;
}

.toast-notification.success {
  background: linear-gradient(135deg, #38A169, #2F855A);
}

@keyframes slideInRight {
  from {
    opacity: 0;
    transform: translateX(100%);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

/* 响应式适配 */
@media (max-width: 768px) {
  .create-activity-modal {
    width: 95%;
    margin: 20px;
  }
  
  .modal-header,
  .modal-body,
  .modal-footer {
    padding: 20px;
  }
  
  .form-row {
    grid-template-columns: 1fr;
    gap: 16px;
  }
  
  .activity-types {
    grid-template-columns: 1fr;
  }
  
  .modal-footer {
    flex-direction: column;
  }
  
  .btn-cancel,
  .btn-confirm {
    width: 100%;
    justify-content: center;
  }
}
</style>
