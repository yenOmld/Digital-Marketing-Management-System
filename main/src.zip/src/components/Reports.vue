<template>
  <div class="reports-container">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1>报表中心</h1>
        <p>智能数据分析平台 - 全方位报表生成与业务洞察</p>
      </div>
      <div class="header-actions">
        <button class="btn-primary" @click="showCreateReportModal = true">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 5v14M5 12h14"/>
          </svg>
          3秒建报表
        </button>
      </div>
    </div>

    <!-- 智能筛选面板 -->
    <div class="filter-panel">
      <div class="filter-section">
        <h3>时间魔方</h3>
        <div class="time-filters">
          <button :class="['time-btn', { active: timeRange === 'today' }]" @click="setTimeRange('today')">今天</button>
          <button :class="['time-btn', { active: timeRange === '7days' }]" @click="setTimeRange('7days')">近7天</button>
          <button :class="['time-btn', { active: timeRange === 'month' }]" @click="setTimeRange('month')">本月</button>
          <button :class="['time-btn', { active: timeRange === 'quarter' }]" @click="setTimeRange('quarter')">季度</button>
        </div>
        <div class="compare-toggle">
          <label class="toggle-switch">
            <input type="checkbox" v-model="compareMode" />
            <span class="toggle-slider"></span>
            同期对比
          </label>
        </div>
      </div>

      <div class="filter-section">
        <h3>数据维度选择器</h3>
        <div class="dimension-filters">
          <div class="dimension-group">
            <label>渠道维度：</label>
            <select v-model="channelDimension">
              <option value="all">全部渠道</option>
              <option value="website">网站</option>
              <option value="wechat">微信</option>
              <option value="app">APP</option>
            </select>
          </div>
          <div class="dimension-group">
            <label>用户维度：</label>
            <select v-model="userDimension">
              <option value="all">全部用户</option>
              <option value="new">新客</option>
              <option value="old">老客</option>
              <option value="high_value">高价值</option>
            </select>
          </div>
        </div>
      </div>

      <div class="filter-section">
        <h3>指标切换器</h3>
        <div class="metric-filters">
          <div class="metric-group">
            <label>核心指标：</label>
            <select v-model="coreMetric">
              <option value="conversion">转化率</option>
              <option value="roi">ROI</option>
              <option value="cost">获客成本</option>
            </select>
          </div>
          <div class="custom-formula">
            <label>自定义公式：</label>
            <input type="text" v-model="customFormula" placeholder="(转化数÷点击量)×100%" />
          </div>
        </div>
      </div>
    </div>

    <!-- 数据概览卡片 -->
    <div class="overview-cards">
      <div class="overview-card">
        <div class="card-icon" style="background: #2C6FD1">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
            <polyline points="14,2 14,8 20,8"/>
            <line x1="16" y1="13" x2="8" y2="13"/>
            <line x1="16" y1="17" x2="8" y2="17"/>
            <polyline points="10,9 9,9 8,9"/>
          </svg>
        </div>
        <div class="card-content">
          <h3>总报表数</h3>
          <div class="card-value">156</div>
          <div class="card-trend positive">↑8.5%</div>
        </div>
      </div>
      
      <div class="overview-card">
        <div class="card-icon" style="background: #38A169">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
            <polyline points="22,4 12,14.01 9,11.01"/>
          </svg>
        </div>
        <div class="card-content">
          <h3>已完成</h3>
          <div class="card-value">142</div>
          <div class="card-trend positive">↑12.3%</div>
        </div>
      </div>
      
      <div class="overview-card">
        <div class="card-icon" style="background: #FF6B35">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <polyline points="12,6 12,12 16,14"/>
          </svg>
        </div>
        <div class="card-content">
          <h3>进行中</h3>
          <div class="card-value">8</div>
          <div class="card-trend negative">↓2.1%</div>
        </div>
      </div>
      
      <div class="overview-card">
        <div class="card-icon" style="background: #805AD5">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        <div class="card-content">
          <h3>推荐报表</h3>
          <div class="card-value">24</div>
          <div class="card-trend positive">↑15.8%</div>
        </div>
      </div>
    </div>

    <!-- 主要内容区域 -->
    <div class="main-content">
      <!-- 左侧：报表导航墙 -->
      <div class="left-panel">
        <!-- 分类导航 -->
        <div class="panel-card">
          <div class="panel-header">
            <h3>报表分类</h3>
          </div>
          
          <div class="category-nav">
            <div class="nav-category">
              <h4>营销效果</h4>
              <div class="nav-items">
                <div class="nav-item" :class="{ active: activeReport === 'activity' }" @click="setActiveReport('activity')">
                  <span class="nav-icon">📊</span>
                  活动报表
                </div>
                <div class="nav-item" :class="{ active: activeReport === 'channel' }" @click="setActiveReport('channel')">
                  <span class="nav-icon">📈</span>
                  渠道报表
                </div>
              </div>
            </div>
            
            <div class="nav-category">
              <h4>用户分析</h4>
              <div class="nav-items">
                <div class="nav-item" :class="{ active: activeReport === 'profile' }" @click="setActiveReport('profile')">
                  <span class="nav-icon">👤</span>
                  画像报告
                </div>
                <div class="nav-item" :class="{ active: activeReport === 'behavior' }" @click="setActiveReport('behavior')">
                  <span class="nav-icon">🎯</span>
                  行为报告
                </div>
              </div>
            </div>
            
            <div class="nav-category">
              <h4>内容效能</h4>
              <div class="nav-items">
                <div class="nav-item" :class="{ active: activeReport === 'heatmap' }" @click="setActiveReport('heatmap')">
                  <span class="nav-icon">🔥</span>
                  热力报告
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 我的收藏 -->
        <div class="panel-card">
          <div class="panel-header">
            <h3>我的收藏</h3>
          </div>
          
          <div class="favorites-list">
            <div class="favorite-item" v-for="favorite in favoriteReports" :key="favorite.id">
              <span class="favorite-icon">⭐</span>
              <span class="favorite-name">{{ favorite.name }}</span>
            </div>
            <div class="recent-history">
              <h5>最近查看</h5>
              <div class="recent-item" v-for="recent in recentReports" :key="recent.id">
                <span class="recent-name">{{ recent.name }}</span>
                <span class="recent-time">{{ recent.time }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 报表搜索 -->
        <div class="panel-card">
          <div class="panel-header">
            <h3>搜索报表</h3>
          </div>
          
          <div class="search-section">
            <div class="search-input-wrapper">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"/>
                <path d="M21 21l-4.35-4.35"/>
              </svg>
              <input 
                type="text" 
                v-model="searchQuery" 
                placeholder="搜索报告名称..."
                class="search-input"
              />
            </div>
          </div>
        </div>
      </div>

      <!-- 右侧：报表展示区 -->
      <div class="right-panel">
        <!-- 多视图标签页 -->
        <div class="panel-card">
          <div class="panel-header">
            <div class="view-tabs">
              <button :class="['tab-btn', { active: activeView === 'chart' }]" @click="setActiveView('chart')">
                图表视图
              </button>
              <button :class="['tab-btn', { active: activeView === 'table' }]" @click="setActiveView('table')">
                表格视图
              </button>
              <button :class="['tab-btn', { active: activeView === 'compare' }]" @click="setActiveView('compare')">
                对比视图
              </button>
            </div>
            <div class="view-actions">
              <button class="btn-secondary" @click="showAnalysisTools = !showAnalysisTools">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M3 3v18h18"/>
                  <path d="M18.7 8l-5.1 5.2-2.8-2.7L7 14.3"/>
                </svg>
                分析工具
              </button>
            </div>
          </div>
          
          <!-- 报表展示画布 -->
          <div class="report-canvas">
            <div v-if="activeView === 'chart'" class="chart-view">
              <!-- 趋势分析 - 双Y轴折线图 -->
              <div class="chart-container trend-chart">
                <div class="chart-header">
                  <h4>渠道效果分析 ⭐</h4>
                  <div class="chart-badges">
                    <span class="badge fire">🔥</span>
                    <span class="badge-text">热门报表</span>
                  </div>
                </div>
                <div class="chart-info">
                  <div class="chart-meta">
                    <span class="meta-item">📅 数据时段：8.1-8.7</span>
                    <span class="meta-item">📊 包含：折线图+数据表格</span>
                    <span class="meta-item">⚡ 最新更新：今天 10:30</span>
                  </div>
                </div>
                <div class="chart-content">
                  <!-- 双Y轴折线图 -->
                  <svg width="100%" height="300" viewBox="0 0 600 300" class="trend-svg">
                    <!-- 网格线 -->
                    <defs>
                      <pattern id="grid" width="40" height="30" patternUnits="userSpaceOnUse">
                        <path d="M 40 0 L 0 0 0 30" fill="none" stroke="#E2E8F0" stroke-width="1"/>
                      </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#grid)" />
                    
                    <!-- Y轴标签 -->
                    <g font-size="12" fill="#718096">
                      <text x="15" y="50">400</text>
                      <text x="15" y="100">300</text>
                      <text x="15" y="150">200</text>
                      <text x="15" y="200">100</text>
                      <text x="25" y="250">0</text>
                    </g>
                    
                    <!-- X轴标签 -->
                    <g font-size="12" fill="#718096">
                      <text x="60" y="280">8.1</text>
                      <text x="140" y="280">8.2</text>
                      <text x="220" y="280">8.3</text>
                      <text x="300" y="280">8.4</text>
                      <text x="380" y="280">8.5</text>
                      <text x="460" y="280">8.6</text>
                      <text x="540" y="280">8.7</text>
                    </g>
                    
                    <!-- 转化率折线（科技蓝） -->
                    <polyline
                      fill="none"
                      stroke="#2C6FD1"
                      stroke-width="3"
                      points="60,180 140,160 220,140 300,120 380,100 460,90 540,80"
                    />
                    
                    <!-- ROI折线（活力橙） -->
                    <polyline
                      fill="none"
                      stroke="#FF6B35"
                      stroke-width="3"
                      points="60,200 140,190 220,170 300,150 380,140 460,130 540,110"
                    />
                    
                    <!-- 数据点标记 -->
                    <g fill="#2C6FD1">
                      <circle cx="60" cy="180" r="4"/>
                      <circle cx="140" cy="160" r="4"/>
                      <circle cx="220" cy="140" r="4"/>
                      <circle cx="300" cy="120" r="4"/>
                      <circle cx="380" cy="100" r="4"/>
                      <circle cx="460" cy="90" r="4"/>
                      <!-- 最大值菱形标记 -->
                      <polygon points="540,80 545,85 540,90 535,85" fill="#2C6FD1"/>
                    </g>
                    
                    <g fill="#FF6B35">
                      <circle cx="60" cy="200" r="4"/>
                      <circle cx="140" cy="190" r="4"/>
                      <circle cx="220" cy="170" r="4"/>
                      <circle cx="300" cy="150" r="4"/>
                      <circle cx="380" cy="140" r="4"/>
                      <circle cx="460" cy="130" r="4"/>
                      <circle cx="540" cy="110" r="4"/>
                    </g>
                    
                    <!-- 图例 -->
                    <g font-size="12">
                      <line x1="450" y1="30" x2="470" y2="30" stroke="#2C6FD1" stroke-width="3"/>
                      <text x="475" y="35" fill="#2C6FD1">转化率</text>
                      <line x1="450" y1="50" x2="470" y2="50" stroke="#FF6B35" stroke-width="3"/>
                      <text x="475" y="55" fill="#FF6B35">ROI</text>
                    </g>
                  </svg>
                </div>
              </div>

              <!-- 占比分析 - 环形图 -->
              <div class="chart-container donut-chart">
                <div class="chart-header">
                  <h4>渠道占比分析</h4>
                </div>
                <div class="chart-content">
                  <svg width="100%" height="250" viewBox="0 0 400 250" class="donut-svg">
                    <!-- 环形图 -->
                    <g transform="translate(200, 125)">
                      <!-- 微信渠道 40% -->
                      <path d="M 0,-80 A 80,80 0 0,1 69.28,40 L 34.64,20 A 40,40 0 0,0 0,-40 Z" fill="#38A169" />
                      <!-- 网站渠道 35% -->
                      <path d="M 69.28,40 A 80,80 0 0,1 -25.71,75.65 L -12.86,37.82 A 40,40 0 0,0 34.64,20 Z" fill="#2C6FD1" />
                      <!-- APP渠道 25% -->
                      <path d="M -25.71,75.65 A 80,80 0 0,1 0,-80 L 0,-40 A 40,40 0 0,0 -12.86,37.82 Z" fill="#FF6B35" />
                      
                      <!-- 中心文字 -->
                      <text x="0" y="-5" text-anchor="middle" font-size="14" font-weight="600" fill="#2D3748">总转化</text>
                      <text x="0" y="15" text-anchor="middle" font-size="20" font-weight="700" fill="#2D3748">15.8%</text>
                    </g>
                    
                    <!-- 图例 -->
                    <g font-size="12">
                      <rect x="50" y="220" width="12" height="12" fill="#38A169"/>
                      <text x="70" y="230" fill="#2D3748">微信 40%</text>
                      <rect x="150" y="220" width="12" height="12" fill="#2C6FD1"/>
                      <text x="170" y="230" fill="#2D3748">网站 35%</text>
                      <rect x="250" y="220" width="12" height="12" fill="#FF6B35"/>
                      <text x="270" y="230" fill="#2D3748">APP 25%</text>
                    </g>
                  </svg>
                </div>
              </div>
            </div>

            <div v-if="activeView === 'table'" class="table-view">
              <div class="data-table">
                <table>
                  <thead>
                    <tr>
                      <th>渠道</th>
                      <th>访问量</th>
                      <th>转化数</th>
                      <th>转化率</th>
                      <th>ROI</th>
                      <th>操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="row in tableData" :key="row.id">
                      <td>{{ row.channel }}</td>
                      <td>{{ row.visits }}</td>
                      <td>{{ row.conversions }}</td>
                      <td :class="{ 'highlight': row.conversionRate > 15 }">{{ row.conversionRate }}%</td>
                      <td>{{ row.roi }}</td>
                      <td>
                        <button class="table-action-btn" @click="drillDown(row)">下钻</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div v-if="activeView === 'compare'" class="compare-view">
              <div class="compare-container">
                <div class="compare-section">
                  <h4>本期数据</h4>
                  <div class="compare-metrics">
                    <div class="metric-item">
                      <span class="metric-label">转化率</span>
                      <span class="metric-value">15.8%</span>
                    </div>
                    <div class="metric-item">
                      <span class="metric-label">ROI</span>
                      <span class="metric-value">3.2</span>
                    </div>
                  </div>
                </div>
                <div class="compare-divider">VS</div>
                <div class="compare-section">
                  <h4>同期数据</h4>
                  <div class="compare-metrics">
                    <div class="metric-item">
                      <span class="metric-label">转化率</span>
                      <span class="metric-value">13.6%</span>
                    </div>
                    <div class="metric-item">
                      <span class="metric-label">ROI</span>
                      <span class="metric-value">2.8</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="compare-insights">
                <div class="insight-item">
                  <span class="insight-icon">📈</span>
                  <span class="insight-text">转化率提升2.2%，表现优异</span>
                </div>
                <div class="insight-item">
                  <span class="insight-icon">💰</span>
                  <span class="insight-text">ROI增长14.3%，投资回报显著</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 分析工具箱（右侧滑出） -->
    <div class="analysis-tools" :class="{ active: showAnalysisTools }">
      <div class="tools-header">
        <h3>分析工具箱</h3>
        <button class="close-tools" @click="showAnalysisTools = false">×</button>
      </div>
      
      <div class="tools-content">
        <!-- 智能洞察 -->
        <div class="tool-section">
          <h4>智能洞察</h4>
          <div class="insights-list">
            <div class="insight-item">
              <span class="insight-icon warning">⚠️</span>
              <span class="insight-text">周二转化率下降30%</span>
            </div>
            <div class="insight-item">
              <span class="insight-icon success">💡</span>
              <span class="insight-text">建议增加社交渠道投放</span>
            </div>
          </div>
        </div>

        <!-- 快照功能 -->
        <div class="tool-section">
          <h4>快照管理</h4>
          <div class="snapshot-controls">
            <input type="text" v-model="snapshotName" placeholder="8月销售快照" class="snapshot-input" />
            <button class="btn-primary" @click="saveSnapshot">保存快照</button>
            <button class="btn-secondary" @click="generateShareLink">生成分享链接</button>
          </div>
        </div>

        <!-- 数据讲故事 -->
        <div class="tool-section">
          <h4>数据洞察</h4>
          <button class="btn-primary" @click="generateInsights">生成洞察</button>
          <div v-if="dataStory.length > 0" class="data-story">
            <div v-for="(story, index) in dataStory" :key="index" class="story-item">
              <span class="story-number">{{ index + 1 }}.</span>
              <span class="story-text">{{ story }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 3秒建报表模态框 -->
    <div v-if="showCreateReportModal" class="modal-overlay" @click="closeCreateReportModal">
      <div class="modal-content create-report-modal" @click.stop>
        <div class="modal-header">
          <h3>3秒建报表</h3>
          <button class="modal-close" @click="closeCreateReportModal">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
        
        <div class="modal-body">
          <div class="create-steps">
            <!-- 步骤1：选择数据集 -->
            <div class="step-section" :class="{ active: createStep === 1 }">
              <div class="step-header">
                <span class="step-number">1</span>
                <h4>选择数据集</h4>
              </div>
              <div class="dataset-options">
                <div 
                  class="dataset-card" 
                  :class="{ selected: selectedDataset === 'activity' }"
                  @click="selectDataset('activity')"
                >
                  <div class="dataset-icon">📊</div>
                  <div class="dataset-name">活动数据</div>
                  <div class="dataset-desc">营销活动效果数据</div>
                </div>
                <div 
                  class="dataset-card" 
                  :class="{ selected: selectedDataset === 'channel' }"
                  @click="selectDataset('channel')"
                >
                  <div class="dataset-icon">📈</div>
                  <div class="dataset-name">渠道数据</div>
                  <div class="dataset-desc">各渠道流量转化数据</div>
                </div>
                <div 
                  class="dataset-card" 
                  :class="{ selected: selectedDataset === 'user' }"
                  @click="selectDataset('user')"
                >
                  <div class="dataset-icon">👤</div>
                  <div class="dataset-name">用户数据</div>
                  <div class="dataset-desc">用户行为分析数据</div>
                </div>
              </div>
            </div>

            <!-- 步骤2：拖拽指标 -->
            <div class="step-section" :class="{ active: createStep === 2 }">
              <div class="step-header">
                <span class="step-number">2</span>
                <h4>拖拽指标到画布</h4>
              </div>
              <div class="metrics-drag-area">
                <div class="available-metrics">
                  <h5>可用指标</h5>
                  <div class="metric-list">
                    <div 
                      class="metric-item" 
                      draggable="true"
                      @dragstart="handleDragStart($event, 'conversion')"
                    >
                      📊 转化率
                    </div>
                    <div 
                      class="metric-item" 
                      draggable="true"
                      @dragstart="handleDragStart($event, 'roi')"
                    >
                      💰 ROI
                    </div>
                    <div 
                      class="metric-item" 
                      draggable="true"
                      @dragstart="handleDragStart($event, 'cost')"
                    >
                      💸 获客成本
                    </div>
                  </div>
                </div>
                <div 
                  class="drop-canvas" 
                  @dragover.prevent
                  @drop="handleDrop"
                >
                  <div v-if="selectedMetrics.length === 0" class="drop-placeholder">
                    拖拽指标到此处
                  </div>
                  <div v-else class="selected-metrics">
                    <div 
                      v-for="metric in selectedMetrics" 
                      :key="metric"
                      class="selected-metric"
                    >
                      {{ getMetricName(metric) }}
                      <button @click="removeMetric(metric)">×</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 步骤3：生成图表 -->
            <div class="step-section" :class="{ active: createStep === 3 }">
              <div class="step-header">
                <span class="step-number">3</span>
                <h4>自动生成可视化图表</h4>
              </div>
              <div class="chart-preview">
                <div v-if="selectedMetrics.length > 0" class="preview-chart">
                  <div class="chart-title">{{ selectedDataset }} - {{ selectedMetrics.join(' + ') }} 分析</div>
                  <div class="chart-placeholder">
                    <svg width="100%" height="200" viewBox="0 0 400 200">
                      <rect x="50" y="150" width="60" height="40" fill="#2C6FD1" rx="4"/>
                      <rect x="130" y="120" width="60" height="70" fill="#2C6FD1" rx="4"/>
                      <rect x="210" y="100" width="60" height="90" fill="#2C6FD1" rx="4"/>
                      <rect x="290" y="80" width="60" height="110" fill="#2C6FD1" rx="4"/>
                      <text x="200" y="30" text-anchor="middle" font-size="14" fill="#2D3748">预览图表</text>
                    </svg>
                  </div>
                </div>
                <div v-else class="preview-empty">
                  请先选择数据集和指标
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="modal-footer">
          <button class="btn-secondary" @click="prevStep" :disabled="createStep === 1">
            上一步
          </button>
          <button 
            class="btn-primary" 
            @click="nextStep"
            :disabled="!canProceed"
          >
            {{ createStep === 3 ? '生成报表' : '下一步' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'

// 响应式数据
const showCreateReportModal = ref(false)
const showAnalysisTools = ref(false)
const timeRange = ref('7days')
const compareMode = ref(false)
const channelDimension = ref('all')
const userDimension = ref('all')
const coreMetric = ref('conversion')
const customFormula = ref('(转化数÷点击量)×100%')
const activeReport = ref('channel')
const activeView = ref('chart')
const searchQuery = ref('')
const snapshotName = ref('')

// 3秒建报表相关
const createStep = ref(1)
const selectedDataset = ref('')
const selectedMetrics = ref([])

// 收藏报表
const favoriteReports = ref([
  { id: 1, name: '渠道效果分析' },
  { id: 2, name: '用户转化漏斗' },
  { id: 3, name: '营销ROI报告' }
])

// 最近查看
const recentReports = ref([
  { id: 1, name: '8月销售报告', time: '2小时前' },
  { id: 2, name: '用户留存分析', time: '昨天' },
  { id: 3, name: '广告投放效果', time: '3天前' }
])

// 表格数据
const tableData = ref([
  { id: 1, channel: '微信', visits: 12580, conversions: 2516, conversionRate: 20.0, roi: 3.5 },
  { id: 2, channel: '网站', visits: 9840, conversions: 1476, conversionRate: 15.0, roi: 2.8 },
  { id: 3, channel: 'APP', visits: 7650, conversions: 918, conversionRate: 12.0, roi: 2.2 },
  { id: 4, channel: '抖音', visits: 5420, conversions: 651, conversionRate: 12.0, roi: 1.9 }
])

// 数据故事
const dataStory = ref([])

// 方法
const setTimeRange = (range) => {
  timeRange.value = range
  console.log('时间范围切换:', range)
}

const setActiveReport = (report) => {
  activeReport.value = report
  console.log('切换报表:', report)
}

const setActiveView = (view) => {
  activeView.value = view
  console.log('切换视图:', view)
}

const drillDown = (row) => {
  console.log('下钻分析:', row)
  // 这里可以实现下钻分析逻辑
}

const saveSnapshot = () => {
  if (snapshotName.value) {
    console.log('保存快照:', snapshotName.value)
    // 这里可以实现快照保存逻辑
    snapshotName.value = ''
  }
}

const generateShareLink = () => {
  console.log('生成分享链接')
  // 这里可以实现分享链接生成逻辑
}

const generateInsights = () => {
  dataStory.value = [
    '整体趋势：8月转化率上升15%',
    '关键发现：微信渠道增长显著',
    '异常预警：周末PC端转化下降',
    '行动建议：加大微信渠道投入'
  ]
  console.log('生成数据洞察')
}

// 3秒建报表相关方法
const closeCreateReportModal = () => {
  showCreateReportModal.value = false
  resetCreateReportForm()
}

const resetCreateReportForm = () => {
  createStep.value = 1
  selectedDataset.value = ''
  selectedMetrics.value = []
}

const selectDataset = (dataset) => {
  selectedDataset.value = dataset
}

const nextStep = () => {
  if (createStep.value < 3) {
    createStep.value++
  } else {
    // 生成报表
    console.log('生成报表:', {
      dataset: selectedDataset.value,
      metrics: selectedMetrics.value
    })
    closeCreateReportModal()
  }
}

const prevStep = () => {
  if (createStep.value > 1) {
    createStep.value--
  }
}

const canProceed = computed(() => {
  if (createStep.value === 1) {
    return selectedDataset.value !== ''
  }
  if (createStep.value === 2) {
    return selectedMetrics.value.length > 0
  }
  return true
})

const handleDragStart = (event, metric) => {
  event.dataTransfer.setData('text/plain', metric)
}

const handleDrop = (event) => {
  event.preventDefault()
  const metric = event.dataTransfer.getData('text/plain')
  if (!selectedMetrics.value.includes(metric)) {
    selectedMetrics.value.push(metric)
  }
}

const removeMetric = (metric) => {
  const index = selectedMetrics.value.indexOf(metric)
  if (index > -1) {
    selectedMetrics.value.splice(index, 1)
  }
}

const getMetricName = (metric) => {
  const names = {
    conversion: '转化率',
    roi: 'ROI',
    cost: '获客成本'
  }
  return names[metric] || metric
}
</script>

<style scoped>
.reports-container {
  padding: 24px;
  background: #F7FAFC;
  min-height: 100vh;
}

/* 页面头部 */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 32px;
}

.header-content {
  text-align: center;
  flex: 1;
}

.header-content h1 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 700;
  font-size: 28px;
  color: #2D3748;
  margin: 0 0 8px 0;
}

.header-content p {
  color: #718096;
  font-size: 16px;
  margin: 0;
}

.btn-primary {
  background: #2C6FD1;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 12px 20px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.3s ease;
}

.btn-primary:hover {
  background: #1E5AB9;
}

.btn-secondary {
  background: #F7FAFC;
  color: #2C6FD1;
  border: 1px solid #2C6FD1;
  border-radius: 6px;
  padding: 8px 16px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 8px;
}

.btn-secondary:hover {
  background: #EBF4FF;
}

/* 智能筛选面板 */
.filter-panel {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
  margin-bottom: 24px;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 32px;
}

.filter-section h3 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 16px;
  color: #2D3748;
  margin: 0 0 16px 0;
}

.time-filters {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
}

.time-btn {
  padding: 8px 16px;
  border: 1px solid #E2E8F0;
  background: #F7FAFC;
  color: #718096;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.time-btn.active,
.time-btn:hover {
  background: #2C6FD1;
  color: white;
  border-color: #2C6FD1;
}

.toggle-switch {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-size: 14px;
  color: #4A5568;
}

.toggle-switch input {
  display: none;
}

.toggle-slider {
  width: 40px;
  height: 20px;
  background: #E2E8F0;
  border-radius: 10px;
  position: relative;
  transition: background 0.3s;
}

.toggle-slider:before {
  content: '';
  position: absolute;
  top: 2px;
  left: 2px;
  width: 16px;
  height: 16px;
  background: white;
  border-radius: 50%;
  transition: transform 0.3s;
}

.toggle-switch input:checked + .toggle-slider {
  background: #2C6FD1;
}

.toggle-switch input:checked + .toggle-slider:before {
  transform: translateX(20px);
}

.dimension-filters,
.metric-filters {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.dimension-group,
.metric-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.dimension-group label,
.metric-group label {
  font-size: 14px;
  color: #4A5568;
  font-weight: 500;
}

.dimension-group select,
.metric-group select,
.custom-formula input {
  padding: 8px 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  background: white;
  font-size: 14px;
  color: #2D3748;
}

.custom-formula input {
  width: 100%;
  box-sizing: border-box;
}

/* 概览卡片 */
.overview-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 32px;
}

.overview-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
  display: flex;
  align-items: center;
  gap: 16px;
}

.card-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.card-content h3 {
  font-size: 14px;
  color: #718096;
  margin: 0 0 8px 0;
  font-weight: 500;
}

.card-value {
  font-size: 24px;
  font-weight: 700;
  color: #2D3748;
  margin-bottom: 4px;
}

.card-trend {
  font-size: 12px;
  font-weight: 600;
}

.card-trend.positive {
  color: #38A169;
}

.card-trend.negative {
  color: #E53E3E;
}

/* 主要内容区域 */
.main-content {
  display: grid;
  grid-template-columns: 320px 1fr;
  gap: 24px;
}

/* 左侧面板 */
.left-panel {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* 面板卡片 */
.panel-card {
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.panel-header h3 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 16px;
  color: #2D3748;
  margin: 0;
}

/* 分类导航 */
.category-nav {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.nav-category h4 {
  font-size: 14px;
  color: #718096;
  margin: 0 0 8px 0;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.nav-items {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 14px;
  color: #4A5568;
}

.nav-item:hover {
  background: #EBF4FF;
  color: #2C6FD1;
}

.nav-item.active {
  background: #2C6FD1;
  color: white;
}

.nav-icon {
  font-size: 16px;
}

/* 收藏列表 */
.favorites-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.favorite-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 0;
  font-size: 14px;
  color: #4A5568;
}

.favorite-icon {
  color: #D69E2E;
}

.recent-history {
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid #E2E8F0;
}

.recent-history h5 {
  font-size: 12px;
  color: #718096;
  margin: 0 0 8px 0;
  font-weight: 600;
  text-transform: uppercase;
}

.recent-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 4px 0;
  font-size: 13px;
}

.recent-name {
  color: #4A5568;
}

.recent-time {
  color: #A0AEC0;
  font-size: 12px;
}

/* 搜索区域 */
.search-input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.search-input-wrapper svg {
  position: absolute;
  left: 12px;
  color: #A0AEC0;
}

.search-input {
  width: 100%;
  padding: 12px 12px 12px 40px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
  transition: border-color 0.3s;
}

.search-input:focus {
  border-color: #2C6FD1;
}

/* 右侧面板 */
.right-panel {
  display: flex;
  flex-direction: column;
}

/* 视图标签页 */
.view-tabs {
  display: flex;
  gap: 4px;
}

.tab-btn {
  padding: 8px 16px;
  border: 1px solid #E2E8F0;
  background: #F7FAFC;
  color: #718096;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.tab-btn.active,
.tab-btn:hover {
  background: #2C6FD1;
  color: white;
  border-color: #2C6FD1;
}

.view-actions {
  display: flex;
  gap: 12px;
}

/* 报表画布 */
.report-canvas {
  margin-top: 20px;
  min-height: 600px;
}

/* 图表容器 */
.chart-container {
  background: #F7FAFC;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  border: 1px solid #E2E8F0;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.chart-header h4 {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin: 0;
}

.chart-badges {
  display: flex;
  align-items: center;
  gap: 8px;
}

.badge {
  font-size: 16px;
}

.badge-text {
  font-size: 12px;
  color: #D69E2E;
  font-weight: 600;
}

.chart-info {
  margin-bottom: 16px;
}

.chart-meta {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}

.meta-item {
  font-size: 12px;
  color: #718096;
}

.chart-content {
  background: white;
  border-radius: 6px;
  padding: 16px;
}

/* 表格视图 */
.table-view {
  background: white;
  border-radius: 8px;
  padding: 20px;
}

.data-table {
  overflow-x: auto;
}

.data-table table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
}

.data-table th,
.data-table td {
  padding: 12px 16px;
  text-align: left;
  border-bottom: 1px solid #E2E8F0;
}

.data-table th {
  background: #F7FAFC;
  font-weight: 600;
  color: #2D3748;
}

.data-table td {
  color: #4A5568;
}

.data-table td.highlight {
  background: #FEF3C7;
  color: #92400E;
  font-weight: 600;
}

.table-action-btn {
  background: #2C6FD1;
  color: white;
  border: none;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: background 0.3s;
}

.table-action-btn:hover {
  background: #1E5AB9;
}

/* 对比视图 */
.compare-view {
  background: white;
  border-radius: 8px;
  padding: 20px;
}

.compare-container {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 32px;
  align-items: center;
  margin-bottom: 32px;
}

.compare-section {
  text-align: center;
  padding: 24px;
  background: #F7FAFC;
  border-radius: 8px;
}

.compare-section h4 {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin: 0 0 16px 0;
}

.compare-metrics {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.metric-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.metric-label {
  font-size: 14px;
  color: #718096;
}

.metric-value {
  font-size: 24px;
  font-weight: 700;
  color: #2D3748;
}

.compare-divider {
  font-size: 20px;
  font-weight: 700;
  color: #2C6FD1;
  text-align: center;
}

.compare-insights {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.insight-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  background: #EBF4FF;
  border-radius: 8px;
  border-left: 4px solid #2C6FD1;
}

.insight-icon {
  font-size: 20px;
}

.insight-text {
  font-size: 14px;
  color: #2D3748;
}

/* 分析工具箱 */
.analysis-tools {
  position: fixed;
  top: 0;
  right: -400px;
  width: 380px;
  height: 100vh;
  background: white;
  box-shadow: -4px 0 20px rgba(0, 0, 0, 0.1);
  transition: right 0.3s ease;
  z-index: 1000;
  overflow-y: auto;
}

.analysis-tools.active {
  right: 0;
}

.tools-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  border-bottom: 1px solid #E2E8F0;
}

.tools-header h3 {
  font-size: 18px;
  font-weight: 600;
  color: #2D3748;
  margin: 0;
}

.close-tools {
  background: none;
  border: none;
  font-size: 24px;
  color: #718096;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  transition: background 0.3s;
}

.close-tools:hover {
  background: #F7FAFC;
}

.tools-content {
  padding: 24px;
}

.tool-section {
  margin-bottom: 32px;
}

.tool-section h4 {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin: 0 0 16px 0;
}

.insights-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.insights-list .insight-item {
  padding: 12px;
  background: #F7FAFC;
  border-radius: 6px;
  border-left: 3px solid transparent;
}

.insights-list .insight-item.warning {
  border-left-color: #D69E2E;
  background: #FEFCBF;
}

.insights-list .insight-item.success {
  border-left-color: #38A169;
  background: #F0FFF4;
}

.snapshot-controls {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.snapshot-input {
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
  outline: none;
}

.snapshot-input:focus {
  border-color: #2C6FD1;
}

.data-story {
  margin-top: 16px;
  padding: 16px;
  background: #F7FAFC;
  border-radius: 8px;
  border-left: 4px solid #2C6FD1;
}

.story-item {
  display: flex;
  gap: 8px;
  margin-bottom: 8px;
  align-items: flex-start;
}

.story-number {
  font-weight: 600;
  color: #2C6FD1;
  min-width: 20px;
}

.story-text {
  font-size: 14px;
  color: #2D3748;
  line-height: 1.5;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .overview-cards {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .main-content {
    grid-template-columns: 1fr;
  }
  
  .left-panel {
    order: 2;
  }
  
  .right-panel {
    order: 1;
  }
  
  .filter-panel {
    grid-template-columns: 1fr 1fr;
  }
}

@media (max-width: 768px) {
  .overview-cards {
    grid-template-columns: 1fr;
  }
  
  .filter-panel {
    grid-template-columns: 1fr;
  }
  
  .page-header {
    flex-direction: column;
    gap: 16px;
    align-items: flex-start;
  }
  
  .header-content {
    text-align: left;
  }
  
  .compare-container {
    grid-template-columns: 1fr;
    gap: 16px;
  }
  
  .compare-divider {
    transform: rotate(90deg);
  }
  
  .analysis-tools {
    width: 100%;
    right: -100%;
  }
  
  .chart-meta {
    flex-direction: column;
    gap: 8px;
  }
  
  .time-filters {
    flex-wrap: wrap;
  }
}

/* 3秒建报表模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 800px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.create-report-modal {
  max-width: 900px;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 24px 0 24px;
  border-bottom: 1px solid #E2E8F0;
  padding-bottom: 16px;
}

.modal-header h3 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 20px;
  color: #2D3748;
  margin: 0;
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  color: #718096;
  transition: all 0.3s ease;
}

.modal-close:hover {
  background: #F7FAFC;
  color: #2D3748;
}

.modal-body {
  padding: 24px;
}

.modal-footer {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 0 24px 24px 24px;
  border-top: 1px solid #E2E8F0;
  padding-top: 16px;
}

/* 创建步骤 */
.create-steps {
  display: flex;
  flex-direction: column;
  gap: 32px;
}

.step-section {
  opacity: 0.5;
  transition: opacity 0.3s ease;
}

.step-section.active {
  opacity: 1;
}

.step-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
}

.step-number {
  width: 32px;
  height: 32px;
  background: #2C6FD1;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 14px;
}

.step-header h4 {
  font-size: 18px;
  font-weight: 600;
  color: #2D3748;
  margin: 0;
}

/* 数据集选择 */
.dataset-options {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.dataset-card {
  padding: 20px;
  border: 2px solid #E2E8F0;
  border-radius: 8px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  background: #F7FAFC;
}

.dataset-card:hover {
  border-color: #2C6FD1;
  background: #EBF4FF;
}

.dataset-card.selected {
  border-color: #2C6FD1;
  background: #EBF4FF;
  box-shadow: 0 0 0 3px rgba(44, 111, 209, 0.1);
}

.dataset-icon {
  font-size: 32px;
  margin-bottom: 12px;
}

.dataset-name {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin-bottom: 4px;
}

.dataset-desc {
  font-size: 14px;
  color: #718096;
}

/* 指标拖拽区域 */
.metrics-drag-area {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}

.available-metrics h5 {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin: 0 0 12px 0;
}

.metric-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.metric-item {
  padding: 12px 16px;
  background: #F7FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  cursor: grab;
  transition: all 0.3s ease;
  font-size: 14px;
  color: #2D3748;
}

.metric-item:hover {
  background: #EBF4FF;
  border-color: #2C6FD1;
}

.metric-item:active {
  cursor: grabbing;
}

.drop-canvas {
  min-height: 200px;
  border: 2px dashed #E2E8F0;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #FAFAFA;
  transition: all 0.3s ease;
}

.drop-canvas:hover {
  border-color: #2C6FD1;
  background: #EBF4FF;
}

.drop-placeholder {
  color: #A0AEC0;
  font-size: 16px;
  text-align: center;
}

.selected-metrics {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
  padding: 16px;
}

.selected-metric {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  background: #2C6FD1;
  color: white;
  border-radius: 6px;
  font-size: 14px;
}

.selected-metric button {
  background: none;
  border: none;
  color: white;
  cursor: pointer;
  font-size: 16px;
  padding: 0 4px;
  border-radius: 3px;
  transition: background 0.3s;
}

.selected-metric button:hover {
  background: rgba(255, 255, 255, 0.2);
}

/* 图表预览 */
.chart-preview {
  text-align: center;
}

.preview-chart {
  padding: 20px;
  background: #F7FAFC;
  border-radius: 8px;
  border: 1px solid #E2E8F0;
}

.chart-title {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin-bottom: 16px;
}

.chart-placeholder {
  background: white;
  border-radius: 6px;
  padding: 16px;
}

.preview-empty {
  color: #A0AEC0;
  font-size: 16px;
  padding: 60px 20px;
}

@media (max-width: 768px) {
  .modal-content {
    width: 95%;
    margin: 20px;
  }
  
  .dataset-options {
    grid-template-columns: 1fr;
  }
  
  .metrics-drag-area {
    grid-template-columns: 1fr;
  }
  
  .modal-footer {
    flex-direction: column;
  }
}
</style>
