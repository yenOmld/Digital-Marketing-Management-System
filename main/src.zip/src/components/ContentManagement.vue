<template>
  <div class="content-management-container">
    <!-- 页面标题和工具栏 -->
    <div class="page-header">
      <div class="header-left">
      <h1>内容管理</h1>
        <p>管理营销内容、素材和模板，提升内容营销效果</p>
      </div>
      <div class="header-controls">
        <button class="import-btn" @click="showImportModal = true">
          <span class="btn-icon">📥</span>
          导入内容
        </button>
        <button class="export-btn" @click="exportContents">
          <span class="btn-icon">📤</span>
          导出数据
        </button>
      </div>
    </div>

    <!-- 内容库导航和筛选 -->
    <div class="content-navigation">
      <div class="nav-header">
        <div class="search-section">
          <input 
            v-model="searchQuery" 
            type="text" 
            placeholder="搜索内容标题、标签或作者"
            class="search-input"
          />
          <button class="search-btn" @click="performSearch">
            <span class="btn-icon">🔍</span>
            搜索
          </button>
        </div>
        <div class="quick-filters">
          <button 
            v-for="tag in quickTags" 
            :key="tag"
            :class="['quick-tag', { active: selectedQuickTag === tag }]"
            @click="toggleQuickTag(tag)"
          >
            {{ tag }}
          </button>
        </div>
      </div>

      <div class="category-nav">
        <div class="nav-item" :class="{ active: currentCategory === 'all' }" @click="setCategory('all')">
          <span class="nav-icon">📚</span>
          <span>全部内容</span>
          <span class="count">{{ totalContents }}</span>
        </div>
        <div class="nav-item" :class="{ active: currentCategory === 'article' }" @click="setCategory('article')">
          <span class="nav-icon">📄</span>
          <span>图文</span>
          <span class="count">{{ articleCount }}</span>
        </div>
        <div class="nav-item" :class="{ active: currentCategory === 'video' }" @click="setCategory('video')">
          <span class="nav-icon">🎥</span>
          <span>视频</span>
          <span class="count">{{ videoCount }}</span>
        </div>
        <div class="nav-item" :class="{ active: currentCategory === 'template' }" @click="setCategory('template')">
          <span class="nav-icon">🎨</span>
          <span>模板</span>
          <span class="count">{{ templateCount }}</span>
        </div>
        </div>
      </div>

    <!-- 内容工厂和筛选工具栏 -->
    <div class="content-factory-toolbar">
      <div class="factory-section">
        <button class="factory-btn" @click="showCreateModal('article')">
          <span class="btn-icon">📝</span>
          新建图文
        </button>
        <button class="factory-btn" @click="showCreateModal('video')">
          <span class="btn-icon">🎬</span>
          新建视频
        </button>
        <button class="factory-btn" @click="showCreateModal('template')">
          <span class="btn-icon">🎨</span>
          模板克隆
        </button>
        </div>
      
      <div class="filter-section">
        <select v-model="statusFilter" class="filter-select">
          <option value="all">全部状态</option>
          <option value="published">已发布</option>
          <option value="draft">草稿</option>
          <option value="archived">已归档</option>
        </select>
        <select v-model="sortBy" class="filter-select">
          <option value="createTime">创建时间</option>
          <option value="readRate">阅读率</option>
          <option value="conversionRate">转化率</option>
          <option value="usedCount">使用次数</option>
        </select>
        </div>
      </div>

    <!-- 效能分析板 -->
    <div class="performance-dashboard">
      <div class="dashboard-left">
        <div class="content-heatmap">
          <h3>内容热力榜 TOP5</h3>
          <div class="heatmap-list">
            <div v-for="(item, index) in contentHeatmap" :key="item.id" class="heatmap-item">
              <div class="rank">{{ index + 1 }}</div>
              <div class="content-info">
                <div class="content-title">{{ item.title }}</div>
                <div class="content-meta">
                  <span class="type">{{ item.type }}</span>
                  <span class="used-count">被引用 {{ item.usedCount }} 次</span>
        </div>
              </div>
              <div class="performance">
                <div class="conversion-rate">{{ item.conversionRate }}%</div>
                <div class="trend" :class="item.trend">{{ item.trendText }}</div>
              </div>
            </div>
        </div>
      </div>
    </div>

      <div class="dashboard-right">
        <div class="content-health">
          <h3>内容健康度</h3>
          <div class="health-stats">
            <div class="health-item warning">
              <div class="health-icon">⚠️</div>
              <div class="health-info">
                <div class="health-count">{{ healthData.needOptimize }}</div>
                <div class="health-label">待优化内容</div>
                <div class="health-desc">阅读率 < 40%</div>
      </div>
            </div>
            <div class="health-item danger">
              <div class="health-icon">⏰</div>
              <div class="health-info">
                <div class="health-count">{{ healthData.expired }}</div>
                <div class="health-label">过期内容</div>
                <div class="health-desc">半年未更新</div>
              </div>
            </div>
      </div>
    </div>

        <div class="smart-recommendations">
          <h3>智能推荐</h3>
          <div class="recommendation-list">
            <div v-for="rec in smartRecommendations" :key="rec.id" class="recommendation-item">
              <div class="rec-icon">{{ rec.icon }}</div>
              <div class="rec-content">
                <div class="rec-title">{{ rec.title }}</div>
                <div class="rec-desc">{{ rec.description }}</div>
              </div>
              <button class="rec-action" @click="applyRecommendation(rec)">应用</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 内容列表 -->
    <div class="content-list-section">
      <div class="list-header">
        <h2>内容列表</h2>
        <div class="list-actions">
          <button class="batch-btn" @click="batchOperation">
            <span class="btn-icon">📋</span>
            批量操作
          </button>
        </div>
      </div>
      
    <div class="content-grid">
        <div 
          v-for="content in filteredContents" 
          :key="content.id"
          class="content-card"
          @click="showContentDetail(content)"
        >
          <div class="card-header">
        <div class="content-preview">
          <img :src="content.preview" :alt="content.title" />
              <div class="content-status" :class="content.status">
                {{ content.statusText }}
            </div>
              <!-- 智能标识 -->
              <div class="smart-badges">
                <div v-if="content.isHot" class="badge hot" title="近期热门">
                  🔥
          </div>
                <div v-if="content.isHighConversion" class="badge conversion" title="高转化率">
                  🏆
        </div>
                <div v-if="content.usedInCampaigns > 0" class="badge linked" :title="`被${content.usedInCampaigns}个活动引用`">
                  🔗
                </div>
              </div>
            </div>
            <div class="content-type" :class="content.type">
              {{ getTypeText(content.type) }}
            </div>
          </div>
          
          <div class="card-content">
          <h3 class="content-title">{{ content.title }}</h3>
          <p class="content-description">{{ content.description }}</p>
            
          <div class="content-meta">
              <span class="meta-item">
                <span class="meta-icon">👤</span>
                {{ content.author }}
              </span>
              <span class="meta-item">
                <span class="meta-icon">📅</span>
                {{ content.createTime }}
              </span>
              <span class="meta-item">
                <span class="meta-icon">👁️</span>
                {{ formatNumber(content.views) }} 阅读
              </span>
            </div>
            
            <div class="content-tags">
              <span 
                v-for="tag in content.tags" 
                :key="tag" 
                class="tag"
                :class="getTagClass(tag)"
              >
                {{ tag }}
              </span>
            </div>
            
            <div class="content-stats">
              <div class="stat-item">
                <span class="stat-label">点赞</span>
                <span class="stat-value">{{ formatNumber(content.likes) }}</span>
          </div>
              <div class="stat-item">
                <span class="stat-label">分享</span>
                <span class="stat-value">{{ formatNumber(content.shares) }}</span>
              </div>
            </div>
          </div>
          
          <div class="card-actions">
            <button class="action-btn" @click.stop="viewDetail(content)">
              查看详情
            </button>
            <button class="action-btn secondary" @click.stop="editContent(content)">
              编辑
            </button>
            <button class="action-btn clone" @click.stop="cloneContent(content)" title="3秒克隆">
              克隆
            </button>
            <button class="action-btn analytics" @click.stop="showAnalytics(content)" title="数据分析">
              分析
            </button>
            <button 
              :class="['action-btn', content.status === 'published' ? 'success' : 'warning']"
              @click.stop="toggleStatus(content)"
            >
              {{ content.status === 'published' ? '已发布' : '发布' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 创建内容模态框 -->
    <div v-if="showCreateContentModal" class="modal-overlay" @click="showCreateContentModal = false">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>创建内容</h3>
          <button class="close-btn" @click="showCreateContentModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>内容标题</label>
            <input v-model="newContent.title" type="text" placeholder="输入内容标题" />
          </div>
          <div class="form-group">
            <label>内容描述</label>
            <textarea v-model="newContent.description" placeholder="输入内容描述" rows="3"></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>内容类型</label>
              <select v-model="newContent.type">
                <option value="article">文章</option>
                <option value="image">图片</option>
                <option value="video">视频</option>
                <option value="template">模板</option>
              </select>
            </div>
            <div class="form-group">
              <label>作者</label>
              <input v-model="newContent.author" type="text" placeholder="输入作者姓名" />
            </div>
          </div>
          <div class="form-group">
            <label>标签</label>
            <div class="tag-selector">
              <label class="tag-option">
                <input type="checkbox" v-model="newContent.tags" value="营销" />
                <span>营销</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="newContent.tags" value="产品" />
                <span>产品</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="newContent.tags" value="品牌" />
                <span>品牌</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="newContent.tags" value="教程" />
                <span>教程</span>
              </label>
            </div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="cancel-btn" @click="showCreateContentModal = false">取消</button>
          <button class="confirm-btn" @click="createContent">确认创建</button>
        </div>
      </div>
    </div>

    <!-- 导入内容模态框 -->
    <div v-if="showImportModal" class="modal-overlay" @click="showImportModal = false">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>导入内容</h3>
          <button class="close-btn" @click="showImportModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="upload-area">
            <div class="upload-icon">📁</div>
            <p>拖拽文件到此处或点击选择文件</p>
            <input type="file" accept=".csv,.xlsx" @change="handleFileUpload" />
          </div>
          <div class="import-tips">
            <h4>导入说明：</h4>
            <ul>
              <li>支持 CSV 和 Excel 格式</li>
              <li>文件大小不超过 10MB</li>
              <li>请确保数据格式正确</li>
            </ul>
          </div>
        </div>
        <div class="modal-actions">
          <button class="cancel-btn" @click="showImportModal = false">取消</button>
          <button class="confirm-btn" @click="importContents">开始导入</button>
        </div>
      </div>
    </div>

    <!-- 内容详情模态框 -->
    <div v-if="showContentDetailModal && selectedContent" class="modal-overlay" @click="showContentDetailModal = false">
      <div class="modal-content content-detail-modal" @click.stop>
        <div class="modal-header">
          <h3>内容详情</h3>
          <button class="close-btn" @click="showContentDetailModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="detail-grid">
            <div class="detail-left">
              <div class="content-preview-large">
                <img :src="selectedContent.preview" :alt="selectedContent.title" />
                <div class="content-status" :class="selectedContent.status">
                  {{ selectedContent.statusText }}
                </div>
                <div class="smart-badges">
                  <div v-if="selectedContent.isHot" class="badge hot" title="近期热门">
                    🔥
                  </div>
                  <div v-if="selectedContent.isHighConversion" class="badge conversion" title="高转化率">
                    🏆
                  </div>
                  <div v-if="selectedContent.usedInCampaigns > 0" class="badge linked" :title="`被${selectedContent.usedInCampaigns}个活动引用`">
                    🔗
                  </div>
                </div>
              </div>
            </div>
            <div class="detail-right">
              <div class="detail-info">
                <h4 class="detail-title">{{ selectedContent.title }}</h4>
                <p class="detail-description">{{ selectedContent.description }}</p>
                
                <div class="detail-meta">
                  <div class="meta-row">
                    <span class="meta-label">内容类型:</span>
                    <span class="meta-value">{{ getTypeText(selectedContent.type) }}</span>
                  </div>
                  <div class="meta-row">
                    <span class="meta-label">作者:</span>
                    <span class="meta-value">{{ selectedContent.author }}</span>
                  </div>
                  <div class="meta-row">
                    <span class="meta-label">创建时间:</span>
                    <span class="meta-value">{{ selectedContent.createTime }}</span>
                  </div>
                  <div class="meta-row">
                    <span class="meta-label">标签:</span>
                    <div class="meta-tags">
                      <span 
                        v-for="tag in selectedContent.tags" 
                        :key="tag" 
                        class="tag"
                        :class="getTagClass(tag)"
                      >
                        {{ tag }}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div class="detail-stats">
                  <div class="stat-card">
                    <div class="stat-icon">👁️</div>
                    <div class="stat-info">
                      <div class="stat-value">{{ formatNumber(selectedContent.views) }}</div>
                      <div class="stat-label">浏览量</div>
                    </div>
                  </div>
                  <div class="stat-card">
                    <div class="stat-icon">👍</div>
                    <div class="stat-info">
                      <div class="stat-value">{{ formatNumber(selectedContent.likes) }}</div>
                      <div class="stat-label">点赞数</div>
                    </div>
                  </div>
                  <div class="stat-card">
                    <div class="stat-icon">📤</div>
                    <div class="stat-info">
                      <div class="stat-value">{{ formatNumber(selectedContent.shares) }}</div>
                      <div class="stat-label">分享数</div>
                    </div>
                  </div>
                  <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-info">
                      <div class="stat-value">{{ selectedContent.readRate }}%</div>
                      <div class="stat-label">阅读率</div>
                    </div>
                  </div>
                  <div class="stat-card">
                    <div class="stat-icon">🎯</div>
                    <div class="stat-info">
                      <div class="stat-value">{{ selectedContent.conversionRate }}%</div>
                      <div class="stat-label">转化率</div>
                    </div>
                  </div>
                  <div class="stat-card">
                    <div class="stat-icon">🔗</div>
                    <div class="stat-info">
                      <div class="stat-value">{{ selectedContent.usedInCampaigns }}</div>
                      <div class="stat-label">被引用次数</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="cancel-btn" @click="showContentDetailModal = false">关闭</button>
          <button class="confirm-btn" @click="editContent(selectedContent)">编辑内容</button>
        </div>
      </div>
    </div>

    <!-- 编辑内容模态框 -->
    <div v-if="showEditContentModal" class="modal-overlay" @click="showEditContentModal = false">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>编辑内容</h3>
          <button class="close-btn" @click="showEditContentModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>内容标题</label>
            <input v-model="editContentData.title" type="text" placeholder="输入内容标题" />
          </div>
          <div class="form-group">
            <label>内容描述</label>
            <textarea v-model="editContentData.description" placeholder="输入内容描述" rows="3"></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>内容类型</label>
              <select v-model="editContentData.type">
                <option value="article">文章</option>
                <option value="image">图片</option>
                <option value="video">视频</option>
                <option value="template">模板</option>
              </select>
            </div>
            <div class="form-group">
              <label>作者</label>
              <input v-model="editContentData.author" type="text" placeholder="输入作者姓名" />
            </div>
          </div>
          <div class="form-group">
            <label>标签</label>
            <div class="tag-selector">
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="营销" />
                <span>营销</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="产品" />
                <span>产品</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="品牌" />
                <span>品牌</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="教程" />
                <span>教程</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="案例" />
                <span>案例</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="分析" />
                <span>分析</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="模板" />
                <span>模板</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="新品" />
                <span>新品</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="春季" />
                <span>春季</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="海报" />
                <span>海报</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="视频" />
                <span>视频</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="节日" />
                <span>节日</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="分享" />
                <span>分享</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="editContentData.tags" value="报告" />
                <span>报告</span>
              </label>
            </div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="cancel-btn" @click="showEditContentModal = false">取消</button>
          <button class="confirm-btn" @click="saveEditContent">保存修改</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'

// 页面状态
const searchQuery = ref('')
const statusFilter = ref('all')
const sortBy = ref('createTime')
const currentCategory = ref('all')
const selectedQuickTag = ref('')
const showCreateContentModal = ref(false)
const showImportModal = ref(false)
const showContentDetailModal = ref(false)
const showEditContentModal = ref(false)
const selectedContent = ref(null)

const editContentData = reactive({
  title: '',
  description: '',
  type: 'article',
  author: '',
  tags: []
})

// 快捷标签
const quickTags = ['高转化', '新手必备', '节日限定', '爆款', '推荐用于活动']

// 内容热力榜数据
const contentHeatmap = reactive([
  {
    id: 'H001',
    title: '限时折扣攻略',
    type: '图文',
    conversionRate: 18.7,
    usedCount: 5,
    trend: 'up',
    trendText: '↑12%'
  },
  {
    id: 'H002',
    title: '产品对比视频',
    type: '视频',
    conversionRate: 15.2,
    usedCount: 3,
    trend: 'stable',
    trendText: '→'
  },
  {
    id: 'H003',
    title: '新手入门指南',
    type: '图文',
    conversionRate: 14.8,
    usedCount: 8,
    trend: 'up',
    trendText: '↑8%'
  },
  {
    id: 'H004',
    title: '品牌故事海报',
    type: '图片',
    conversionRate: 12.3,
    usedCount: 2,
    trend: 'down',
    trendText: '↓3%'
  },
  {
    id: 'H005',
    title: '节日营销模板',
    type: '模板',
    conversionRate: 11.9,
    usedCount: 12,
    trend: 'up',
    trendText: '↑15%'
  }
])

// 内容健康度数据
const healthData = reactive({
  needOptimize: 3,
  expired: 2
})

// 智能推荐数据
const smartRecommendations = reactive([
  {
    id: 'R001',
    icon: '📈',
    title: '优化低效内容',
    description: '3篇内容阅读率低于40%，建议优化标题和封面'
  },
  {
    id: 'R002',
    icon: '🎯',
    title: '创建节日内容',
    description: '距离春节还有30天，建议准备节日营销素材'
  },
  {
    id: 'R003',
    icon: '📊',
    title: '分析热门内容',
    description: '查看热力榜TOP5，了解高转化内容的共同特征'
  }
])

// 概览数据
const overviewData = reactive({
  totalContents: 1247,
  publishedContents: 892,
  draftContents: 245,
  templates: 110,
  totalViews: 1258470,
  avgEngagement: 8.5,
  conversionRate: 12.1
})

// 内容数据
const contents = reactive([
  {
    id: 'C001',
    title: '春季新品推广文案',
    description: '针对春季新品的营销推广文案，包含产品特性和优惠信息',
    preview: new URL('../assets/Spring.jpg', import.meta.url).href,
    type: 'article',
    status: 'published',
    statusText: '已发布',
    createTime: '2024-01-15',
    author: '张三',
    tags: ['营销', '新品', '春季'],
    views: 1250,
    likes: 89,
    shares: 23,
    readRate: 82,
    conversionRate: 15.2,
    usedInCampaigns: 3,
    isHot: true,
    isHighConversion: true
  },
  {
    id: 'C002',
    title: '品牌形象海报设计',
    description: '公司品牌形象宣传海报，突出品牌理念和价值观',
    preview: new URL('../assets/brand.jpg', import.meta.url).href,
    type: 'image',
    status: 'draft',
    statusText: '草稿',
    createTime: '2024-01-14',
    author: '李四',
    tags: ['品牌', '设计', '海报'],
    views: 0,
    likes: 0,
    shares: 0,
    readRate: 0,
    conversionRate: 0,
    usedInCampaigns: 0,
    isHot: false,
    isHighConversion: false
  },
  {
    id: 'C003',
    title: '产品使用教程视频',
    description: '详细的产品使用教程视频，帮助用户快速上手',
    preview: new URL('../assets/product.jpg', import.meta.url).href,
    type: 'video',
    status: 'review',
    statusText: '审核中',
    createTime: '2024-01-13',
    author: '王五',
    tags: ['教程', '产品', '视频'],
    views: 0,
    likes: 0,
    shares: 0,
    readRate: 0,
    conversionRate: 0,
    usedInCampaigns: 0,
    isHot: false,
    isHighConversion: false
  },
  {
    id: 'C004',
    title: '节日营销模板',
    description: '通用节日营销模板，可快速生成节日相关营销内容',
    preview: new URL('../assets/festival.jpg', import.meta.url).href,
    type: 'template',
    status: 'published',
    statusText: '已发布',
    createTime: '2024-01-12',
    author: '赵六',
    tags: ['模板', '节日', '营销'],
    views: 2340,
    likes: 156,
    shares: 45,
    readRate: 78,
    conversionRate: 12.5,
    usedInCampaigns: 12,
    isHot: true,
    isHighConversion: false
  },
  {
    id: 'C005',
    title: '客户案例分享',
    description: '成功客户案例分享，展示产品价值和客户满意度',
    preview: new URL('../assets/customer.jpg', import.meta.url).href,
    type: 'article',
    status: 'published',
    statusText: '已发布',
    createTime: '2024-01-11',
    author: '张三',
    tags: ['案例', '客户', '分享'],
    views: 1890,
    likes: 134,
    shares: 67,
    readRate: 65,
    conversionRate: 8.7,
    usedInCampaigns: 2,
    isHot: false,
    isHighConversion: false
  },
  {
    id: 'C006',
    title: '行业分析报告',
    description: '深度行业分析报告，包含市场趋势和机会分析',
    preview: new URL('../assets/analysis.jpg', import.meta.url).href,
    type: 'article',
    status: 'draft',
    statusText: '草稿',
    createTime: '2024-01-10',
    author: '李四',
    tags: ['分析', '行业', '报告'],
    views: 0,
    likes: 0,
    shares: 0,
    readRate: 0,
    conversionRate: 0,
    usedInCampaigns: 0,
    isHot: false,
    isHighConversion: false
  }
])

// 新增内容数据
const newContent = reactive({
  title: '',
  description: '',
  type: 'article',
  author: '',
  tags: []
})

// 计算属性
const filteredContents = computed(() => {
  return contents.filter(content => {
    const matchesSearch = content.title.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                         content.description.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                         content.author.toLowerCase().includes(searchQuery.value.toLowerCase())
    const matchesCategory = currentCategory.value === 'all' || content.type === currentCategory.value
    const matchesStatus = statusFilter.value === 'all' || content.status === statusFilter.value
    const matchesQuickTag = !selectedQuickTag.value || content.tags.includes(selectedQuickTag.value)
    return matchesSearch && matchesCategory && matchesStatus && matchesQuickTag
  }).sort((a, b) => {
    switch (sortBy.value) {
      case 'readRate':
        return b.readRate - a.readRate
      case 'conversionRate':
        return b.conversionRate - a.conversionRate
      case 'usedCount':
        return b.usedInCampaigns - a.usedInCampaigns
      default:
        return new Date(b.createTime) - new Date(a.createTime)
    }
  })
})

const totalContents = computed(() => contents.length)
const articleCount = computed(() => contents.filter(c => c.type === 'article').length)
const videoCount = computed(() => contents.filter(c => c.type === 'video').length)
const templateCount = computed(() => contents.filter(c => c.type === 'template').length)

// 方法
const formatNumber = (num) => {
  return num.toLocaleString()
}

const getTypeText = (type) => {
  const typeMap = {
    article: '文章',
    image: '图片',
    video: '视频',
    template: '模板'
  }
  return typeMap[type] || '未知'
}

const getTagClass = (tag) => {
  const classMap = {
    '营销': 'marketing',
    '产品': 'product',
    '品牌': 'brand',
    '教程': 'tutorial',
    '案例': 'case',
    '分析': 'analysis',
    '模板': 'template',
    '新品': 'new',
    '春季': 'season',
    '海报': 'poster',
    '视频': 'video',
    '节日': 'festival',
    '分享': 'share',
    '报告': 'report'
  }
  return classMap[tag] || 'default'
}

const showContentDetail = (content) => {
  console.log('查看内容详情:', content)
}

const viewDetail = (content) => {
  console.log('查看详情:', content)
  showContentDetailModal.value = true
  selectedContent.value = content
}

const editContent = (content) => {
  console.log('编辑内容:', content)
  Object.assign(editContentData, {
    title: content.title,
    description: content.description,
    type: content.type,
    author: content.author,
    tags: [...content.tags]
  })
  selectedContent.value = content
  showEditContentModal.value = true
}

const saveEditContent = () => {
  if (selectedContent.value && editContentData.title && editContentData.description) {
    Object.assign(selectedContent.value, {
      title: editContentData.title,
      description: editContentData.description,
      type: editContentData.type,
      author: editContentData.author,
      tags: [...editContentData.tags]
    })
    Object.assign(editContentData, {
      title: '',
      description: '',
      type: 'article',
      author: '',
      tags: []
    })
    selectedContent.value = null
    showEditContentModal.value = false
  }
}

const performSearch = () => {
  console.log('执行搜索:', searchQuery.value)
  // 搜索逻辑已经在 computed 中实现，这里可以添加额外的搜索功能
}

const toggleStatus = (content) => {
  if (content.status === 'published') {
    content.status = 'draft'
    content.statusText = '草稿'
  } else {
    content.status = 'published'
    content.statusText = '已发布'
  }
  console.log('切换内容状态:', content)
}

const batchOperation = () => {
  console.log('批量操作')
}

const exportContents = () => {
  console.log('导出内容数据')
}

const createContent = () => {
  if (newContent.title && newContent.description) {
    const contentData = {
      id: `C${String(contents.length + 1).padStart(3, '0')}`,
      title: newContent.title,
      description: newContent.description,
      preview: 'https://via.placeholder.com/300x200',
      type: newContent.type,
      status: 'draft',
      statusText: '草稿',
      createTime: new Date().toISOString().split('T')[0],
      author: newContent.author || '当前用户',
      tags: [...newContent.tags],
      views: 0,
      likes: 0,
      shares: 0
    }
    contents.unshift(contentData)
    
    // 重置表单
    Object.assign(newContent, {
      title: '',
      description: '',
      type: 'article',
      author: '',
      tags: []
    })
    showCreateContentModal.value = false
  }
}

const handleFileUpload = (event) => {
  const file = event.target.files[0]
  console.log('上传文件:', file)
}

const importContents = () => {
  console.log('导入内容数据')
  showImportModal.value = false
}

// 新增方法
const setCategory = (category) => {
  currentCategory.value = category
}

const toggleQuickTag = (tag) => {
  selectedQuickTag.value = selectedQuickTag.value === tag ? '' : tag
}

const showCreateModal = (type) => {
  newContent.type = type
  showCreateContentModal.value = true
}

const cloneContent = (content) => {
  const clonedContent = {
    ...content,
    id: `C${String(contents.length + 1).padStart(3, '0')}`,
    title: `${content.title}的副本_${new Date().toISOString().slice(0, 10)}`,
    status: 'draft',
    statusText: '草稿',
    createTime: new Date().toISOString().split('T')[0],
    views: 0,
    likes: 0,
    shares: 0,
    readRate: 0,
    conversionRate: 0,
    usedInCampaigns: 0,
    isHot: false,
    isHighConversion: false
  }
  contents.unshift(clonedContent)
  console.log('内容克隆成功:', clonedContent)
}

const showAnalytics = (content) => {
  console.log('显示内容分析:', content)
  // 这里可以显示详细的数据分析弹窗
}

const applyRecommendation = (recommendation) => {
  console.log('应用推荐:', recommendation)
  // 根据推荐类型执行相应操作
}
</script>

<style scoped>
.content-management-container {
  padding: 24px;
  background: #F8FAFC;
  min-height: 100vh;
}

/* 页面标题和工具栏 */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}

.header-left {
  text-align: center;
  flex: 1;
}

.header-left h1 {
  font-size: 28px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.header-left p {
  color: #718096;
  margin: 0;
}

.header-controls {
  display: flex;
  gap: 16px;
  align-items: center;
}

.import-btn, .export-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.import-btn {
  background: #4F46E5;
  color: white;
}

.export-btn {
  background: #10B981;
  color: white;
}

.btn-icon {
  font-size: 16px;
}

/* 内容库导航 */
.content-navigation {
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin-bottom: 24px;
  border: 1px solid #E2E8F0;
}

.nav-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  gap: 20px;
}

.search-section {
  flex: 1;
  max-width: 300px;
  display: flex;
  gap: 8px;
}

.search-input {
  flex: 1;
  padding: 12px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
}

.search-input:focus {
  border-color: #4F46E5;
}

.search-btn {
  padding: 12px 16px;
  background: #4F46E5;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
  display: flex;
  align-items: center;
  gap: 6px;
}

.search-btn:hover {
  background: #3730A3;
}

.search-btn .btn-icon {
  font-size: 16px;
}

.quick-filters {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.quick-tag {
  padding: 6px 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  background: white;
  color: #4A5568;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.quick-tag:hover {
  background: #F7FAFC;
}

.quick-tag.active {
  background: #4F46E5;
  color: white;
  border-color: #4F46E5;
}

.category-nav {
  display: flex;
  gap: 20px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  border: 1px solid transparent;
}

.nav-item:hover {
  background: #F7FAFC;
}

.nav-item.active {
  background: #4F46E5;
  color: white;
}

.nav-icon {
  font-size: 16px;
}

.count {
  background: rgba(255, 255, 255, 0.2);
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 12px;
  margin-left: auto;
}

/* 内容工厂工具栏 */
.content-factory-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin-bottom: 24px;
  border: 1px solid #E2E8F0;
}

.factory-section {
  display: flex;
  gap: 12px;
}

.factory-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  background: white;
  color: #4A5568;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
}

.factory-btn:hover {
  background: #F7FAFC;
  border-color: #4F46E5;
  color: #4F46E5;
}

.filter-section {
  display: flex;
  gap: 12px;
}

.search-section {
  flex: 1;
  max-width: 300px;
}

.search-input {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
}

.search-input:focus {
  border-color: #4F46E5;
}

.filter-section {
  display: flex;
  gap: 12px;
}

.filter-select {
  padding: 12px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  background: white;
  font-size: 14px;
  color: #1A202C;
}

.add-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #10B981;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
}

.add-btn:hover {
  background: #059669;
}

/* 效能分析板 */
.performance-dashboard {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 24px;
  margin-bottom: 32px;
}

.dashboard-left {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.dashboard-right {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.content-heatmap h3,
.content-health h3,
.smart-recommendations h3 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 16px 0;
}

.heatmap-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.heatmap-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  background: #F7FAFC;
  border: 1px solid #E2E8F0;
}

.rank {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: #4F46E5;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
}

.heatmap-item:nth-child(1) .rank {
  background: #F59E0B;
}

.heatmap-item:nth-child(2) .rank {
  background: #6B7280;
}

.heatmap-item:nth-child(3) .rank {
  background: #D97706;
}

.content-info {
  flex: 1;
}

.content-title {
  font-size: 14px;
  font-weight: 600;
  color: #1A202C;
  margin-bottom: 4px;
}

.content-meta {
  display: flex;
  gap: 12px;
  font-size: 12px;
  color: #718096;
}

.performance {
  text-align: right;
}

.conversion-rate {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

.trend {
  font-size: 12px;
  font-weight: 500;
}

.trend.up {
  color: #10B981;
}

.trend.down {
  color: #DC2626;
}

.trend.stable {
  color: #6B7280;
}

.content-health {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.health-stats {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.health-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  border-radius: 8px;
  border: 1px solid #E2E8F0;
}

.health-item.warning {
  background: #FEF3C7;
  border-color: #F59E0B;
}

.health-item.danger {
  background: #FDE8E8;
  border-color: #DC2626;
}

.health-icon {
  font-size: 20px;
}

.health-info {
  flex: 1;
}

.health-count {
  font-size: 20px;
  font-weight: 700;
  color: #1A202C;
  margin-bottom: 4px;
}

.health-label {
  font-size: 14px;
  font-weight: 500;
  color: #1A202C;
  margin-bottom: 2px;
}

.health-desc {
  font-size: 12px;
  color: #718096;
}

.smart-recommendations {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.recommendation-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.recommendation-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  background: #F7FAFC;
  border: 1px solid #E2E8F0;
}

.rec-icon {
  font-size: 20px;
}

.rec-content {
  flex: 1;
}

.rec-title {
  font-size: 14px;
  font-weight: 600;
  color: #1A202C;
  margin-bottom: 4px;
}

.rec-desc {
  font-size: 12px;
  color: #718096;
  line-height: 1.4;
}

.rec-action {
  padding: 6px 12px;
  border: 1px solid #4F46E5;
  border-radius: 6px;
  background: white;
  color: #4F46E5;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.rec-action:hover {
  background: #4F46E5;
  color: white;
}

.status-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 24px;
}

.status-card {
  display: flex;
  align-items: center;
  gap: 16px;
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.status-icon {
  font-size: 24px;
}

.status-info {
  flex: 1;
}

.status-count {
  font-size: 24px;
  font-weight: 700;
  color: #1A202C;
  margin-bottom: 4px;
}

.status-label {
  font-size: 14px;
  color: #718096;
}

.metrics-cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.metric-card {
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.metric-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.metric-label {
  font-size: 14px;
  color: #718096;
}

.metric-trend {
  font-size: 12px;
  font-weight: 500;
  padding: 4px 8px;
  border-radius: 6px;
}

.metric-trend.positive {
  background: #DEF7EC;
  color: #03543F;
}

.metric-value {
  font-size: 28px;
  font-weight: 700;
  color: #1A202C;
  margin-bottom: 4px;
}

/* 内容列表 */
.content-list-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.list-header h2 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.batch-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #4F46E5;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
}

.content-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 20px;
}

.content-card {
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  padding: 20px;
  background: #F8FAFC;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}

.content-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.card-header {
  margin-bottom: 16px;
}

.content-preview {
  position: relative;
  height: 150px;
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 12px;
}

.content-preview img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.content-status {
  position: absolute;
  top: 8px;
  right: 8px;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.content-status.published {
  background: #DEF7EC;
  color: #03543F;
}

.content-status.draft {
  background: #FEF3C7;
  color: #92400E;
}

.content-status.review {
  background: #DBEAFE;
  color: #1E40AF;
}

.smart-badges {
  position: absolute;
  top: 8px;
  left: 8px;
  display: flex;
  gap: 4px;
}

.badge {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  backdrop-filter: blur(4px);
}

.badge.hot {
  background: rgba(220, 38, 38, 0.9);
  color: white;
}

.badge.conversion {
  background: rgba(245, 158, 11, 0.9);
  color: white;
}

.badge.linked {
  background: rgba(79, 70, 229, 0.9);
  color: white;
}

.content-type {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.content-type.article {
  background: #E0E7FF;
  color: #3730A3;
}

.content-type.image {
  background: #FEF3C7;
  color: #92400E;
}

.content-type.video {
  background: #FDE8E8;
  color: #9B1C1C;
}

.content-type.template {
  background: #DEF7EC;
  color: #03543F;
}

.content-title {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
  line-height: 1.4;
}

.content-description {
  font-size: 14px;
  color: #718096;
  margin: 0 0 16px 0;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.content-meta {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #718096;
}

.meta-icon {
  font-size: 16px;
}

.content-tags {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.tag {
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.tag.marketing {
  background: #DEF7EC;
  color: #03543F;
}

.tag.product {
  background: #DBEAFE;
  color: #1E40AF;
}

.tag.brand {
  background: #FEF3C7;
  color: #92400E;
}

.tag.tutorial {
  background: #FDE8E8;
  color: #9B1C1C;
}

.tag.case {
  background: #E0E7FF;
  color: #3730A3;
}

.tag.analysis {
  background: #F3E8FF;
  color: #581C87;
}

.tag.template {
  background: #FEF3C7;
  color: #92400E;
}

.tag.new {
  background: #DEF7EC;
  color: #03543F;
}

.tag.season {
  background: #FEF3C7;
  color: #92400E;
}

.tag.poster {
  background: #DBEAFE;
  color: #1E40AF;
}

.tag.video {
  background: #FDE8E8;
  color: #9B1C1C;
}

.tag.festival {
  background: #FEF3C7;
  color: #92400E;
}

.tag.share {
  background: #DEF7EC;
  color: #03543F;
}

.tag.report {
  background: #F3E8FF;
  color: #581C87;
}

.tag.default {
  background: #E5E7EB;
  color: #374151;
}

.content-stats {
  display: flex;
  gap: 20px;
  margin-bottom: 16px;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.stat-label {
  font-size: 12px;
  color: #718096;
  margin-bottom: 4px;
}

.stat-value {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

.card-actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  padding: 6px 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  background: white;
  color: #4A5568;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.action-btn:hover {
  background: #F7FAFC;
}

.action-btn.secondary {
  border-color: #4F46E5;
  color: #4F46E5;
}

.action-btn.warning {
  border-color: #DC2626;
  color: #DC2626;
}

.action-btn.success {
  border-color: #10B981;
  color: #10B981;
}

.action-btn.clone {
  border-color: #8B5CF6;
  color: #8B5CF6;
}

.action-btn.analytics {
  border-color: #F59E0B;
  color: #F59E0B;
}

/* 模态框 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  border-bottom: 1px solid #E2E8F0;
}

.modal-header h3 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  color: #718096;
  cursor: pointer;
}

.modal-body {
  padding: 24px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  font-size: 14px;
  font-weight: 500;
  color: #4A5568;
  margin-bottom: 8px;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
}

.form-group textarea {
  resize: vertical;
  min-height: 80px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.tag-selector {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}

.tag-option {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.modal-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  padding: 24px;
  border-top: 1px solid #E2E8F0;
}

.cancel-btn, .confirm-btn {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
}

.cancel-btn {
  background: #E2E8F0;
  color: #4A5568;
}

.confirm-btn {
  background: #4F46E5;
  color: white;
}

.upload-area {
  border: 2px dashed #E2E8F0;
  border-radius: 8px;
  padding: 40px;
  text-align: center;
  margin-bottom: 20px;
}

.upload-icon {
  font-size: 48px;
  margin-bottom: 16px;
}

.upload-area p {
  color: #718096;
  margin: 0;
}

.upload-area input[type="file"] {
  display: none;
}

.import-tips {
  background: #F7FAFC;
  border-radius: 8px;
  padding: 16px;
}

.import-tips h4 {
  font-size: 14px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.import-tips ul {
  margin: 0;
  padding-left: 20px;
  color: #718096;
  font-size: 14px;
}

.import-tips li {
  margin-bottom: 4px;
}

/* 内容详情模态框 */
.content-detail-modal {
  max-width: 800px;
}

.detail-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}

.detail-left {
  display: flex;
    flex-direction: column;
}

.content-preview-large {
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  margin-bottom: 16px;
}

.content-preview-large img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.detail-right {
  display: flex;
  flex-direction: column;
}

.detail-info {
  flex: 1;
}

.detail-title {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 12px 0;
}

.detail-description {
  font-size: 14px;
  color: #718096;
  line-height: 1.6;
  margin: 0 0 20px 0;
}

.detail-meta {
  margin-bottom: 24px;
}

.meta-row {
  display: flex;
  align-items: center;
  margin-bottom: 12px;
}

.meta-label {
  font-weight: 500;
  color: #4A5568;
  min-width: 80px;
  margin-right: 12px;
}

.meta-value {
  color: #1A202C;
}

.meta-tags {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.detail-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.stat-card {
  background: #F7FAFC;
  border-radius: 8px;
  padding: 16px;
  text-align: center;
  border: 1px solid #E2E8F0;
}

.stat-icon {
  font-size: 24px;
  margin-bottom: 8px;
}

.stat-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.stat-value {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
}

.stat-label {
  font-size: 12px;
  color: #718096;
}

@media (max-width: 1024px) {
  .performance-dashboard {
    grid-template-columns: 1fr;
  }
  
  .category-nav {
    flex-wrap: wrap;
  }
  
  .content-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .header-controls {
    width: 100%;
    justify-content: center;
  }
  
  .nav-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .quick-filters {
    justify-content: center;
  }
  
  .category-nav {
    flex-direction: column;
    gap: 8px;
  }
  
  .content-factory-toolbar {
    flex-direction: column;
    gap: 16px;
  }
  
  .factory-section {
    justify-content: center;
  }
  
  .filter-section {
    justify-content: center;
  }
  
  .form-row {
    grid-template-columns: 1fr;
  }
  
  .tag-selector {
    flex-direction: column;
    gap: 8px;
  }
  
  .detail-grid {
    grid-template-columns: 1fr;
  }
  
  .detail-stats {
    grid-template-columns: 1fr;
  }
}
</style>
