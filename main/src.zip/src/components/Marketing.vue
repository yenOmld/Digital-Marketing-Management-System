<template>
  <div class="marketing-container">
    <!-- 页面标题和工具栏 -->
    <div class="page-header">
      <div class="header-left">
      <h1>营销活动</h1>
        <p>基于数据分析创建精准营销活动，监控活动效果</p>
      </div>
      <div class="header-controls">
        <button class="template-btn" @click="showTemplateModal = true">
          <span class="btn-icon">📋</span>
          模板库
        </button>
        <button class="simulator-btn" @click="showSimulator = true">
          <span class="btn-icon">🎯</span>
          活动模拟器
        </button>
      </div>
    </div>
    
    <!-- 筛选控制区 -->
    <div class="filter-toolbar">
      <div class="search-section">
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="搜索活动名称"
          class="search-input"
        />
          </div>
      <div class="filter-section">
        <select v-model="statusFilter" class="filter-select">
          <option value="all">全部状态</option>
          <option value="active">进行中</option>
          <option value="pending">未开始</option>
          <option value="ended">已结束</option>
        </select>
        <select v-model="typeFilter" class="filter-select">
          <option value="all">全部类型</option>
          <option value="promotion">促销</option>
          <option value="notification">通知</option>
          <option value="recall">召回</option>
        </select>
          </div>
      <button class="create-btn" @click="showCreateWizard = true">
        <span class="btn-icon">+</span>
        新建活动
      </button>
    </div>

    <!-- 活动看板 -->
    <div class="dashboard-section">
      <div class="status-cards">
        <div class="status-card active">
          <div class="status-icon">✅</div>
          <div class="status-info">
            <div class="status-count">{{ overviewData.activeCount }}</div>
            <div class="status-label">进行中活动</div>
          </div>
        </div>
        <div class="status-card pending">
          <div class="status-icon">⏳</div>
          <div class="status-info">
            <div class="status-count">{{ overviewData.pendingCount }}</div>
            <div class="status-label">未开始活动</div>
          </div>
        </div>
        <div class="status-card ended">
          <div class="status-icon">📊</div>
          <div class="status-info">
            <div class="status-count">{{ overviewData.endedCount }}</div>
            <div class="status-label">已结束活动</div>
          </div>
        </div>
      </div>
      
      <div class="metrics-cards">
        <div class="metric-card">
          <div class="metric-header">
            <span class="metric-label">参与人数</span>
            <span class="metric-trend positive">↑8%</span>
          </div>
          <div class="metric-value">{{ formatNumber(overviewData.participants) }}</div>
        </div>
        <div class="metric-card">
          <div class="metric-header">
            <span class="metric-label">平均转化率</span>
            <span class="metric-trend positive">↑2.1%</span>
          </div>
          <div class="metric-value">{{ overviewData.avgConversionRate }}%</div>
        </div>
        <div class="metric-card">
          <div class="metric-header">
            <span class="metric-label">ROI</span>
            <span class="metric-trend positive">↑0.3</span>
          </div>
          <div class="metric-value">{{ overviewData.roi }}</div>
          <div class="metric-subtitle">每投入1元赚取{{ overviewData.roi }}元</div>
          </div>
        </div>
      </div>

      <!-- 活动列表 -->
    <div class="activity-list-section">
      <div class="list-header">
        <h2>活动列表</h2>
        <div class="list-actions">
          <button class="batch-btn" @click="batchOperation">
            <span class="btn-icon">📋</span>
            批量操作
          </button>
        </div>
              </div>
      
      <div class="activity-grid">
        <div 
          v-for="activity in filteredActivities" 
          :key="activity.id"
          class="activity-card"
          :class="activity.type"
          @click="showActivityDetail(activity)"
        >
          <div class="card-header">
            <div class="activity-type">{{ getActivityTypeText(activity.type) }}</div>
            <div class="status-indicator" :class="activity.status"></div>
            </div>
          
          <div class="card-content">
            <h3 class="activity-title">{{ activity.name }}</h3>
            <div class="activity-meta">
              <span class="meta-item">
                <span class="meta-icon">📅</span>
                {{ activity.dateRange }}
              </span>
              <span class="meta-item">
                <span class="meta-icon">📱</span>
                {{ activity.channels.join('+') }}
              </span>
              <span class="meta-item">
                <span class="meta-icon">👥</span>
                {{ formatNumber(activity.participants) }}人参与
              </span>
              </div>
            
            <div class="activity-stats">
              <div class="stat-item">
                <span class="stat-label">转化率</span>
                <span class="stat-value">{{ activity.conversionRate }}%</span>
              </div>
              <div class="stat-item">
                <span class="stat-label">ROI</span>
                <span class="stat-value">{{ activity.roi }}</span>
            </div>
            </div>
          </div>
          
          <div class="card-actions">
            <button class="action-btn" @click.stop="viewDetail(activity)">
              查看详情
            </button>
            <button class="action-btn secondary" @click.stop="copyActivity(activity)">
              复制活动
            </button>
            <button 
              :class="['action-btn', activity.status === 'active' ? 'warning' : 'success']"
              @click.stop="toggleActivity(activity)"
            >
              {{ activity.status === 'active' ? '暂停' : '启动' }}
            </button>
              </div>
            </div>
              </div>
              </div>

    <!-- 活动创建向导 -->
    <div v-if="showCreateWizard" class="wizard-modal">
      <div class="wizard-content">
        <div class="wizard-header">
          <h2>创建营销活动</h2>
          <button class="close-btn" @click="showCreateWizard = false">×</button>
            </div>
        
        <div class="wizard-steps">
          <div class="step-indicator">
            <div 
              v-for="(step, index) in wizardSteps" 
              :key="index"
              :class="['step', { active: currentStep === index, completed: currentStep > index }]"
            >
              {{ step.title }}
            </div>
          </div>
          
          <div class="step-content">
            <!-- 步骤1：基础设置 -->
            <div v-if="currentStep === 0" class="step-panel">
              <h3>基础设置</h3>
              <div class="form-group">
                <label>活动名称</label>
                <input v-model="newActivity.name" type="text" placeholder="输入活动名称" />
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>开始时间</label>
                  <input v-model="newActivity.startDate" type="date" />
            </div>
                <div class="form-group">
                  <label>结束时间</label>
                  <input v-model="newActivity.endDate" type="date" />
              </div>
              </div>
              <div class="form-group">
                <label>投放渠道</label>
                <div class="channel-selector">
                  <label class="channel-option">
                    <input type="checkbox" v-model="newActivity.channels" value="APP" />
                    <span>APP</span>
                  </label>
                  <label class="channel-option">
                    <input type="checkbox" v-model="newActivity.channels" value="微信" />
                    <span>微信</span>
                  </label>
                  <label class="channel-option">
                    <input type="checkbox" v-model="newActivity.channels" value="短信" />
                    <span>短信</span>
                  </label>
            </div>
              </div>
            </div>
            
            <!-- 步骤2：选择受众 -->
            <div v-if="currentStep === 1" class="step-panel">
              <h3>选择受众</h3>
              <div class="audience-selector">
                <div 
                  v-for="audience in audienceOptions" 
                  :key="audience.id"
                  :class="['audience-option', { selected: newActivity.audience.includes(audience.id) }]"
                  @click="toggleAudience(audience.id)"
                >
                  <div class="audience-info">
                    <h4>{{ audience.name }}</h4>
                    <p>{{ audience.description }}</p>
                    <span class="audience-count">{{ formatNumber(audience.count) }}人</span>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- 步骤3：配置内容 -->
            <div v-if="currentStep === 2" class="step-panel">
              <h3>配置内容</h3>
              <div class="template-selector">
                <div 
                  v-for="template in contentTemplates" 
                  :key="template.id"
                  :class="['template-option', { selected: newActivity.template === template.id }]"
                  @click="selectTemplate(template.id)"
                >
                  <div class="template-icon">{{ template.icon }}</div>
                  <div class="template-info">
                    <h4>{{ template.name }}</h4>
                    <p>{{ template.description }}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="wizard-actions">
            <button 
              v-if="currentStep > 0" 
              class="prev-btn" 
              @click="previousStep"
            >
              上一步
            </button>
            <button 
              v-if="currentStep < 2" 
              class="next-btn" 
              @click="nextStep"
            >
              下一步
            </button>
            <button 
              v-if="currentStep === 2" 
              class="create-btn" 
              @click="createActivity"
            >
              创建活动
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 模板库模态框 -->
    <div v-if="showTemplateModal" class="modal-overlay" @click="showTemplateModal = false">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>活动模板库</h3>
          <button class="close-btn" @click="showTemplateModal = false">×</button>
        </div>
        <div class="template-grid">
          <div 
            v-for="template in activityTemplates" 
            :key="template.id"
            class="template-card"
            @click="applyTemplate(template)"
          >
            <div class="template-header">
              <div class="template-icon">{{ template.icon }}</div>
              <div class="template-type">{{ template.type }}</div>
            </div>
            <h4>{{ template.name }}</h4>
            <p>{{ template.description }}</p>
            <div class="template-stats">
              <span>平均转化率: {{ template.avgConversion }}%</span>
              <span>平均ROI: {{ template.avgRoi }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 活动模拟器 -->
    <div v-if="showSimulator" class="modal-overlay" @click="showSimulator = false">
      <div class="modal-content simulator-modal" @click.stop>
        <div class="modal-header">
          <h3>活动效果模拟器</h3>
          <button class="close-btn" @click="showSimulator = false">×</button>
        </div>
        <div class="simulator-content">
          <div class="simulator-controls">
            <div class="control-group">
              <label>预算 (元)</label>
              <input v-model="simulatorData.budget" type="number" min="1000" step="1000" />
            </div>
            <div class="control-group">
              <label>预期参与率 (%)</label>
              <input v-model="simulatorData.participationRate" type="number" min="1" max="100" />
            </div>
            <div class="control-group">
              <label>预期转化率 (%)</label>
              <input v-model="simulatorData.conversionRate" type="number" min="1" max="100" />
            </div>
            <button class="simulate-btn" @click="runSimulation">
              <span class="btn-icon">🎯</span>
              立即测试
            </button>
          </div>
          
          <div class="simulation-results">
            <div class="result-card">
              <h4>预测结果</h4>
              <div class="result-stats">
                <div class="result-item">
                  <span class="result-label">参与人数</span>
                  <span class="result-value">{{ simulationResults.participants }}</span>
                </div>
                <div class="result-item">
                  <span class="result-label">转化人数</span>
                  <span class="result-value">{{ simulationResults.conversions }}</span>
                </div>
                <div class="result-item">
                  <span class="result-label">预期收入</span>
                  <span class="result-value">¥{{ formatNumber(simulationResults.revenue) }}</span>
                </div>
                <div class="result-item">
                  <span class="result-label">ROI</span>
                  <span class="result-value">{{ simulationResults.roi }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 活动详情模态框 -->
    <div v-if="showDetailModal" class="modal-overlay" @click="closeDetailModal">
      <div class="modal-content detail-modal" @click.stop>
        <div class="modal-header">
          <h3>
            <span class="activity-type-badge" :class="selectedActivity?.type">
              {{ getActivityTypeText(selectedActivity?.type) }}
            </span>
            {{ selectedActivity?.name }}
          </h3>
          <button class="close-btn" @click="closeDetailModal">×</button>
        </div>
        
        <div class="detail-content">
          <!-- 活动概览 -->
          <div class="detail-section">
            <h4>活动概览</h4>
            <div class="overview-grid">
              <div class="overview-item">
                <div class="overview-icon status" :class="selectedActivity?.status">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M8 14s1.5 2 4 2 4-2 4-2"/>
                    <path d="M9 9h.01"/>
                    <path d="M15 9h.01"/>
                  </svg>
                </div>
                <div class="overview-info">
                  <div class="overview-label">活动状态</div>
                  <div class="overview-value">{{ getStatusText(selectedActivity?.status) }}</div>
                </div>
              </div>
              
              <div class="overview-item">
                <div class="overview-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                    <line x1="16" y1="2" x2="16" y2="6"/>
                    <line x1="8" y1="2" x2="8" y2="6"/>
                    <line x1="3" y1="10" x2="21" y2="10"/>
                  </svg>
                </div>
                <div class="overview-info">
                  <div class="overview-label">活动周期</div>
                  <div class="overview-value">{{ selectedActivity?.dateRange }}</div>
                </div>
              </div>
              
              <div class="overview-item">
                <div class="overview-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                  </svg>
                </div>
                <div class="overview-info">
                  <div class="overview-label">参与人数</div>
                  <div class="overview-value">{{ formatNumber(selectedActivity?.participants || 0) }}</div>
                </div>
              </div>
              
              <div class="overview-item">
                <div class="overview-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="17,8 12,3 7,8"/>
                    <line x1="12" y1="3" x2="12" y2="15"/>
                  </svg>
                </div>
                <div class="overview-info">
                  <div class="overview-label">投放渠道</div>
                  <div class="overview-value">{{ selectedActivity?.channels?.join(' + ') }}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- 核心指标 -->
          <div class="detail-section">
            <h4>核心指标</h4>
            <div class="metrics-grid">
              <div class="metric-card detailed">
                <div class="metric-header">
                  <div class="metric-icon conversion">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
                    </svg>
                  </div>
                  <div class="metric-info">
                    <div class="metric-label">转化率</div>
                    <div class="metric-value">{{ selectedActivity?.conversionRate || 0 }}%</div>
                  </div>
                </div>
                <div class="metric-chart">
                  <div class="chart-bar">
                    <div class="chart-fill" :style="{ width: (selectedActivity?.conversionRate || 0) + '%' }"></div>
                  </div>
                  <div class="chart-label">目标: 15%</div>
                </div>
              </div>
              
              <div class="metric-card detailed">
                <div class="metric-header">
                  <div class="metric-icon roi">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <line x1="12" y1="1" x2="12" y2="23"/>
                      <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                  </div>
                  <div class="metric-info">
                    <div class="metric-label">ROI</div>
                    <div class="metric-value">{{ selectedActivity?.roi || 0 }}</div>
                  </div>
                </div>
                <div class="metric-chart">
                  <div class="chart-bar">
                    <div class="chart-fill roi" :style="{ width: Math.min((selectedActivity?.roi || 0) * 33, 100) + '%' }"></div>
                  </div>
                  <div class="chart-label">目标: 2.5</div>
                </div>
              </div>
              
              <div class="metric-card detailed">
                <div class="metric-header">
                  <div class="metric-icon cost">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <circle cx="12" cy="12" r="10"/>
                      <path d="M16 8l-4 4-4-4"/>
                    </svg>
                  </div>
                  <div class="metric-info">
                    <div class="metric-label">获客成本</div>
                    <div class="metric-value">¥{{ calculateCPA(selectedActivity) }}</div>
                  </div>
                </div>
                <div class="metric-description">
                  平均每获得一个客户的成本
                </div>
              </div>
            </div>
          </div>

          <!-- 渠道分析 -->
          <div class="detail-section">
            <h4>渠道分析</h4>
            <div class="channel-analysis">
              <div v-for="channel in selectedActivity?.channels" :key="channel" class="channel-item">
                <div class="channel-header">
                  <div class="channel-name">{{ channel }}</div>
                  <div class="channel-performance" :class="getChannelPerformance(channel)">
                    {{ getChannelPerformanceText(channel) }}
                  </div>
                </div>
                <div class="channel-stats">
                  <div class="channel-stat">
                    <span class="stat-label">曝光量</span>
                    <span class="stat-value">{{ formatNumber(getChannelExposure(channel)) }}</span>
                  </div>
                  <div class="channel-stat">
                    <span class="stat-label">点击率</span>
                    <span class="stat-value">{{ getChannelCTR(channel) }}%</span>
                  </div>
                  <div class="channel-stat">
                    <span class="stat-label">转化数</span>
                    <span class="stat-value">{{ getChannelConversions(channel) }}</span>
                  </div>
                </div>
                <div class="channel-progress">
                  <div class="progress-bar">
                    <div class="progress-fill" :style="{ width: getChannelCTR(channel) * 5 + '%' }"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- 时间趋势 -->
          <div class="detail-section">
            <h4>效果趋势</h4>
            <div class="trend-chart">
              <div class="chart-container">
                <svg width="100%" height="200" viewBox="0 0 400 200">
                  <!-- 网格线 -->
                  <g stroke="#E2E8F0" stroke-width="1">
                    <line x1="40" y1="20" x2="40" y2="180"/>
                    <line x1="40" y1="180" x2="380" y2="180"/>
                    <line x1="40" y1="140" x2="380" y2="140"/>
                    <line x1="40" y1="100" x2="380" y2="100"/>
                    <line x1="40" y1="60" x2="380" y2="60"/>
                  </g>
                  <!-- 趋势线 -->
                  <polyline
                    points="60,160 100,140 140,120 180,100 220,90 260,85 300,80 340,75"
                    fill="none"
                    stroke="#4F46E5"
                    stroke-width="3"
                  />
                  <!-- 数据点 -->
                  <circle cx="60" cy="160" r="4" fill="#4F46E5"/>
                  <circle cx="100" cy="140" r="4" fill="#4F46E5"/>
                  <circle cx="140" cy="120" r="4" fill="#4F46E5"/>
                  <circle cx="180" cy="100" r="4" fill="#4F46E5"/>
                  <circle cx="220" cy="90" r="4" fill="#4F46E5"/>
                  <circle cx="260" cy="85" r="4" fill="#4F46E5"/>
                  <circle cx="300" cy="80" r="4" fill="#4F46E5"/>
                  <circle cx="340" cy="75" r="4" fill="#4F46E5"/>
                </svg>
              </div>
              <div class="chart-legend">
                <div class="legend-item">
                  <div class="legend-dot" style="background: #4F46E5;"></div>
                  <span>转化率趋势</span>
                </div>
              </div>
            </div>
          </div>

          <!-- 操作历史 -->
          <div class="detail-section">
            <h4>操作历史</h4>
            <div class="activity-timeline">
              <div class="timeline-item">
                <div class="timeline-dot active"></div>
                <div class="timeline-content">
                  <div class="timeline-title">活动启动</div>
                  <div class="timeline-desc">{{ selectedActivity?.dateRange?.split('-')[0] }} 活动正式开始投放</div>
                  <div class="timeline-time">2小时前</div>
                </div>
              </div>
              <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                  <div class="timeline-title">规则调整</div>
                  <div class="timeline-desc">优化了目标受众筛选条件</div>
                  <div class="timeline-time">1天前</div>
                </div>
              </div>
              <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                  <div class="timeline-title">活动创建</div>
                  <div class="timeline-desc">完成活动配置和审核</div>
                  <div class="timeline-time">3天前</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="detail-footer">
          <button class="btn-secondary" @click="editActivity(selectedActivity)">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
            编辑活动
          </button>
          <button class="btn-secondary" @click="duplicateActivity(selectedActivity)">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
            </svg>
            复制活动
          </button>
          <button 
            :class="['btn-primary', selectedActivity?.status === 'active' ? 'warning' : 'success']"
            @click="toggleActivityStatus(selectedActivity)"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polygon points="5,3 19,12 5,21 5,3"/>
            </svg>
            {{ selectedActivity?.status === 'active' ? '暂停活动' : '启动活动' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'

// 页面状态
const searchQuery = ref('')
const statusFilter = ref('all')
const typeFilter = ref('all')
const showCreateWizard = ref(false)
const showTemplateModal = ref(false)
const showSimulator = ref(false)
const showDetailModal = ref(false)
const currentStep = ref(0)
const selectedActivity = ref(null)

// 概览数据
const overviewData = reactive({
  activeCount: 3,
  pendingCount: 2,
  endedCount: 5,
  participants: 1245,
  avgConversionRate: 12.8,
  roi: 2.5
})

// 活动数据
const activities = reactive([
  {
    id: 1,
    name: '夏季大促',
    type: 'promotion',
    status: 'active',
    dateRange: '08/01-08/15',
    channels: ['APP', '微信'],
    participants: 1240,
    conversionRate: 15.2,
    roi: 2.8
  },
  {
    id: 2,
    name: '新品通知',
    type: 'notification',
    status: 'active',
    dateRange: '08/10-08/25',
    channels: ['APP', '短信'],
    participants: 856,
    conversionRate: 8.5,
    roi: 1.5
  },
  {
    id: 3,
    name: '用户召回',
    type: 'recall',
    status: 'pending',
    dateRange: '08/20-09/05',
    channels: ['微信', '短信'],
    participants: 0,
    conversionRate: 0,
    roi: 0
  },
  {
    id: 4,
    name: '双11预热',
    type: 'promotion',
    status: 'ended',
    dateRange: '07/15-07/30',
    channels: ['APP', '微信', '短信'],
    participants: 2156,
    conversionRate: 18.5,
    roi: 3.2
  }
])

// 创建向导数据
const wizardSteps = reactive([
  { title: '基础设置' },
  { title: '选择受众' },
  { title: '配置内容' }
])

const newActivity = reactive({
  name: '',
  startDate: '',
  endDate: '',
  channels: [],
  audience: [],
  template: ''
})

// 受众选项
const audienceOptions = reactive([
  { id: 'new_users', name: '新用户', description: '注册时间少于30天的用户', count: 1250 },
  { id: 'high_value', name: '高价值用户', description: '消费金额前20%的用户', count: 320 },
  { id: 'inactive', name: '休眠用户', description: '30天未活跃的用户', count: 890 },
  { id: 'tech_lovers', name: '科技爱好者', description: '偏好科技类内容的用户', count: 456 }
])

// 内容模板
const contentTemplates = reactive([
  { id: 'promotion', icon: '🎉', name: '促销模板', description: '适用于节日促销、限时优惠等活动' },
  { id: 'notification', icon: '📢', name: '通知模板', description: '适用于新品发布、功能更新等通知' },
  { id: 'recall', icon: '💝', name: '召回模板', description: '适用于用户召回、会员关怀等活动' }
])

// 活动模板库
const activityTemplates = reactive([
  {
    id: 1,
    icon: '🎊',
    type: '节日促销',
    name: '双11大促模板',
    description: '适用于大型购物节促销活动',
    avgConversion: 15.2,
    avgRoi: 2.8
  },
  {
    id: 2,
    icon: '🚀',
    type: '新品通知',
    name: '科技新品发布',
    description: '适用于科技产品新品发布',
    avgConversion: 8.5,
    avgRoi: 1.5
  },
  {
    id: 3,
    icon: '💝',
    type: '用户召回',
    name: '温情召回模板',
    description: '适用于用户召回和关怀活动',
    avgConversion: 12.3,
    avgRoi: 2.1
  }
])

// 模拟器数据
const simulatorData = reactive({
  budget: 10000,
  participationRate: 15,
  conversionRate: 8
})

const simulationResults = reactive({
  participants: 0,
  conversions: 0,
  revenue: 0,
  roi: 0
})

// 计算属性
const filteredActivities = computed(() => {
  return activities.filter(activity => {
    const matchesSearch = activity.name.toLowerCase().includes(searchQuery.value.toLowerCase())
    const matchesStatus = statusFilter.value === 'all' || activity.status === statusFilter.value
    const matchesType = typeFilter.value === 'all' || activity.type === typeFilter.value
    return matchesSearch && matchesStatus && matchesType
  })
})

// 方法
const getActivityTypeText = (type) => {
  const types = {
    promotion: '促销',
    notification: '通知',
    recall: '召回'
  }
  return types[type] || type
}

const formatNumber = (num) => {
  return num.toLocaleString()
}

const showActivityDetail = (activity) => {
  selectedActivity.value = activity
  showDetailModal.value = true
}

const viewDetail = (activity) => {
  selectedActivity.value = activity
  showDetailModal.value = true
}

const copyActivity = (activity) => {
  console.log('复制活动:', activity)
  // 复制活动配置到新建向导
  Object.assign(newActivity, {
    name: activity.name + ' (副本)',
    channels: [...activity.channels],
    template: activity.type
  })
  showCreateWizard.value = true
}

const toggleActivity = (activity) => {
  activity.status = activity.status === 'active' ? 'paused' : 'active'
  console.log('切换活动状态:', activity)
}

const batchOperation = () => {
  console.log('批量操作')
}

const toggleAudience = (audienceId) => {
  const index = newActivity.audience.indexOf(audienceId)
  if (index > -1) {
    newActivity.audience.splice(index, 1)
  } else {
    newActivity.audience.push(audienceId)
  }
}

const selectTemplate = (templateId) => {
  newActivity.template = templateId
}

const nextStep = () => {
  if (currentStep.value < 2) {
    currentStep.value++
  }
}

const previousStep = () => {
  if (currentStep.value > 0) {
    currentStep.value--
  }
}

const createActivity = () => {
  console.log('创建活动:', newActivity)
  // 添加新活动到列表
  const newActivityData = {
    id: Date.now(),
    name: newActivity.name,
    type: newActivity.template,
    status: 'pending',
    dateRange: `${newActivity.startDate} - ${newActivity.endDate}`,
    channels: newActivity.channels,
    participants: 0,
    conversionRate: 0,
    roi: 0
  }
  activities.unshift(newActivityData)
  
  // 重置表单
  Object.assign(newActivity, {
    name: '',
    startDate: '',
    endDate: '',
    channels: [],
    audience: [],
    template: ''
  })
  currentStep.value = 0
  showCreateWizard.value = false
}

const applyTemplate = (template) => {
  console.log('应用模板:', template)
  // 应用模板配置到新建向导
  newActivity.template = template.type === '节日促销' ? 'promotion' : 
                        template.type === '新品通知' ? 'notification' : 'recall'
  showTemplateModal.value = false
  showCreateWizard.value = true
}

const runSimulation = () => {
  const { budget, participationRate, conversionRate } = simulatorData
  const totalUsers = 10000 // 假设总用户数
  const participants = Math.floor(totalUsers * (participationRate / 100))
  const conversions = Math.floor(participants * (conversionRate / 100))
  const revenue = conversions * 200 // 假设平均客单价200元
  const roi = revenue / budget

  Object.assign(simulationResults, {
    participants,
    conversions,
    revenue,
    roi: roi.toFixed(2)
  })
  
  console.log('模拟结果:', simulationResults)
}

// 详情模态框相关方法
const closeDetailModal = () => {
  showDetailModal.value = false
  selectedActivity.value = null
}

const getStatusText = (status) => {
  const statusMap = {
    active: '进行中',
    pending: '未开始',
    ended: '已结束',
    paused: '已暂停'
  }
  return statusMap[status] || status
}

const calculateCPA = (activity) => {
  if (!activity || !activity.participants) return '0'
  const estimatedCost = 5000 // 假设成本
  return Math.round(estimatedCost / activity.participants)
}

// 渠道分析相关方法
const getChannelExposure = (channel) => {
  const exposureMap = {
    'APP': 45000,
    '微信': 32000,
    '短信': 18000
  }
  return exposureMap[channel] || 10000
}

const getChannelCTR = (channel) => {
  const ctrMap = {
    'APP': 8.5,
    '微信': 12.3,
    '短信': 5.2
  }
  return ctrMap[channel] || 6.0
}

const getChannelConversions = (channel) => {
  const conversionMap = {
    'APP': 156,
    '微信': 234,
    '短信': 89
  }
  return conversionMap[channel] || 50
}

const getChannelPerformance = (channel) => {
  const ctr = getChannelCTR(channel)
  if (ctr > 10) return 'excellent'
  if (ctr > 7) return 'good'
  return 'average'
}

const getChannelPerformanceText = (channel) => {
  const performance = getChannelPerformance(channel)
  const textMap = {
    excellent: '表现优秀',
    good: '表现良好',
    average: '表现一般'
  }
  return textMap[performance] || '表现一般'
}

// 详情页面操作方法
const editActivity = (activity) => {
  console.log('编辑活动:', activity)
  closeDetailModal()
  // 可以在这里打开编辑模态框或跳转到编辑页面
}

const duplicateActivity = (activity) => {
  console.log('复制活动:', activity)
  closeDetailModal()
  copyActivity(activity)
}

const toggleActivityStatus = (activity) => {
  if (activity) {
    activity.status = activity.status === 'active' ? 'paused' : 'active'
    console.log('切换活动状态:', activity)
  }
}
</script>

<style scoped>
.marketing-container {
  padding: 24px;
  background: #F8FAFC;
  min-height: 100vh;
}

/* 页面标题和工具栏 */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}

.header-left {
  text-align: center;
  flex: 1;
}

.header-left h1 {
  font-size: 28px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.header-left p {
  color: #718096;
  margin: 0;
}

.header-controls {
  display: flex;
  gap: 16px;
  align-items: center;
}

.template-btn, .simulator-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.template-btn {
  background: #4F46E5;
  color: white;
}

.simulator-btn {
  background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
  color: white;
}

.btn-icon {
  font-size: 16px;
}

/* 筛选控制区 */
.filter-toolbar {
  display: flex;
  gap: 24px;
  align-items: center;
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin-bottom: 24px;
}

.search-section {
  flex: 1;
  max-width: 300px;
}

.search-input {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
}

.search-input:focus {
  border-color: #4F46E5;
}

.filter-section {
  display: flex;
  gap: 12px;
}

.filter-select {
  padding: 12px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  background: white;
  font-size: 14px;
  color: #1A202C;
}

.create-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #10B981;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
}

.create-btn:hover {
  background: #059669;
}

/* 活动看板 */
.dashboard-section {
  margin-bottom: 32px;
}

.status-cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
  margin-bottom: 24px;
}

.status-card {
  display: flex;
  align-items: center;
  gap: 16px;
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.status-icon {
  font-size: 24px;
}

.status-info {
  flex: 1;
}

.status-count {
  font-size: 24px;
  font-weight: 700;
  color: #1A202C;
  margin-bottom: 4px;
}

.status-label {
  font-size: 14px;
  color: #718096;
}

.metrics-cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.metric-card {
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.metric-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.metric-label {
  font-size: 14px;
  color: #718096;
}

.metric-trend {
  font-size: 12px;
  font-weight: 500;
  padding: 4px 8px;
  border-radius: 6px;
}

.metric-trend.positive {
  background: #DEF7EC;
  color: #03543F;
}

.metric-value {
  font-size: 28px;
  font-weight: 700;
  color: #1A202C;
  margin-bottom: 4px;
}

.metric-subtitle {
  font-size: 12px;
  color: #A0AEC0;
}

/* 活动列表 */
.activity-list-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.list-header h2 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.batch-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #4F46E5;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
}

.activity-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 20px;
}

.activity-card {
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  padding: 20px;
  background: #F8FAFC;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}

.activity-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.activity-card.promotion {
  border-left: 4px solid #F59E0B;
}

.activity-card.notification {
  border-left: 4px solid #4F46E5;
}

.activity-card.recall {
  border-left: 4px solid #10B981;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.activity-type {
  font-size: 12px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 6px;
  background: #E2E8F0;
  color: #4A5568;
}

.status-indicator {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}

.status-indicator.active {
  background: #10B981;
}

.status-indicator.pending {
  background: #F59E0B;
}

.status-indicator.ended {
  background: #6B7280;
}

.activity-title {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 12px 0;
}

.activity-meta {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #718096;
}

.meta-icon {
  font-size: 16px;
}

.activity-stats {
  display: flex;
  gap: 20px;
  margin-bottom: 16px;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.stat-label {
  font-size: 12px;
  color: #718096;
  margin-bottom: 4px;
}

.stat-value {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

.card-actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  padding: 6px 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  background: white;
  color: #4A5568;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.action-btn:hover {
  background: #F7FAFC;
}

.action-btn.secondary {
  border-color: #4F46E5;
  color: #4F46E5;
}

.action-btn.warning {
  border-color: #DC2626;
  color: #DC2626;
}

.action-btn.success {
  border-color: #10B981;
  color: #10B981;
}

/* 创建向导 */
.wizard-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.wizard-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 600px;
  max-height: 80vh;
  overflow-y: auto;
}

.wizard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  border-bottom: 1px solid #E2E8F0;
}

.wizard-header h2 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  color: #718096;
  cursor: pointer;
}

.wizard-steps {
  padding: 24px;
}

.step-indicator {
  display: flex;
  justify-content: space-between;
  margin-bottom: 32px;
}

.step {
  flex: 1;
  text-align: center;
  padding: 12px;
  border-radius: 8px;
  font-size: 14px;
  color: #718096;
  background: #F7FAFC;
  margin: 0 4px;
}

.step.active {
  background: #4F46E5;
  color: white;
}

.step.completed {
  background: #10B981;
  color: white;
}

.step-content {
  margin-bottom: 24px;
}

.step-panel h3 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 20px 0;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  font-size: 14px;
  font-weight: 500;
  color: #4A5568;
  margin-bottom: 8px;
}

.form-group input {
  width: 100%;
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.channel-selector {
  display: flex;
  gap: 16px;
}

.channel-option {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.audience-selector {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.audience-option {
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  padding: 16px;
  cursor: pointer;
  transition: all 0.2s;
}

.audience-option.selected {
  border-color: #4F46E5;
  background: #EBF4FF;
}

.audience-info h4 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.audience-info p {
  font-size: 14px;
  color: #718096;
  margin: 0 0 8px 0;
}

.audience-count {
  font-size: 12px;
  color: #4F46E5;
  font-weight: 500;
}

.template-selector {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
}

.template-option {
  display: flex;
  align-items: center;
  gap: 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  padding: 16px;
  cursor: pointer;
  transition: all 0.2s;
}

.template-option.selected {
  border-color: #4F46E5;
  background: #EBF4FF;
}

.template-icon {
  font-size: 24px;
}

.template-info h4 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 4px 0;
}

.template-info p {
  font-size: 14px;
  color: #718096;
  margin: 0;
}

.wizard-actions {
  display: flex;
  justify-content: space-between;
  gap: 16px;
}

.prev-btn, .next-btn, .create-btn {
  padding: 12px 24px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}

.prev-btn {
  background: #E2E8F0;
  color: #4A5568;
}

.next-btn, .create-btn {
  background: #4F46E5;
  color: white;
}

/* 模态框 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 800px;
  max-height: 80vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  border-bottom: 1px solid #E2E8F0;
}

.modal-header h3 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.template-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  padding: 24px;
}

.template-card {
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  padding: 20px;
  cursor: pointer;
  transition: all 0.2s;
}

.template-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.template-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.template-icon {
  font-size: 24px;
}

.template-type {
  font-size: 12px;
  color: #718096;
  padding: 4px 8px;
  background: #F7FAFC;
  border-radius: 4px;
}

.template-card h4 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.template-card p {
  font-size: 14px;
  color: #718096;
  margin: 0 0 12px 0;
}

.template-stats {
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 12px;
  color: #A0AEC0;
}

/* 模拟器 */
.simulator-modal {
  max-width: 600px;
}

.simulator-content {
  padding: 24px;
}

.simulator-controls {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  margin-bottom: 24px;
}

.control-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.control-group label {
  font-size: 14px;
  font-weight: 500;
  color: #4A5568;
}

.control-group input {
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
}

.simulate-btn {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
  color: white;
  border: none;
  padding: 12px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}

.simulation-results {
  background: #F7FAFC;
  border-radius: 8px;
  padding: 20px;
}

.result-card h4 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 16px 0;
}

.result-stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.result-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.result-label {
  font-size: 14px;
  color: #718096;
}

.result-value {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

@media (max-width: 1024px) {
  .status-cards {
    grid-template-columns: 1fr;
  }
  
  .metrics-cards {
    grid-template-columns: 1fr;
  }
  
  .activity-grid {
    grid-template-columns: 1fr;
  }
  
  .audience-selector {
    grid-template-columns: 1fr;
  }
  
  .simulator-controls {
    grid-template-columns: 1fr;
  }
  
  .result-stats {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .header-controls {
    width: 100%;
    justify-content: center;
  }
  
  .filter-toolbar {
    flex-direction: column;
    gap: 16px;
  }
  
  .filter-section {
    width: 100%;
    justify-content: space-between;
  }
  
  .form-row {
    grid-template-columns: 1fr;
  }
  
  .channel-selector {
    flex-direction: column;
    gap: 8px;
  }
}

/* 活动详情模态框 */
.detail-modal {
  max-width: 1000px;
  max-height: 90vh;
}

.activity-type-badge {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
  margin-right: 12px;
}

.activity-type-badge.promotion {
  background: #FEF3C7;
  color: #92400E;
}

.activity-type-badge.notification {
  background: #EBF4FF;
  color: #3730A3;
}

.activity-type-badge.recall {
  background: #DEF7EC;
  color: #03543F;
}

.detail-content {
  padding: 24px;
  max-height: 60vh;
  overflow-y: auto;
}

.detail-section {
  margin-bottom: 32px;
}

.detail-section:last-child {
  margin-bottom: 0;
}

.detail-section h4 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 20px 0;
  padding-bottom: 8px;
  border-bottom: 2px solid #E2E8F0;
}

/* 活动概览 */
.overview-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
}

.overview-item {
  display: flex;
  align-items: center;
  gap: 16px;
  background: #F7FAFC;
  padding: 20px;
  border-radius: 12px;
  border: 1px solid #E2E8F0;
}

.overview-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: #4F46E5;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
}

.overview-icon.status.active {
  background: #10B981;
}

.overview-icon.status.pending {
  background: #F59E0B;
}

.overview-icon.status.ended {
  background: #6B7280;
}

.overview-info {
  flex: 1;
}

.overview-label {
  font-size: 14px;
  color: #718096;
  margin-bottom: 4px;
}

.overview-value {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
}

/* 详细指标卡片 */
.metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
}

.metric-card.detailed {
  background: white;
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.metric-card.detailed .metric-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 16px;
}

.metric-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.metric-icon.conversion {
  background: linear-gradient(135deg, #667EEA, #764BA2);
}

.metric-icon.roi {
  background: linear-gradient(135deg, #F093FB, #F5576C);
}

.metric-icon.cost {
  background: linear-gradient(135deg, #4FACFE, #00F2FE);
}

.metric-info {
  flex: 1;
}

.metric-card.detailed .metric-label {
  font-size: 14px;
  color: #718096;
  margin-bottom: 4px;
}

.metric-card.detailed .metric-value {
  font-size: 28px;
  font-weight: 700;
  color: #1A202C;
}

.metric-chart {
  margin-top: 16px;
}

.chart-bar {
  height: 8px;
  background: #E2E8F0;
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 8px;
}

.chart-fill {
  height: 100%;
  background: #4F46E5;
  border-radius: 4px;
  transition: width 0.3s ease;
}

.chart-fill.roi {
  background: linear-gradient(90deg, #F093FB, #F5576C);
}

.chart-label {
  font-size: 12px;
  color: #A0AEC0;
}

.metric-description {
  font-size: 12px;
  color: #718096;
  margin-top: 8px;
}

/* 渠道分析 */
.channel-analysis {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.channel-item {
  background: white;
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  padding: 20px;
}

.channel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.channel-name {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

.channel-performance {
  padding: 4px 12px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
}

.channel-performance.excellent {
  background: #DEF7EC;
  color: #03543F;
}

.channel-performance.good {
  background: #DBEAFE;
  color: #1E40AF;
}

.channel-performance.average {
  background: #FEF3C7;
  color: #92400E;
}

.channel-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  margin-bottom: 16px;
}

.channel-stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.channel-stat .stat-label {
  font-size: 12px;
  color: #718096;
  margin-bottom: 4px;
}

.channel-stat .stat-value {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

.channel-progress {
  margin-top: 12px;
}

.progress-bar {
  height: 6px;
  background: #E2E8F0;
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #4F46E5, #7C3AED);
  border-radius: 3px;
  transition: width 0.3s ease;
}

/* 趋势图表 */
.trend-chart {
  background: white;
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  padding: 20px;
}

.chart-container {
  margin-bottom: 16px;
}

.chart-legend {
  display: flex;
  justify-content: center;
  gap: 20px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #718096;
}

.legend-dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}

/* 操作历史时间线 */
.activity-timeline {
  position: relative;
  padding-left: 32px;
}

.activity-timeline::before {
  content: '';
  position: absolute;
  left: 12px;
  top: 0;
  bottom: 0;
  width: 2px;
  background: #E2E8F0;
}

.timeline-item {
  position: relative;
  margin-bottom: 24px;
}

.timeline-item:last-child {
  margin-bottom: 0;
}

.timeline-dot {
  position: absolute;
  left: -20px;
  top: 4px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #E2E8F0;
  border: 2px solid white;
}

.timeline-dot.active {
  background: #10B981;
}

.timeline-content {
  background: white;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  padding: 16px;
}

.timeline-title {
  font-size: 14px;
  font-weight: 600;
  color: #1A202C;
  margin-bottom: 4px;
}

.timeline-desc {
  font-size: 14px;
  color: #718096;
  margin-bottom: 8px;
}

.timeline-time {
  font-size: 12px;
  color: #A0AEC0;
}

/* 详情页面底部操作 */
.detail-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 24px;
  border-top: 1px solid #E2E8F0;
  background: #F7FAFC;
}

.btn-secondary {
  display: flex;
  align-items: center;
  gap: 8px;
  background: white;
  color: #4A5568;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  padding: 10px 16px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-secondary:hover {
  background: #F7FAFC;
  border-color: #CBD5E0;
}

.btn-primary {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #4F46E5;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 10px 16px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-primary:hover {
  background: #4338CA;
}

.btn-primary.warning {
  background: #DC2626;
}

.btn-primary.warning:hover {
  background: #B91C1C;
}

.btn-primary.success {
  background: #10B981;
}

.btn-primary.success:hover {
  background: #059669;
}

/* 响应式适配 */
@media (max-width: 768px) {
  .detail-modal {
    width: 95%;
    margin: 20px;
  }
  
  .overview-grid {
    grid-template-columns: 1fr;
  }
  
  .metrics-grid {
    grid-template-columns: 1fr;
  }
  
  .channel-stats {
    grid-template-columns: 1fr;
    gap: 12px;
  }
  
  .detail-footer {
    flex-direction: column;
  }
  
  .btn-secondary,
  .btn-primary {
    justify-content: center;
  }
}
</style>
