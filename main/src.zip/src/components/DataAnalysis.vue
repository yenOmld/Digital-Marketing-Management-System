<template>
  <div class="data-analysis-container">
    <!-- 页面标题和工具栏 -->
    <div class="page-header">
      <div class="header-left">
        <h1>数据分析</h1>
        <p>实时监控业务指标和用户行为</p>
      </div>
      <div class="header-controls">
        <div class="data-mode-toggle">
          <button 
            :class="['mode-btn', { active: dataMode === 'real' }]"
            @click="setDataMode('real')"
          >
            真实数据
          </button>
          <button 
            :class="['mode-btn', { active: dataMode === 'demo' }]"
            @click="setDataMode('demo')"
          >
            演示数据
          </button>
        </div>
        <button class="optimize-btn" @click="optimizeData">
          <span class="btn-icon">⚡</span>
          立即优化
        </button>
      </div>
    </div>

    <!-- 筛选控制区 -->
    <div class="filter-toolbar">
      <div class="filter-group">
        <label>时间范围：</label>
        <select v-model="timeRange" @change="updateData">
          <option value="today">今日</option>
          <option value="7days">7天</option>
          <option value="30days">30天</option>
        </select>
      </div>
      <div class="filter-group">
        <label>渠道筛选：</label>
        <select v-model="channelFilter" @change="updateData">
          <option value="all">全选</option>
          <option value="social">社交媒体</option>
          <option value="search">搜索引擎</option>
        </select>
      </div>
      <button class="refresh-btn" @click="refreshData">
        <span class="btn-icon">🔄</span>
        刷新
      </button>
    </div>

    <!-- 快速洞察提示 -->
    <div v-if="insights.length > 0" class="insights-panel">
      <div class="insight-item" v-for="insight in insights" :key="insight.id">
        <span class="insight-icon">💡</span>
        <span class="insight-text">{{ insight.message }}</span>
      </div>
    </div>

    <!-- 概览仪表盘 -->
    <div class="overview-dashboard">
      <div class="metric-card">
        <div class="metric-header">
          <h3>访问量</h3>
          <span class="metric-trend positive">+15.2%</span>
        </div>
        <div class="metric-value">{{ formatNumber(overviewData.visits) }}</div>
        <div class="metric-subtitle">今日访问量</div>
        <div class="metric-total">累计：{{ formatNumber(overviewData.totalVisits) }}</div>
      </div>

      <div class="metric-card">
        <div class="metric-header">
          <h3>转化率</h3>
          <span class="metric-trend positive">+8.3%</span>
        </div>
        <div class="metric-value">{{ overviewData.conversionRate }}%</div>
        <div class="metric-subtitle">当前转化率</div>
        <div class="metric-change">较昨日：+2.1%</div>
      </div>

      <div class="metric-card">
        <div class="metric-header">
          <h3>热门渠道</h3>
          <span class="metric-trend positive">+12.5%</span>
        </div>
        <div class="metric-value">{{ overviewData.topChannel.name }}</div>
        <div class="metric-subtitle">TOP1渠道</div>
        <div class="metric-percentage">占比：{{ overviewData.topChannel.percentage }}%</div>
      </div>

      <div class="metric-card">
        <div class="metric-header">
          <h3>内容热度</h3>
          <span class="metric-trend positive">+18.7%</span>
        </div>
        <div class="metric-value">{{ overviewData.topContent.type }}</div>
        <div class="metric-subtitle">最受欢迎内容</div>
        <div class="metric-views">{{ formatNumber(overviewData.topContent.views) }}次浏览</div>
      </div>
    </div>

    <!-- 流量分析 -->
    <div class="traffic-analysis">
      <div class="chart-section">
        <div class="section-header">
          <h2>流量趋势</h2>
          <div class="chart-controls">
            <button 
              :class="['time-btn', { active: timeUnit === 'day' }]"
              @click="setTimeUnit('day')"
            >
              天
            </button>
            <button 
              :class="['time-btn', { active: timeUnit === 'week' }]"
              @click="setTimeUnit('week')"
            >
              周
            </button>
          </div>
        </div>
        <div class="chart-container">
          <div class="line-chart">
            <svg width="100%" height="200" viewBox="0 0 400 200">
              <defs>
                <linearGradient id="lineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" style="stop-color:#4F46E5;stop-opacity:0.3" />
                  <stop offset="100%" style="stop-color:#4F46E5;stop-opacity:0.1" />
                </linearGradient>
              </defs>
              <path 
                d="M20,150 L80,120 L140,100 L200,80 L260,90 L320,60 L380,70" 
                stroke="#4F46E5" 
                stroke-width="3" 
                fill="none"
                class="trend-line"
              />
              <path 
                d="M20,150 L80,120 L140,100 L200,80 L260,90 L320,60 L380,70 L380,200 L20,200 Z" 
                fill="url(#lineGradient)"
              />
              <circle cx="80" cy="120" r="4" fill="#4F46E5" class="data-point" />
              <circle cx="140" cy="100" r="4" fill="#4F46E5" class="data-point" />
              <circle cx="200" cy="80" r="4" fill="#4F46E5" class="data-point" />
              <circle cx="260" cy="90" r="4" fill="#4F46E5" class="data-point" />
              <circle cx="320" cy="60" r="4" fill="#4F46E5" class="data-point" />
              <circle cx="380" cy="70" r="4" fill="#4F46E5" class="data-point" />
            </svg>
          </div>
        </div>
      </div>

      <div class="chart-section">
        <div class="section-header">
          <h2>渠道来源</h2>
        </div>
        <div class="chart-container">
          <div class="pie-chart">
            <svg width="150" height="150" viewBox="0 0 200 200">
              <circle cx="100" cy="100" r="80" fill="none" stroke="#E5E7EB" stroke-width="16"/>
              <circle cx="100" cy="100" r="80" fill="none" stroke="#4F46E5" stroke-width="16" 
                      stroke-dasharray="251.2" stroke-dashoffset="75.36" transform="rotate(-90 100 100)"/>
              <circle cx="100" cy="100" r="80" fill="none" stroke="#10B981" stroke-width="16" 
                      stroke-dasharray="251.2" stroke-dashoffset="150.72" transform="rotate(-90 100 100)"/>
              <circle cx="100" cy="100" r="80" fill="none" stroke="#F59E0B" stroke-width="16" 
                      stroke-dasharray="251.2" stroke-dashoffset="188.4" transform="rotate(-90 100 100)"/>
              <circle cx="100" cy="100" r="80" fill="none" stroke="#EF4444" stroke-width="16" 
                      stroke-dasharray="251.2" stroke-dashoffset="226.08" transform="rotate(-90 100 100)"/>
            </svg>
            <div class="pie-legend">
              <div class="legend-item">
                <span class="legend-color" style="background: #4F46E5"></span>
                <span>搜索引擎 (40%)</span>
              </div>
              <div class="legend-item">
                <span class="legend-color" style="background: #10B981"></span>
                <span>社交媒体 (30%)</span>
              </div>
              <div class="legend-item">
                <span class="legend-color" style="background: #F59E0B"></span>
                <span>直接访问 (15%)</span>
              </div>
              <div class="legend-item">
                <span class="legend-color" style="background: #EF4444"></span>
                <span>其他 (15%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="chart-section">
        <div class="section-header">
          <h2>设备分布</h2>
        </div>
        <div class="chart-container">
          <div class="device-distribution">
            <div class="device-item">
              <div class="device-icon">📱</div>
              <div class="device-info">
                <div class="device-name">移动端</div>
                <div class="device-percentage">{{ deviceData.mobile }}%</div>
              </div>
              <div class="device-bar">
                <div class="bar-fill" :style="{ width: deviceData.mobile + '%' }"></div>
              </div>
            </div>
            <div class="device-item">
              <div class="device-icon">💻</div>
              <div class="device-info">
                <div class="device-name">PC端</div>
                <div class="device-percentage">{{ deviceData.desktop }}%</div>
              </div>
              <div class="device-bar">
                <div class="bar-fill" :style="{ width: deviceData.desktop + '%' }"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 转化漏斗 -->
    <div class="conversion-funnel">
      <div class="section-header">
        <h2>转化漏斗</h2>
        <button class="export-btn" @click="exportData">
          <span class="btn-icon">📊</span>
          导出CSV
        </button>
      </div>
      <div class="funnel-container">
        <div class="funnel-stage" :class="{ 'loss-point': stage.loss }" v-for="stage in funnelData" :key="stage.name">
          <div class="stage-header">
            <h3>{{ stage.name }}</h3>
            <span class="stage-count">{{ formatNumber(stage.count) }}</span>
          </div>
          <div class="stage-bar">
            <div class="bar-fill" :style="{ width: stage.percentage + '%' }"></div>
          </div>
          <div class="stage-info">
            <span class="conversion-rate">{{ stage.conversionRate }}%</span>
            <span v-if="stage.loss" class="loss-indicator">⚠️ 关键流失点</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 内容效果 -->
    <div class="content-performance">
      <div class="section-header">
        <h2>内容排行榜</h2>
        <button class="screenshot-btn" @click="takeScreenshot">
          <span class="btn-icon">📸</span>
          截图分享
        </button>
      </div>
      <div class="content-table">
        <table>
          <thead>
            <tr>
              <th>内容标题</th>
              <th>浏览量</th>
              <th>转化率</th>
              <th>趋势</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="content in contentData" :key="content.id">
              <td>{{ content.title }}</td>
              <td>{{ formatNumber(content.views) }}</td>
              <td :class="{ 'low-conversion': content.conversionRate < 5 }">
                {{ content.conversionRate }}%
              </td>
              <td>
                <span :class="['trend-indicator', content.trend]">
                  {{ content.trend === 'up' ? '↗' : '↘' }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'

// 数据模式
const dataMode = ref('real')
const timeRange = ref('7days')
const channelFilter = ref('all')
const timeUnit = ref('day')

// 概览数据
const overviewData = reactive({
  visits: 12450,
  totalVisits: 2847392,
  conversionRate: 12.8,
  topChannel: {
    name: '搜索引擎',
    percentage: 40
  },
  topContent: {
    type: '视频内容',
    views: 1240
  }
})

// 设备分布数据
const deviceData = reactive({
  mobile: 65,
  desktop: 35
})

// 漏斗数据
const funnelData = reactive([
  { name: '曝光', count: 10000, percentage: 100, conversionRate: 100, loss: false },
  { name: '点击', count: 3200, percentage: 32, conversionRate: 32, loss: false },
  { name: '转化', count: 1280, percentage: 12.8, conversionRate: 12.8, loss: true }
])

// 内容数据
const contentData = reactive([
  { id: 1, title: '夏季促销', views: 1240, conversionRate: 12.8, trend: 'up' },
  { id: 2, title: '新品视频', views: 980, conversionRate: 8.5, trend: 'up' },
  { id: 3, title: '用户指南', views: 856, conversionRate: 4.2, trend: 'down' },
  { id: 4, title: '产品介绍', views: 720, conversionRate: 6.8, trend: 'up' },
  { id: 5, title: '活动海报', views: 650, conversionRate: 3.5, trend: 'down' }
])

// 洞察提示
const insights = reactive([
  { id: 1, message: '社交渠道转化较低 → 尝试优化落地页' },
  { id: 2, message: '移动端访问占比高 → 建议优化移动端体验' }
])

// 方法
const setDataMode = (mode) => {
  dataMode.value = mode
  updateData()
}

const setTimeUnit = (unit) => {
  timeUnit.value = unit
  updateData()
}

const updateData = () => {
  // 根据筛选条件更新数据
  console.log('更新数据:', { timeRange: timeRange.value, channelFilter: channelFilter.value })
}

const refreshData = () => {
  // 刷新数据
  console.log('刷新数据')
}

const optimizeData = () => {
  // 模拟数据优化效果
  overviewData.conversionRate += 15
  overviewData.visits += 2000
  console.log('数据优化完成')
}

const exportData = () => {
  // 导出CSV
  console.log('导出CSV数据')
}

const takeScreenshot = () => {
  // 截图分享
  console.log('生成截图')
}

const formatNumber = (num) => {
  return num.toLocaleString()
}

onMounted(() => {
  // 初始化数据
  updateData()
})
</script>

<style scoped>
.data-analysis-container {
  padding: 24px;
  background: #F8FAFC;
  min-height: 100vh;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}

.header-left {
  text-align: center;
  flex: 1;
}

.header-left h1 {
  font-size: 28px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.header-left p {
  color: #718096;
  margin: 0;
}

.header-controls {
  display: flex;
  gap: 16px;
  align-items: center;
}

.data-mode-toggle {
  display: flex;
  background: #E2E8F0;
  border-radius: 8px;
  padding: 4px;
}

.mode-btn {
  padding: 8px 16px;
  border: none;
  background: transparent;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
}

.mode-btn.active {
  background: white;
  color: #4F46E5;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.optimize-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: transform 0.2s;
}

.optimize-btn:hover {
  transform: translateY(-2px);
}

.btn-icon {
  font-size: 16px;
}

.filter-toolbar {
  display: flex;
  gap: 24px;
  align-items: center;
  background: white;
  padding: 16px 24px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin-bottom: 24px;
}

.filter-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.filter-group label {
  font-size: 14px;
  color: #4A5568;
  font-weight: 500;
}

.filter-group select {
  padding: 8px 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  background: white;
  color: #1A202C;
  font-size: 14px;
}

.refresh-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #4F46E5;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.refresh-btn:hover {
  background: #4338CA;
}

.insights-panel {
  background: #FEF3C7;
  border: 1px solid #F59E0B;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 24px;
}

.insight-item {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.insight-item:last-child {
  margin-bottom: 0;
}

.insight-icon {
  font-size: 16px;
}

.insight-text {
  font-size: 14px;
  color: #92400E;
}

.overview-dashboard {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 32px;
}

.metric-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
  transition: transform 0.2s;
}

.metric-card:hover {
  transform: translateY(-2px);
}

.metric-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.metric-header h3 {
  font-size: 16px;
  font-weight: 600;
  color: #4A5568;
  margin: 0;
}

.metric-trend {
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.metric-trend.positive {
  background: #DEF7EC;
  color: #03543F;
}

.metric-value {
  font-size: 32px;
  font-weight: 700;
  color: #1A202C;
  margin-bottom: 8px;
}

.metric-subtitle {
  font-size: 14px;
  color: #718096;
  margin-bottom: 4px;
}

.metric-total, .metric-change, .metric-percentage, .metric-views {
  font-size: 12px;
  color: #A0AEC0;
}

.traffic-analysis {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 24px;
  margin-bottom: 32px;
}

.chart-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.section-header h2 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.chart-controls {
  display: flex;
  gap: 8px;
}

.time-btn {
  padding: 6px 12px;
  border: 1px solid #E2E8F0;
  background: white;
  border-radius: 6px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.time-btn.active {
  background: #4F46E5;
  color: white;
  border-color: #4F46E5;
}

.chart-container {
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.line-chart {
  width: 100%;
  height: 100%;
}

.trend-line {
  transition: stroke-dasharray 0.3s;
}

.data-point {
  transition: r 0.2s;
}

.data-point:hover {
  r: 6;
}

.pie-chart {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
}

.pie-legend {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: #4A5568;
}

.legend-color {
  width: 12px;
  height: 12px;
  border-radius: 2px;
}

.device-distribution {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.device-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.device-icon {
  font-size: 24px;
}

.device-info {
  flex: 1;
}

.device-name {
  font-size: 14px;
  color: #4A5568;
  margin-bottom: 4px;
}

.device-percentage {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
}

.device-bar {
  width: 80px;
  height: 8px;
  background: #E2E8F0;
  border-radius: 4px;
  overflow: hidden;
}

.bar-fill {
  height: 100%;
  background: linear-gradient(90deg, #4F46E5, #667EEA);
  border-radius: 4px;
  transition: width 0.3s;
}

.conversion-funnel {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
  margin-bottom: 32px;
}

.funnel-container {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.funnel-stage {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px;
  border-radius: 8px;
  background: #F7FAFC;
  transition: all 0.2s;
}

.funnel-stage.loss-point {
  background: #FEF2F2;
  border: 1px solid #FECACA;
}

.funnel-stage:hover {
  transform: translateX(8px);
}

.stage-header {
  display: flex;
  flex-direction: column;
  min-width: 120px;
}

.stage-header h3 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 4px 0;
}

.stage-count {
  font-size: 14px;
  color: #718096;
}

.stage-bar {
  flex: 1;
  height: 12px;
  background: #E2E8F0;
  border-radius: 6px;
  overflow: hidden;
}

.stage-info {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  min-width: 100px;
}

.conversion-rate {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

.loss-indicator {
  font-size: 12px;
  color: #DC2626;
  margin-top: 4px;
}

.export-btn, .screenshot-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #4F46E5;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.export-btn:hover, .screenshot-btn:hover {
  background: #4338CA;
}

.content-performance {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.content-table {
  overflow-x: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #E2E8F0;
}

th {
  background: #F7FAFC;
  font-weight: 600;
  color: #1A202C;
  font-size: 14px;
}

td {
  color: #1A202C;
  font-size: 14px;
}

.low-conversion {
  color: #DC2626;
  font-weight: 500;
}

.trend-indicator {
  font-weight: bold;
  font-size: 16px;
}

.trend-indicator.up {
  color: #059669;
}

.trend-indicator.down {
  color: #DC2626;
}

@media (max-width: 1024px) {
  .traffic-analysis {
    grid-template-columns: 1fr;
  }
  
  .overview-dashboard {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  }
}

@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .header-controls {
    width: 100%;
    justify-content: space-between;
  }
  
  .filter-toolbar {
    flex-direction: column;
    gap: 16px;
  }
  
  .overview-dashboard {
    grid-template-columns: 1fr;
  }
}
</style>
