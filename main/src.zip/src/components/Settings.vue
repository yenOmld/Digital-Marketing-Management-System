<template>
  <div class="settings-container">
    <!-- 页面标题 -->
    <div class="page-header">
      <h1>系统设置</h1>
      <p>管理系统配置和用户偏好</p>
    </div>

    <!-- 设置导航 -->
    <div class="settings-layout">
      <div class="settings-sidebar">
        <div class="sidebar-section">
          <h3>系统配置</h3>
          <div class="nav-items">
            <div 
              v-for="item in navItems" 
              :key="item.id"
              class="nav-item"
              :class="{ 'active': activeTab === item.id }"
              @click="activeTab = item.id"
            >
              <div class="nav-icon" v-html="item.icon"></div>
              <span>{{ item.name }}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="settings-content">
        <!-- 基本设置 -->
        <div v-if="activeTab === 'basic'" class="settings-section">
          <h2>基本设置</h2>
          <div class="settings-form">
            <div class="form-group">
              <label>系统名称</label>
              <input type="text" v-model="basicSettings.systemName" placeholder="智能营销中心" />
            </div>
            <div class="form-group">
              <label>系统版本</label>
              <input type="text" v-model="basicSettings.version" placeholder="v1.0.0" readonly />
            </div>
            <div class="form-group">
              <label>时区设置</label>
              <select v-model="basicSettings.timezone">
                <option value="Asia/Shanghai">中国标准时间 (UTC+8)</option>
                <option value="UTC">协调世界时 (UTC)</option>
                <option value="America/New_York">美国东部时间 (UTC-5)</option>
              </select>
            </div>
            <div class="form-group">
              <label>语言设置</label>
              <select v-model="basicSettings.language">
                <option value="zh-CN">简体中文</option>
                <option value="en-US">English</option>
                <option value="ja-JP">日本語</option>
              </select>
            </div>
          </div>
        </div>

        <!-- 用户管理 -->
        <div v-if="activeTab === 'users'" class="settings-section">
          <h2>用户管理</h2>
          <div class="users-list">
            <div class="list-header">
              <h3>用户列表</h3>
              <div class="header-actions">
                <button class="batch-btn" @click="showBatchActions = !showBatchActions" :disabled="selectedUsers.length === 0">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 11H1v6h8v-6zM23 11h-8v6h8v-6zM9 1H1v6h8V1zM23 1h-8v6h8V1z"/>
                  </svg>
                  批量操作 ({{ selectedUsers.length }})
                </button>
                <button class="add-btn" @click="showAddUserModal = true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 5v14M5 12h14"/>
                  </svg>
                  添加用户
                </button>
              </div>
            </div>
            <!-- 批量操作面板 -->
            <div v-if="showBatchActions" class="batch-actions-panel">
              <div class="batch-actions">
                <button class="batch-action-btn" @click="batchDeleteUsers">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3,6 5,6 21,6"/>
                    <path d="M19,6v14a2,2 0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2v2"/>
                  </svg>
                  删除选中
                </button>
                <button class="batch-action-btn" @click="batchActivateUsers">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                    <polyline points="22,4 12,14.01 9,11.01"/>
                  </svg>
                  激活选中
                </button>
                <button class="batch-action-btn" @click="batchDeactivateUsers">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="15" y1="9" x2="9" y2="15"/>
                    <line x1="9" y1="9" x2="15" y2="15"/>
                  </svg>
                  停用选中
                </button>
              </div>
            </div>

            <div class="table-container">
              <table>
                <thead>
                  <tr>
                    <th width="25">
                      <label class="checkbox-wrapper">
                        <input 
                          type="checkbox" 
                          @change="toggleAllUsers"
                          :checked="selectedUsers.length === users.length && users.length > 0"
                          :indeterminate="selectedUsers.length > 0 && selectedUsers.length < users.length"
                        />
                        <span class="checkmark"></span>
                      </label>
                    </th>
                    <th width="80">用户名</th>
                    <th>邮箱</th>
                    <th width="70">角色</th>
                    <th width="55">状态</th>
                    <th>最后登录</th>
                    <th width="70">操作</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="user in users" :key="user.id" :class="{ 'selected': selectedUsers.includes(user.id) }">
                    <td>
                      <label class="checkbox-wrapper">
                        <input 
                          type="checkbox" 
                          :value="user.id"
                          v-model="selectedUsers"
                        />
                        <span class="checkmark"></span>
                      </label>
                    </td>
                    <td>
                      <div class="user-info">
                        <div class="user-avatar" :class="getUserAvatarClass(user)">
                          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                          </svg>
                        </div>
                        <span>{{ user.name }}</span>
                      </div>
                    </td>
                    <td>{{ user.email }}</td>
                    <td>
                      <span class="role-badge" :class="user.role">{{ user.roleText }}</span>
                    </td>
                    <td>
                      <span class="status-badge" :class="user.status">{{ user.statusText }}</span>
                    </td>
                    <td>{{ user.lastLogin }}</td>
                    <td>
                      <div class="actions">
                        <button class="action-btn edit" @click="editUser(user)" title="编辑用户">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                          </svg>
                        </button>
                        <button class="action-btn delete" @click="deleteUser(user)" title="删除用户">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3,6 5,6 21,6"/>
                            <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2v2"/>
                            <line x1="10" y1="11" x2="10" y2="17"/>
                            <line x1="14" y1="11" x2="14" y2="17"/>
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- 权限设置 -->
        <div v-if="activeTab === 'permissions'" class="settings-section">
          <h2>权限设置</h2>
          <div class="permissions-grid">
            <div class="permission-card" v-for="permission in permissions" :key="permission.id">
              <div class="permission-header">
                <h3>{{ permission.name }}</h3>
                <label class="switch">
                  <input type="checkbox" v-model="permission.enabled" />
                  <span class="slider"></span>
                </label>
              </div>
              <p class="permission-description">{{ permission.description }}</p>
              <div class="permission-roles">
                <span v-for="role in permission.roles" :key="role" class="role-tag">{{ role }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 通知设置 -->
        <div v-if="activeTab === 'notifications'" class="settings-section">
          <h2>通知设置</h2>
          <div class="notification-settings">
            <div class="notification-group" v-for="group in notificationGroups" :key="group.id">
              <h3>{{ group.name }}</h3>
              <div class="notification-items">
                <div class="notification-item" v-for="item in group.items" :key="item.id">
                  <div class="item-info">
                    <span class="item-name">{{ item.name }}</span>
                    <span class="item-description">{{ item.description }}</span>
                  </div>
                  <div class="item-controls">
                    <label class="switch">
                      <input type="checkbox" v-model="item.enabled" />
                      <span class="slider"></span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 安全设置 -->
        <div v-if="activeTab === 'security'" class="settings-section">
          <h2>安全设置</h2>
          <div class="security-settings">
            <div class="security-item">
              <div class="item-info">
                <h3>密码策略</h3>
                <p>设置密码复杂度要求和有效期</p>
              </div>
              <button class="configure-btn">配置</button>
            </div>
            <div class="security-item">
              <div class="item-info">
                <h3>登录安全</h3>
                <p>设置登录验证和会话管理</p>
              </div>
              <button class="configure-btn">配置</button>
            </div>
            <div class="security-item">
              <div class="item-info">
                <h3>数据备份</h3>
                <p>配置数据备份和恢复策略</p>
              </div>
              <button class="configure-btn">配置</button>
            </div>
            <div class="security-item">
              <div class="item-info">
                <h3>审计日志</h3>
                <p>查看系统操作审计日志</p>
              </div>
              <button class="configure-btn">查看</button>
            </div>
          </div>
        </div>

        <!-- 保存按钮 -->
        <div class="settings-actions">
          <button class="save-btn" @click="saveSettings" :disabled="!hasChanges">
            <svg v-if="isSaving" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spinning">
              <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
            </svg>
            <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
              <polyline points="17,21 17,13 7,13 7,21"/>
              <polyline points="7,3 7,8 15,8"/>
            </svg>
            {{ isSaving ? '保存中...' : '保存设置' }}
          </button>
          <button class="cancel-btn" @click="cancelChanges">取消</button>
        </div>
      </div>
    </div>

    <!-- 添加用户模态框 -->
    <div v-if="showAddUserModal" class="modal-overlay" @click="closeAddUserModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>添加用户</h3>
          <button class="modal-close" @click="closeAddUserModal">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
        
        <div class="modal-body">
          <div class="form-group">
            <label>用户名 *</label>
            <input 
              type="text" 
              v-model="newUser.name" 
              placeholder="请输入用户名"
              class="form-input"
              :class="{ 'error': newUserErrors.name }"
            />
            <span v-if="newUserErrors.name" class="error-text">{{ newUserErrors.name }}</span>
          </div>
          
          <div class="form-group">
            <label>邮箱 *</label>
            <input 
              type="email" 
              v-model="newUser.email" 
              placeholder="请输入邮箱地址"
              class="form-input"
              :class="{ 'error': newUserErrors.email }"
            />
            <span v-if="newUserErrors.email" class="error-text">{{ newUserErrors.email }}</span>
          </div>
          
          <div class="form-group">
            <label>角色 *</label>
            <select 
              v-model="newUser.role" 
              class="form-select"
              :class="{ 'error': newUserErrors.role }"
            >
              <option value="">请选择角色</option>
              <option value="admin">管理员</option>
              <option value="manager">经理</option>
              <option value="user">普通用户</option>
            </select>
            <span v-if="newUserErrors.role" class="error-text">{{ newUserErrors.role }}</span>
          </div>
          
          <div class="form-group">
            <label>初始密码 *</label>
            <input 
              type="password" 
              v-model="newUser.password" 
              placeholder="请输入初始密码"
              class="form-input"
              :class="{ 'error': newUserErrors.password }"
            />
            <span v-if="newUserErrors.password" class="error-text">{{ newUserErrors.password }}</span>
          </div>
          
          <div class="form-group">
            <label>确认密码 *</label>
            <input 
              type="password" 
              v-model="newUser.confirmPassword" 
              placeholder="请再次输入密码"
              class="form-input"
              :class="{ 'error': newUserErrors.confirmPassword }"
            />
            <span v-if="newUserErrors.confirmPassword" class="error-text">{{ newUserErrors.confirmPassword }}</span>
          </div>
        </div>
        
        <div class="modal-footer">
          <button class="btn-cancel" @click="closeAddUserModal">取消</button>
          <button class="btn-confirm" @click="addUser">添加用户</button>
        </div>
      </div>
    </div>

    <!-- 编辑用户模态框 -->
    <div v-if="showEditUserModal" class="modal-overlay" @click="closeEditUserModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>编辑用户</h3>
          <button class="modal-close" @click="closeEditUserModal">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
        
        <div class="modal-body">
          <div class="form-group">
            <label>用户名 *</label>
            <input 
              type="text" 
              v-model="editingUser.name" 
              placeholder="请输入用户名"
              class="form-input"
              :class="{ 'error': editUserErrors.name }"
            />
            <span v-if="editUserErrors.name" class="error-text">{{ editUserErrors.name }}</span>
          </div>
          
          <div class="form-group">
            <label>邮箱 *</label>
            <input 
              type="email" 
              v-model="editingUser.email" 
              placeholder="请输入邮箱地址"
              class="form-input"
              :class="{ 'error': editUserErrors.email }"
            />
            <span v-if="editUserErrors.email" class="error-text">{{ editUserErrors.email }}</span>
          </div>
          
          <div class="form-group">
            <label>角色 *</label>
            <select 
              v-model="editingUser.role" 
              class="form-select"
              :class="{ 'error': editUserErrors.role }"
            >
              <option value="admin">管理员</option>
              <option value="manager">经理</option>
              <option value="user">普通用户</option>
            </select>
            <span v-if="editUserErrors.role" class="error-text">{{ editUserErrors.role }}</span>
          </div>
          
          <div class="form-group">
            <label>状态</label>
            <select v-model="editingUser.status" class="form-select">
              <option value="active">活跃</option>
              <option value="inactive">不活跃</option>
            </select>
          </div>
          
          <div class="form-group">
            <label class="checkbox-label">
              <input type="checkbox" v-model="resetPassword" />
              <span class="checkbox-text">重置密码</span>
            </label>
          </div>
          
          <div v-if="resetPassword" class="password-section">
            <div class="form-group">
              <label>新密码 *</label>
              <input 
                type="password" 
                v-model="editingUser.newPassword" 
                placeholder="请输入新密码"
                class="form-input"
                :class="{ 'error': editUserErrors.newPassword }"
              />
              <span v-if="editUserErrors.newPassword" class="error-text">{{ editUserErrors.newPassword }}</span>
            </div>
            
            <div class="form-group">
              <label>确认新密码 *</label>
              <input 
                type="password" 
                v-model="editingUser.confirmNewPassword" 
                placeholder="请再次输入新密码"
                class="form-input"
                :class="{ 'error': editUserErrors.confirmNewPassword }"
              />
              <span v-if="editUserErrors.confirmNewPassword" class="error-text">{{ editUserErrors.confirmNewPassword }}</span>
            </div>
          </div>
        </div>
        
        <div class="modal-footer">
          <button class="btn-cancel" @click="closeEditUserModal">取消</button>
          <button class="btn-confirm" @click="updateUser">保存修改</button>
        </div>
      </div>
    </div>

    <!-- 删除确认对话框 -->
    <div v-if="showDeleteConfirm" class="modal-overlay" @click="closeDeleteConfirm">
      <div class="confirm-dialog" @click.stop>
        <div class="confirm-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="15" y1="9" x2="9" y2="15"/>
            <line x1="9" y1="9" x2="15" y2="15"/>
          </svg>
        </div>
        <div class="confirm-title">确认删除用户</div>
        <div class="confirm-message">
          您确定要删除用户 <strong>{{ userToDelete?.name }}</strong> 吗？此操作不可撤销。
        </div>
        <div class="confirm-actions">
          <button class="btn-cancel" @click="closeDeleteConfirm">取消</button>
          <button class="btn-danger" @click="confirmDeleteUser">确认删除</button>
        </div>
      </div>
    </div>

    <!-- 批量删除确认对话框 -->
    <div v-if="showBatchDeleteConfirm" class="modal-overlay" @click="closeBatchDeleteConfirm">
      <div class="confirm-dialog" @click.stop>
        <div class="confirm-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="15" y1="9" x2="9" y2="15"/>
            <line x1="9" y1="9" x2="15" y2="15"/>
          </svg>
        </div>
        <div class="confirm-title">批量删除用户</div>
        <div class="confirm-message">
          您确定要删除选中的 <strong>{{ selectedUsers.length }}</strong> 个用户吗？此操作不可撤销。
        </div>
        <div class="confirm-actions">
          <button class="btn-cancel" @click="closeBatchDeleteConfirm">取消</button>
          <button class="btn-danger" @click="confirmBatchDeleteUsers">确认删除</button>
        </div>
      </div>
    </div>

    <!-- 保存成功提示 -->
    <div v-if="showSaveSuccess" class="toast-notification success">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M20 6L9 17L4 12"/>
      </svg>
      <span>设置保存成功！</span>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const activeTab = ref('basic')

// 用户管理相关状态
const selectedUsers = ref([])
const showBatchActions = ref(false)
const showAddUserModal = ref(false)
const showEditUserModal = ref(false)
const showDeleteConfirm = ref(false)
const showBatchDeleteConfirm = ref(false)
const userToDelete = ref(null)
const editingUser = ref({})
const resetPassword = ref(false)

// 保存状态
const isSaving = ref(false)
const showSaveSuccess = ref(false)
const originalSettings = ref({})

// 新用户表单
const newUser = ref({
  name: '',
  email: '',
  role: '',
  password: '',
  confirmPassword: ''
})

// 表单验证错误
const newUserErrors = ref({})
const editUserErrors = ref({})

// 导航项
const navItems = [
  {
    id: 'basic',
    name: '基本设置',
    icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1 1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>'
  },
  {
    id: 'users',
    name: '用户管理',
    icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>'
  },
  {
    id: 'permissions',
    name: '权限设置',
    icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><circle cx="12" cy="16" r="1"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>'
  },
  {
    id: 'notifications',
    name: '通知设置',
    icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>'
  },
  {
    id: 'security',
    name: '安全设置',
    icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>'
  }
]

// 基本设置
const basicSettings = ref({
  systemName: '智能营销中心',
  version: 'v1.0.0',
  timezone: 'Asia/Shanghai',
  language: 'zh-CN'
})

// 用户列表
const users = ref([
  {
    id: 1,
    name: '张三',
    email: 'zhangsan@example.com',
    role: 'admin',
    roleText: '管理员',
    status: 'active',
    statusText: '活跃',
    lastLogin: '2024-01-15 14:30'
  },
  {
    id: 2,
    name: '李四',
    email: 'lisi@example.com',
    role: 'user',
    roleText: '普通用户',
    status: 'active',
    statusText: '活跃',
    lastLogin: '2024-01-14 09:15'
  },
  {
    id: 3,
    name: '王五',
    email: 'wangwu@example.com',
    role: 'manager',
    roleText: '经理',
    status: 'inactive',
    statusText: '不活跃',
    lastLogin: '2024-01-10 16:45'
  }
])

// 权限设置
const permissions = ref([
  {
    id: 1,
    name: '数据查看',
    description: '允许查看系统数据和报表',
    enabled: true,
    roles: ['管理员', '经理', '用户']
  },
  {
    id: 2,
    name: '数据编辑',
    description: '允许编辑和修改系统数据',
    enabled: true,
    roles: ['管理员', '经理']
  },
  {
    id: 3,
    name: '用户管理',
    description: '允许管理用户账户和权限',
    enabled: false,
    roles: ['管理员']
  },
  {
    id: 4,
    name: '系统设置',
    description: '允许修改系统配置',
    enabled: false,
    roles: ['管理员']
  }
])

// 通知设置
const notificationGroups = ref([
  {
    id: 1,
    name: '系统通知',
    items: [
      {
        id: 1,
        name: '系统维护',
        description: '系统维护和更新通知',
        enabled: true
      },
      {
        id: 2,
        name: '安全警告',
        description: '安全相关警告和提醒',
        enabled: true
      }
    ]
  },
  {
    id: 2,
    name: '业务通知',
    items: [
      {
        id: 3,
        name: '数据更新',
        description: '数据更新和同步通知',
        enabled: false
      },
      {
        id: 4,
        name: '报表生成',
        description: '报表生成完成通知',
        enabled: true
      }
    ]
  }
])

// 计算属性
const hasChanges = computed(() => {
  return JSON.stringify(basicSettings.value) !== JSON.stringify(originalSettings.value.basic) ||
         JSON.stringify(permissions.value) !== JSON.stringify(originalSettings.value.permissions) ||
         JSON.stringify(notificationGroups.value) !== JSON.stringify(originalSettings.value.notifications)
})

// 初始化原始设置
const initializeOriginalSettings = () => {
  originalSettings.value = {
    basic: JSON.parse(JSON.stringify(basicSettings.value)),
    permissions: JSON.parse(JSON.stringify(permissions.value)),
    notifications: JSON.parse(JSON.stringify(notificationGroups.value))
  }
}

// 用户管理方法
const getUserAvatarClass = (user) => {
  const baseClass = 'svg-avatar'
  const roleClass = `avatar-${user.role}`
  const statusClass = user.status === 'active' ? 'avatar-active' : 'avatar-inactive'
  return `${baseClass} ${roleClass} ${statusClass}`
}

const toggleAllUsers = (event) => {
  if (event.target.checked) {
    selectedUsers.value = users.value.map(user => user.id)
  } else {
    selectedUsers.value = []
  }
}

const closeAddUserModal = () => {
  showAddUserModal.value = false
  resetNewUserForm()
}

const resetNewUserForm = () => {
  newUser.value = {
    name: '',
    email: '',
    role: '',
    password: '',
    confirmPassword: ''
  }
  newUserErrors.value = {}
}

const validateNewUser = () => {
  const errors = {}
  
  if (!newUser.value.name.trim()) {
    errors.name = '请输入用户名'
  }
  
  if (!newUser.value.email.trim()) {
    errors.email = '请输入邮箱地址'
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newUser.value.email)) {
    errors.email = '请输入有效的邮箱地址'
  } else if (users.value.some(user => user.email === newUser.value.email)) {
    errors.email = '该邮箱已被使用'
  }
  
  if (!newUser.value.role) {
    errors.role = '请选择角色'
  }
  
  if (!newUser.value.password) {
    errors.password = '请输入初始密码'
  } else if (newUser.value.password.length < 6) {
    errors.password = '密码长度至少6位'
  }
  
  if (!newUser.value.confirmPassword) {
    errors.confirmPassword = '请确认密码'
  } else if (newUser.value.password !== newUser.value.confirmPassword) {
    errors.confirmPassword = '两次输入的密码不一致'
  }
  
  newUserErrors.value = errors
  return Object.keys(errors).length === 0
}

const addUser = () => {
  if (!validateNewUser()) {
    return
  }
  
  const roleTexts = {
    admin: '管理员',
    manager: '经理',
    user: '普通用户'
  }
  
  const newUserId = Math.max(...users.value.map(u => u.id)) + 1
  const userData = {
    id: newUserId,
    name: newUser.value.name,
    email: newUser.value.email,
    role: newUser.value.role,
    roleText: roleTexts[newUser.value.role],
    status: 'active',
    statusText: '活跃',
    lastLogin: '从未登录'
  }
  
  users.value.push(userData)
  closeAddUserModal()
  showToast('用户添加成功！')
}

const editUser = (user) => {
  editingUser.value = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    status: user.status,
    newPassword: '',
    confirmNewPassword: ''
  }
  resetPassword.value = false
  editUserErrors.value = {}
  showEditUserModal.value = true
}

const closeEditUserModal = () => {
  showEditUserModal.value = false
  editingUser.value = {}
  resetPassword.value = false
  editUserErrors.value = {}
}

const validateEditUser = () => {
  const errors = {}
  
  if (!editingUser.value.name.trim()) {
    errors.name = '请输入用户名'
  }
  
  if (!editingUser.value.email.trim()) {
    errors.email = '请输入邮箱地址'
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editingUser.value.email)) {
    errors.email = '请输入有效的邮箱地址'
  } else if (users.value.some(user => user.email === editingUser.value.email && user.id !== editingUser.value.id)) {
    errors.email = '该邮箱已被使用'
  }
  
  if (!editingUser.value.role) {
    errors.role = '请选择角色'
  }
  
  if (resetPassword.value) {
    if (!editingUser.value.newPassword) {
      errors.newPassword = '请输入新密码'
    } else if (editingUser.value.newPassword.length < 6) {
      errors.newPassword = '密码长度至少6位'
    }
    
    if (!editingUser.value.confirmNewPassword) {
      errors.confirmNewPassword = '请确认新密码'
    } else if (editingUser.value.newPassword !== editingUser.value.confirmNewPassword) {
      errors.confirmNewPassword = '两次输入的密码不一致'
    }
  }
  
  editUserErrors.value = errors
  return Object.keys(errors).length === 0
}

const updateUser = () => {
  if (!validateEditUser()) {
    return
  }
  
  const roleTexts = {
    admin: '管理员',
    manager: '经理',
    user: '普通用户'
  }
  
  const statusTexts = {
    active: '活跃',
    inactive: '不活跃'
  }
  
  const userIndex = users.value.findIndex(u => u.id === editingUser.value.id)
  if (userIndex !== -1) {
    users.value[userIndex] = {
      ...users.value[userIndex],
      name: editingUser.value.name,
      email: editingUser.value.email,
      role: editingUser.value.role,
      roleText: roleTexts[editingUser.value.role],
      status: editingUser.value.status,
      statusText: statusTexts[editingUser.value.status]
    }
  }
  
  closeEditUserModal()
  showToast('用户信息更新成功！')
}

const deleteUser = (user) => {
  userToDelete.value = user
  showDeleteConfirm.value = true
}

const closeDeleteConfirm = () => {
  showDeleteConfirm.value = false
  userToDelete.value = null
}

const confirmDeleteUser = () => {
  if (userToDelete.value) {
    const userIndex = users.value.findIndex(u => u.id === userToDelete.value.id)
    if (userIndex !== -1) {
      users.value.splice(userIndex, 1)
      // 从选中列表中移除
      selectedUsers.value = selectedUsers.value.filter(id => id !== userToDelete.value.id)
    }
  }
  closeDeleteConfirm()
  showToast('用户删除成功！')
}

// 批量操作方法
const batchDeleteUsers = () => {
  if (selectedUsers.value.length === 0) return
  showBatchDeleteConfirm.value = true
}

const closeBatchDeleteConfirm = () => {
  showBatchDeleteConfirm.value = false
}

const confirmBatchDeleteUsers = () => {
  users.value = users.value.filter(user => !selectedUsers.value.includes(user.id))
  selectedUsers.value = []
  showBatchActions.value = false
  closeBatchDeleteConfirm()
  showToast('批量删除成功！')
}

const batchActivateUsers = () => {
  users.value.forEach(user => {
    if (selectedUsers.value.includes(user.id)) {
      user.status = 'active'
      user.statusText = '活跃'
    }
  })
  selectedUsers.value = []
  showBatchActions.value = false
  showToast('批量激活成功！')
}

const batchDeactivateUsers = () => {
  users.value.forEach(user => {
    if (selectedUsers.value.includes(user.id)) {
      user.status = 'inactive'
      user.statusText = '不活跃'
    }
  })
  selectedUsers.value = []
  showBatchActions.value = false
  showToast('批量停用成功！')
}

// 保存设置
const saveSettings = async () => {
  isSaving.value = true
  
  try {
    // 模拟API调用
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // 更新原始设置
    initializeOriginalSettings()
    
    showSaveSuccess.value = true
    setTimeout(() => {
      showSaveSuccess.value = false
    }, 3000)
    
    showToast('设置保存成功！')
  } catch (error) {
    showToast('保存失败，请重试', 'error')
  } finally {
    isSaving.value = false
  }
}

const cancelChanges = () => {
  // 恢复原始设置
  basicSettings.value = JSON.parse(JSON.stringify(originalSettings.value.basic))
  permissions.value = JSON.parse(JSON.stringify(originalSettings.value.permissions))
  notificationGroups.value = JSON.parse(JSON.stringify(originalSettings.value.notifications))
  
  showToast('已取消修改')
}

const showToast = (message, type = 'success') => {
  // 这里可以实现toast通知
  console.log(`${type}: ${message}`)
}

// 监听选中用户变化，自动隐藏批量操作面板
watch(selectedUsers, (newVal) => {
  if (newVal.length === 0) {
    showBatchActions.value = false
  }
})

// 初始化
initializeOriginalSettings()
</script>

<style scoped>
.settings-container {
  padding: 24px;
  background: #F7FAFC;
  min-height: 100vh;
}

.page-header {
  margin-bottom: 32px;
}

.page-header h1 {
  font-size: 28px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.page-header p {
  color: #718096;
  margin: 0;
}

.settings-layout {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 24px;
}

.settings-sidebar {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
  height: fit-content;
}

.sidebar-section h3 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 16px 0;
}

.nav-items {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  color: #718096;
}

.nav-item:hover {
  background: #F7FAFC;
  color: #1A202C;
}

.nav-item.active {
  background: #4F46E5;
  color: white;
}

.nav-icon {
  display: flex;
  align-items: center;
}

.settings-content {
  background: white;
  border-radius: 12px;
  padding: 32px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.settings-section h2 {
  font-size: 24px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 24px 0;
}

.settings-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-group label {
  font-size: 14px;
  font-weight: 500;
  color: #1A202C;
}

.form-group input,
.form-group select {
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  font-size: 14px;
  background: white;
}

.form-group input:focus,
.form-group select:focus {
  outline: none;
  border-color: #4F46E5;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
}

.users-list {
  margin-top: 24px;
}

.list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.list-header h3 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.add-btn {
  background: #4F46E5;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}

.table-container {
  overflow-x: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #E2E8F0;
}

th {
  background: #F7FAFC;
  font-weight: 600;
  color: #1A202C;
  font-size: 14px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.user-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

/* SVG头像样式 */
.user-avatar.svg-avatar {
  border: 2px solid;
  transition: all 0.3s ease;
}

.user-avatar.avatar-admin {
  background: linear-gradient(135deg, #FEF3C7, #F59E0B);
  border-color: #D97706;
  color: #92400E;
}

.user-avatar.avatar-manager {
  background: linear-gradient(135deg, #DBEAFE, #3B82F6);
  border-color: #2563EB;
  color: #1E40AF;
}

.user-avatar.avatar-user {
  background: linear-gradient(135deg, #F3F4F6, #6B7280);
  border-color: #4B5563;
  color: #374151;
}

.user-avatar.avatar-active {
  box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.2);
}

.user-avatar.avatar-inactive {
  opacity: 0.6;
  filter: grayscale(0.3);
}

.user-avatar svg {
  transition: transform 0.3s ease;
}

.user-avatar:hover svg {
  transform: scale(1.1);
}

.role-badge,
.status-badge {
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.role-badge.admin {
  background: #FEF3C7;
  color: #92400E;
}

.role-badge.manager {
  background: #DBEAFE;
  color: #1E40AF;
}

.role-badge.user {
  background: #E5E7EB;
  color: #374151;
}

.status-badge.active {
  background: #DEF7EC;
  color: #03543F;
}

.status-badge.inactive {
  background: #FDE8E8;
  color: #9B1C1C;
}

.actions {
  display: flex;
  gap: 4px;
}

.action-btn {
  padding: 4px 8px;
  border: 1px solid #E2E8F0;
  border-radius: 4px;
  background: white;
  color: #1A202C;
  font-size: 12px;
  cursor: pointer;
}

.permissions-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
}

.permission-card {
  background: #F7FAFC;
  border-radius: 8px;
  padding: 20px;
  border: 1px solid #E2E8F0;
}

.permission-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.permission-header h3 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.permission-description {
  font-size: 14px;
  color: #718096;
  margin: 0 0 12px 0;
}

.permission-roles {
  display: flex;
  gap: 4px;
  flex-wrap: wrap;
}

.role-tag {
  padding: 2px 6px;
  background: white;
  border: 1px solid #E2E8F0;
  border-radius: 4px;
  font-size: 12px;
  color: #4A5568;
}

.notification-settings {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.notification-group h3 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 16px 0;
}

.notification-items {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.notification-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px;
  background: #F7FAFC;
  border-radius: 8px;
  border: 1px solid #E2E8F0;
}

.item-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.item-name {
  font-size: 14px;
  font-weight: 500;
  color: #1A202C;
}

.item-description {
  font-size: 12px;
  color: #718096;
}

.security-settings {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.security-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background: #F7FAFC;
  border-radius: 8px;
  border: 1px solid #E2E8F0;
}

.item-info h3 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 4px 0;
}

.item-info p {
  font-size: 14px;
  color: #718096;
  margin: 0;
}

.configure-btn {
  background: #4F46E5;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}

.settings-actions {
  display: flex;
  gap: 12px;
  margin-top: 32px;
  padding-top: 24px;
  border-top: 1px solid #E2E8F0;
}

.save-btn {
  background: #4F46E5;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}

.cancel-btn {
  background: white;
  color: #1A202C;
  border: 1px solid #E2E8F0;
  padding: 12px 24px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}

/* 开关样式 */
.switch {
  position: relative;
  display: inline-block;
  width: 44px;
  height: 24px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #E2E8F0;
  transition: .4s;
  border-radius: 24px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 18px;
  width: 18px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  transition: .4s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: #4F46E5;
}

input:checked + .slider:before {
  transform: translateX(20px);
}

/* 新增样式 */
.header-actions {
  display: flex;
  gap: 12px;
  align-items: center;
}

.batch-btn {
  background: #F7FAFC;
  color: #4F46E5;
  border: 1px solid #4F46E5;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.3s ease;
}

.batch-btn:hover:not(:disabled) {
  background: #EBF4FF;
}

.batch-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.add-btn {
  background: #4F46E5;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: background-color 0.3s;
}

.add-btn:hover {
  background: #4338CA;
}

/* 批量操作面板 */
.batch-actions-panel {
  background: #EBF4FF;
  border: 1px solid #2C6FD1;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
}

.batch-actions {
  display: flex;
  gap: 12px;
  align-items: center;
}

.batch-action-btn {
  background: white;
  color: #4F46E5;
  border: 1px solid #4F46E5;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.3s ease;
}

.batch-action-btn:hover {
  background: #F7FAFC;
}

/* 复选框样式 */
.checkbox-wrapper {
  position: relative;
  display: inline-block;
  cursor: pointer;
}

.checkbox-wrapper input {
  opacity: 0;
  width: 0;
  height: 0;
}

.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 16px;
  width: 16px;
  background-color: #F7FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 3px;
  transition: all 0.3s;
}

.checkbox-wrapper:hover input ~ .checkmark {
  background-color: #EBF4FF;
  border-color: #4F46E5;
}

.checkbox-wrapper input:checked ~ .checkmark {
  background-color: #4F46E5;
  border-color: #4F46E5;
}

.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

.checkbox-wrapper input:checked ~ .checkmark:after {
  display: block;
}

.checkbox-wrapper .checkmark:after {
  left: 5px;
  top: 2px;
  width: 4px;
  height: 8px;
  border: solid white;
  border-width: 0 2px 2px 0;
  transform: rotate(45deg);
}

/* 表格行选中状态 */
tbody tr.selected {
  background-color: #F7FAFC;
}

/* 改进的操作按钮 */
.actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  padding: 6px;
  border: 1px solid #E2E8F0;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.action-btn:hover {
  background: #F7FAFC;
}

.action-btn.edit {
  color: #4F46E5;
  border-color: #4F46E5;
}

.action-btn.edit:hover {
  background: #EBF4FF;
}

.action-btn.delete {
  color: #DC2626;
  border-color: #DC2626;
}

.action-btn.delete:hover {
  background: #FEF2F2;
}

/* 保存按钮改进 */
.save-btn {
  background: #4F46E5;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.3s ease;
}

.save-btn:hover:not(:disabled) {
  background: #4338CA;
}

.save-btn:disabled {
  background: #A0AEC0;
  cursor: not-allowed;
}

.spinning {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 24px 0 24px;
  border-bottom: 1px solid #E2E8F0;
  padding-bottom: 16px;
}

.modal-header h3 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  color: #718096;
  transition: all 0.3s ease;
}

.modal-close:hover {
  background: #F7FAFC;
  color: #1A202C;
}

.modal-body {
  padding: 24px;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 0 24px 24px 24px;
  border-top: 1px solid #E2E8F0;
  padding-top: 16px;
}

/* 表单样式 */
.form-input,
.form-select {
  width: 100%;
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
  transition: all 0.3s ease;
  box-sizing: border-box;
}

.form-input:focus,
.form-select:focus {
  outline: none;
  border-color: #4F46E5;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
}

.form-input.error,
.form-select.error {
  border-color: #DC2626;
}

.error-text {
  color: #DC2626;
  font-size: 12px;
  margin-top: 4px;
  display: block;
}

.checkbox-label {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.checkbox-text {
  font-size: 14px;
  color: #4A5568;
}

.password-section {
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid #E2E8F0;
}

/* 按钮样式 */
.btn-cancel {
  background: #F7FAFC;
  color: #4A5568;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-cancel:hover {
  background: #EDF2F7;
}

.btn-confirm {
  background: #4F46E5;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-confirm:hover {
  background: #4338CA;
}

.btn-danger {
  background: #DC2626;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-danger:hover {
  background: #B91C1C;
}

/* 确认对话框 */
.confirm-dialog {
  background: white;
  border-radius: 12px;
  padding: 32px;
  max-width: 400px;
  width: 90%;
  text-align: center;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.confirm-icon {
  color: #DC2626;
  margin-bottom: 16px;
  display: flex;
  justify-content: center;
}

.confirm-title {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin-bottom: 12px;
}

.confirm-message {
  font-size: 14px;
  color: #718096;
  margin-bottom: 24px;
  line-height: 1.5;
}

.confirm-actions {
  display: flex;
  gap: 12px;
  justify-content: center;
}

/* Toast通知 */
.toast-notification {
  position: fixed;
  top: 20px;
  right: 20px;
  background: #38A169;
  color: white;
  padding: 12px 20px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  gap: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  z-index: 3000;
  animation: slideInRight 0.3s ease-out;
}

.toast-notification.success {
  background: #38A169;
}

@keyframes slideInRight {
  from {
    opacity: 0;
    transform: translateX(100%);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@media (max-width: 768px) {
  .settings-layout {
    grid-template-columns: 1fr;
  }
  
  .settings-sidebar {
    order: 2;
  }
  
  .settings-content {
    order: 1;
  }
  
  .permissions-grid {
    grid-template-columns: 1fr;
  }
  
  .modal-content {
    width: 95%;
    margin: 20px;
  }
  
  .header-actions {
    flex-direction: column;
    gap: 8px;
  }
  
  .batch-actions {
    flex-wrap: wrap;
  }
  
  .confirm-actions {
    flex-direction: column;
  }
}
</style>
