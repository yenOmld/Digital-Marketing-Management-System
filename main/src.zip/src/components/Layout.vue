<template>
  <div class="layout-container">
    <!-- 左侧导航栏 -->
    <aside class="sidebar" :class="{ 'collapsed': isSidebarCollapsed }">
      <!-- 品牌区域 -->
      <div class="brand-section">
        <div class="logo-container">
          <svg t="1754552916466" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="6337" width="40" height="40"><path fill="currentColor" d="M917 737.6c-15.8-22.8-35.8-40.4-60.2-52.4 22.8-23.4 36.8-55.4 36.8-90.6 0-71.8-58.4-130.4-130.4-130.4s-130.4 58.4-130.4 130.4c0 35 14 66.8 36.6 90.4-24.8 12-45 29.6-60.8 52.8-26.2 38.4-39 90.6-39 159.6 0 16.6 13.4 30 30 30s30-13.4 30-30c0-55.8 9.6-98 28.6-125.8 21-31 55.4-46 105.2-46 57.4 0 133.6 17.8 133.6 171.8 0 16.6 13.4 30 30 30s30-13.4 30-30c0-67.6-13.4-121.4-40-159.8z m-153.6-213.4c38.8 0 70.4 31.6 70.4 70.4s-31.6 70.4-70.4 70.4-70.4-31.6-70.4-70.4 31.6-70.4 70.4-70.4zM521.8 857.6c0 16.6-13.4 30-30 30H193.6c-65 0-117.8-52.8-117.8-117.8v-578C75.8 126.8 128.6 74 193.6 74h558.2c65 0 117.8 52.8 117.8 117.8V400c0 16.6-13.4 30-30 30s-30-13.4-30-30V191.6c0-31.8-26-57.8-57.8-57.8H193.6c-31.8 0-57.8 26-57.8 57.8v578c0 31.8 26 57.8 57.8 57.8h298.2c16.6 0.2 30 13.6 30 30.2z m180-566.2l-174 105c-7.4 4.6-16.6 5.6-24.8 2.8l-134-44.2-116.6 75.4c-5 3.2-10.6 4.8-16.2 4.8-9.8 0-19.4-4.8-25.2-13.8-9-14-5-32.4 8.8-41.4l128.6-83.2c7.6-5 17-6.2 25.6-3.2l134.6 44.4 162.2-97.8c14.2-8.6 32.6-4 41.2 10.2s4 32.6-10.2 41zM254.4 749c-16.6 0-30-13.4-30-30v-143.8c0-16.6 13.4-30 30-30s30 13.4 30 30v143.8c0 16.6-13.6 30-30 30z m224.8 0c-16.6 0-30-13.4-30-30v-91.4c0-16.6 13.4-30 30-30s30 13.4 30 30v91.4c0 16.6-13.6 30-30 30z m-112.4 0c-16.6 0-30-13.4-30-30V494.2c0-16.6 13.4-30 30-30s30 13.4 30 30v225c0 16.4-13.6 29.8-30 29.8z" p-id="6338"></path></svg>
          <span class="brand-name" v-show="!isSidebarCollapsed">智能营销中心</span>
        </div>
        <div class="version-badge" v-show="!isSidebarCollapsed">v0.0</div>
      </div>

      <!-- 导航菜单 -->
      <nav class="nav-menu">
        <div 
          v-for="item in menuItems" 
          :key="item.id"
          class="nav-item"
          :class="{ 'active': item.id === activeMenu }"
          @click="navigateToPage(item.id)"
        >
          <div class="nav-icon" v-html="item.icon"></div>
          <span class="nav-text" v-show="!isSidebarCollapsed">{{ item.name }}</span>
        </div>
      </nav>

      <!-- 折叠按钮 -->
      <div class="collapse-btn" @click="toggleSidebar" :class="{ rotated: isSidebarCollapsed }">
        <svg t="1754569565837" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="71770" width="24" height="24"><path d="M512 512m-465.454545 0a465.454545 465.454545 0 1 0 930.90909 0 465.454545 465.454545 0 1 0-930.90909 0Z" fill="#FFFFFF" p-id="71771"></path><path d="M512 23.272727c269.917091 0 488.727273 218.810182 488.727273 488.727273S781.917091 1000.727273 512 1000.727273 23.272727 781.917091 23.272727 512 242.082909 23.272727 512 23.272727z m0 46.545455a442.181818 442.181818 0 1 0 0 884.363636 442.181818 442.181818 0 0 0 0-884.363636z" fill="#E8E8E8" p-id="71772"></path><path d="M628.736 347.182545a23.272727 23.272727 0 0 0-31.138909-34.629818L395.264 494.685091a23.272727 23.272727 0 0 0 0 34.629818l202.333091 182.132364a23.272727 23.272727 0 1 0 31.185454-34.629818L445.579636 512l183.109819-164.817455z" fill="#595959" p-id="71773"></path></svg>
      </div>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部状态栏 -->
      <header class="top-bar">
        <div class="left-section">
          <nav class="breadcrumb">
            <span>首页</span>
            <span class="separator">/</span>
            <span class="current">{{ currentPageTitle }}</span>
          </nav>
        </div>

        <div class="right-section">
          <!-- 搜索框 -->
          <div class="search-container">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"/>
              <path d="M21 21l-4.35-4.35"/>
            </svg>
            <input type="text" placeholder="搜索功能/客户/内容..." class="search-input" />
          </div>

          <!-- 通知中心 -->
          <div class="notification-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
              <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
            </svg>
            <span class="notification-badge">3</span>
          </div>

          <!-- 用户头像 -->
          <div class="user-section">
            <div class="user-avatar" @click="toggleUserMenu">
              <svg t="1754554038705" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="6857" width="35" height="35"><path d="M508.928 589.824c-149.504 0-270.336-121.856-270.336-270.336S359.424 48.128 508.928 48.128s270.336 121.856 270.336 270.336-120.832 271.36-270.336 271.36z m0-463.872c-106.496 0-192.512 86.016-192.512 192.512S403.456 512 508.928 512c106.496 0 192.512-86.016 192.512-192.512s-86.016-193.536-192.512-193.536zM772.096 989.184H246.784c-97.28 0-176.128-78.848-176.128-176.128s78.848-176.128 176.128-176.128h525.312c97.28 0 176.128 78.848 176.128 176.128s-78.848 176.128-176.128 176.128zM246.784 711.68c-56.32 0-102.4 46.08-102.4 102.4s46.08 102.4 102.4 102.4h525.312c56.32 0 102.4-46.08 102.4-102.4s-46.08-102.4-102.4-102.4H246.784z" fill="#4C4C4C" p-id="6858"></path><path d="M756.736 836.608h-93.184c-21.504 0-38.912-17.408-38.912-38.912s17.408-38.912 38.912-38.912h93.184c21.504 0 38.912 17.408 38.912 38.912s-17.408 38.912-38.912 38.912z" fill="#FFA028" p-id="6859"></path></svg>
            </div>
            <div class="user-menu" v-show="showUserMenu">
              <div class="menu-item">个人资料</div>
              <div class="menu-item">账户设置</div>
              <div class="menu-item" @click="showLogoutConfirm">退出登录</div>
            </div>
          </div>
        </div>
      </header>

      <!-- 页面内容 -->
      <div class="content-area">
        <router-view />
      </div>
    </main>

    <!-- 退出登录确认对话框 -->
    <div v-if="showConfirmDialog" class="confirm-dialog-overlay" @click="closeConfirmDialog">
      <div class="confirm-dialog" @click.stop>
        <div class="dialog-header">
          <h3>确认退出</h3>
        </div>
        <div class="dialog-content">
          <p>您确定要退出登录吗？</p>
        </div>
        <div class="dialog-actions">
          <button class="btn-cancel" @click="closeConfirmDialog">取消</button>
          <button class="btn-confirm" @click="confirmLogout">确认</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()

// 响应式数据
const isSidebarCollapsed = ref(false)
const activeMenu = ref('dashboard')
const showUserMenu = ref(false)
const showConfirmDialog = ref(false)

// 菜单数据 - 使用更简单的图标
const menuItems = [
  {
    id: 'dashboard',
    name: '数据看板',
    path: '/dashboard',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <rect x="3" y="3" width="7" height="7"/>
      <rect x="14" y="3" width="7" height="7"/>
      <rect x="14" y="14" width="7" height="7"/>
      <rect x="3" y="14" width="7" height="7"/>
    </svg>`
  },
  {
    id: 'data-collection',
    name: '数据采集',
    path: '/data-collection',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      <path d="M13 8H7"/>
      <path d="M17 12H7"/>
    </svg>`
  },
  {
    id: 'user-profile',
    name: '用户画像',
    path: '/user-profile',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
      <circle cx="12" cy="7" r="4"/>
    </svg>`
  },
  {
    id: 'marketing',
    name: '营销活动',
    path: '/marketing',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
    </svg>`
  },
  {
    id: 'data-analysis',
    name: '数据分析',
    path: '/data-analysis',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M3 3v18h18"/>
      <path d="M18.7 8l-5.1 5.2-2.8-2.7L7 14.3"/>
    </svg>`
  },
  {
    id: 'customer-management',
    name: '客户管理',
    path: '/customer-management',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
      <circle cx="9" cy="7" r="4"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
      <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>`
  },
  {
    id: 'content-management',
    name: '内容管理',
    path: '/content-management',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
      <path d="M9 9h1"/>
      <path d="M9 13h1"/>
      <path d="M9 17h1"/>
      <path d="M14 9h1"/>
      <path d="M14 13h1"/>
      <path d="M14 17h1"/>
    </svg>`
  },
  {
    id: 'reports',
    name: '报表中心',
    path: '/reports',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
      <polyline points="14,2 14,8 20,8"/>
      <line x1="16" y1="13" x2="8" y2="13"/>
      <line x1="16" y1="17" x2="8" y2="17"/>
      <polyline points="10,9 9,9 8,9"/>
    </svg>`
  },
  {
    id: 'settings',
    name: '系统设置',
    path: '/settings',
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <circle cx="12" cy="12" r="3"/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1 1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
    </svg>`
  }
]

// 计算属性
const currentPageTitle = computed(() => {
  const currentItem = menuItems.find(item => item.id === activeMenu.value)
  return currentItem ? currentItem.name : '数据看板'
})

// 方法
const toggleSidebar = () => {
  isSidebarCollapsed.value = !isSidebarCollapsed.value
}

const navigateToPage = (menuId) => {
  activeMenu.value = menuId
  const menuItem = menuItems.find(item => item.id === menuId)
  if (menuItem) {
    router.push(menuItem.path)
  }
}

const toggleUserMenu = () => {
  showUserMenu.value = !showUserMenu.value
}

const showLogoutConfirm = () => {
  showConfirmDialog.value = true
  showUserMenu.value = false
}

const closeConfirmDialog = () => {
  showConfirmDialog.value = false
}

const confirmLogout = () => {
  showConfirmDialog.value = false
  router.push('/login')
}

// 监听路由变化
import { watch } from 'vue'
watch(() => route.path, (newPath) => {
  const menuItem = menuItems.find(item => item.path === newPath)
  if (menuItem) {
    activeMenu.value = menuItem.id
  }
}, { immediate: true })
</script>

<style scoped>
.layout-container {
  display: flex;
  height: 100vh;
  background: #F7FAFC;
}

/* 左侧导航栏 */
.sidebar {
  width: 240px;
  background: #2D3748;
  display: flex;
  flex-direction: column;
  transition: width 0.3s ease;
}

.sidebar.collapsed {
  width: 64px;
}

.brand-section {
  padding: 20px;
  border-bottom: 1px solid #4A5568;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.logo-container {
  display: flex;
  align-items: center;
  gap: 12px;
  color: #FFFFFF;
}

.brand-name {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 700;
  font-size: 16px;
}

.version-badge {
  background: #2C6FD1;
  color: white;
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #A0AEC0;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  height: 48px;
}

.nav-item:hover {
  background: rgba(44, 111, 209, 0.1);
  color: #FFFFFF;
}

.nav-item.active {
  background: #2C6FD1;
  color: #FFFFFF;
  font-weight: 600;
}

.nav-item.active::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 4px;
  background: #FF6B35;
}

.nav-icon {
  width: 20px;
  height: 20px;
  margin-right: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.nav-text {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-size: 14px;
}

.collapse-btn {
  padding: 16px;
  color: #A0AEC0;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  border-top: 1px solid #4A5568;
  transition: color 0.3s ease;
  transition: transform 0.3s cubic-bezier(.4,2,.6,1);
}

.collapse-btn .icon {
  transition: transform 0.3s cubic-bezier(.4,2,.6,1);
}

.collapse-btn.rotated .icon {
  transform: rotate(180deg);
}

.collapse-btn:hover {
  color: #FFFFFF;
}

/* 主内容区域 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* 顶部状态栏 */
.top-bar {
  height: 64px;
  background: #FFFFFF;
  border-bottom: 1px solid #E2E8F0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
}

.left-section {
  display: flex;
  align-items: center;
  gap: 16px;
}

.breadcrumb {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #718096;
}

.breadcrumb .current {
  color: #2D3748;
  font-weight: 600;
}

.separator {
  color: #CBD5E0;
}

.right-section {
  display: flex;
  align-items: center;
  gap: 16px;
}

.search-container {
  position: relative;
  display: flex;
  align-items: center;
}

.search-container svg {
  position: absolute;
  left: 12px;
  color: #A0AEC0;
}

.search-input {
  width: 300px;
  height: 36px;
  padding: 0 12px 0 36px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
  background: #F7FAFC;
  transition: all 0.3s ease;
}

.search-input:focus {
  outline: none;
  border-color: #2C6FD1;
  background: #FFFFFF;
}

.notification-center {
  position: relative;
  cursor: pointer;
  padding: 8px;
  border-radius: 4px;
  transition: background 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.notification-center:hover {
  background: #F7FAFC;
}

.notification-badge {
  position: absolute;
  top: 0px;
  left: 22px;
  background: #E53E3E;
  color: white;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 10px;
  min-width: 10px;
  text-align: center;
  line-height: 1;
  font-weight: bold;
  box-shadow: 0 1px 4px rgba(0,0,0,0.08);
  pointer-events: none;
  z-index: 1;
}

.user-section {
  position: relative;
}

.user-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
  cursor: pointer;
  border: 2px solid #E2E8F0;
  transition: border-color 0.3s ease;
}

.user-avatar:hover {
  border-color: #2C6FD1;
}

.user-menu {
  position: absolute;
  top: 100%;
  right: 0;
  background: white;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  padding: 8px 0;
  min-width: 120px;
  z-index: 1000;
}

.menu-item {
  padding: 8px 16px;
  font-size: 14px;
  color: #4A5568;
  cursor: pointer;
  transition: background 0.3s ease;
}

.menu-item:hover {
  background: #F7FAFC;
}

/* 内容区域 */
.content-area {
  flex: 1;
  overflow-y: auto;
}

/* 确认对话框样式 */
.confirm-dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}

.confirm-dialog {
  background: white;
  border-radius: 8px;
  padding: 24px;
  min-width: 400px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.dialog-header {
  margin-bottom: 16px;
}

.dialog-header h3 {
  margin: 0;
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 18px;
  color: #2D3748;
}

.dialog-content {
  margin-bottom: 24px;
}

.dialog-content p {
  margin: 0;
  font-size: 14px;
  color: #4A5568;
  line-height: 1.5;
}

.dialog-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}

.btn-cancel, .btn-confirm {
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  border: none;
  transition: all 0.3s ease;
}

.btn-cancel {
  background: #F7FAFC;
  color: #4A5568;
  border: 1px solid #E2E8F0;
}

.btn-cancel:hover {
  background: #EDF2F7;
}

.btn-confirm {
  background: #E53E3E;
  color: white;
}

.btn-confirm:hover {
  background: #C53030;
}
</style>
