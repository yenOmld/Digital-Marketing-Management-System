<template>
  <div class="user-profile-container">
    <!-- 页面标题和工具栏 -->
    <div class="page-header">
      <div class="header-left">
      <h1>用户画像</h1>
      <p>分析用户行为特征，构建精准用户画像</p>
      </div>
      <div class="header-controls">
        <button class="generate-btn" @click="generateRandomUser">
          <span class="btn-icon">🎲</span>
          随机生成
        </button>
        <button 
          :class="['compare-btn', { active: compareMode }]"
          @click="toggleCompareMode"
        >
          <span class="btn-icon">⚖️</span>
          对比模式
        </button>
      </div>
    </div>

    <!-- 用户搜索与切换控制区 -->
    <div class="search-controls">
      <div class="search-section">
        <div class="search-box">
          <input 
            v-model="searchQuery" 
            type="text" 
            placeholder="输入ID/手机/昵称"
            @input="searchUser"
          />
          <button class="search-btn" @click="searchUser">
            <span class="btn-icon">🔍</span>
          </button>
        </div>
        <div class="example-users">
          <button 
            v-for="user in exampleUsers" 
            :key="user.id"
            class="example-btn"
            @click="loadExampleUser(user)"
          >
            {{ user.name }}
          </button>
        </div>
      </div>
      
      <div class="view-controls">
        <div class="view-tabs">
          <button 
            :class="['tab-btn', { active: currentView === 'individual' }]"
            @click="setView('individual')"
          >
            个体画像
          </button>
          <button 
            :class="['tab-btn', { active: currentView === 'group' }]"
            @click="setView('group')"
          >
            群体画像
          </button>
        </div>
        
        <div v-if="currentView === 'individual'" class="user-navigation">
          <button class="nav-btn" @click="previousUser">
            <span class="btn-icon">←</span>
            上一个
          </button>
          <span class="user-counter">{{ currentUserIndex + 1 }} / {{ totalUsers }}</span>
          <button class="nav-btn" @click="nextUser">
            下一个
            <span class="btn-icon">→</span>
          </button>
        </div>
      </div>
    </div>

    <!-- 主要内容区域 -->
    <div class="main-content" :class="{ 'compare-mode': compareMode }">
      <!-- 个体画像区域 -->
      <div v-if="currentView === 'individual'" class="individual-section">
        <div class="profile-card">
          <div class="profile-header">
            <div class="avatar-section">
              <div class="avatar">{{ currentUser.avatar }}</div>
              <div class="user-info">
                <h3>{{ currentUser.nickname }}</h3>
                <p class="user-id">ID: {{ currentUser.id }}</p>
                <span :class="['value-tag', currentUser.valueLevel]">
                  {{ getValueLevelText(currentUser.valueLevel) }}
                </span>
              </div>
            </div>
            <div class="basic-info">
              <div class="info-item">
                <span class="info-label">性别</span>
                <span class="info-value">{{ currentUser.gender }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">年龄</span>
                <span class="info-value">{{ currentUser.age }}岁</span>
              </div>
              <div class="info-item">
                <span class="info-label">地域</span>
                <span class="info-value">{{ currentUser.location }}</span>
              </div>
            </div>
          </div>
          
          <div class="behavior-section">
            <h4>行为特征</h4>
            <div class="behavior-grid">
              <div class="behavior-item">
                <span class="behavior-label">最近活跃</span>
                <span class="behavior-value">{{ currentUser.lastActive }}</span>
              </div>
              <div class="behavior-item">
                <span class="behavior-label">偏好渠道</span>
                <span class="behavior-value">{{ currentUser.preferredChannel }}</span>
              </div>
              <div class="behavior-item">
                <span class="behavior-label">内容倾向</span>
                <div class="content-preference">
                  <div class="preference-bar">
                    <div class="video-pref" :style="{ width: currentUser.contentPreference.video + '%' }">
                      视频 {{ currentUser.contentPreference.video }}%
                    </div>
                    <div class="text-pref" :style="{ width: currentUser.contentPreference.text + '%' }">
                      图文 {{ currentUser.contentPreference.text }}%
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 标签管理面板 -->
        <div class="tag-management">
          <div class="tag-header">
            <h3>标签管理</h3>
            <button class="add-tag-btn" @click="showAddTagModal = true">
              <span class="btn-icon">+</span>
              添加标签
            </button>
          </div>
          
          <div class="tag-sections">
            <div class="tag-section">
              <h4>预置标签</h4>
              <div class="tag-list">
                <span 
                  v-for="tag in presetTags" 
                  :key="tag.id"
                  :class="['tag', { active: tag.active }]"
                  @click="toggleTag(tag)"
                >
                  {{ tag.name }}
                </span>
              </div>
    </div>
    
            <div class="tag-section">
              <h4>自定义标签</h4>
              <div class="tag-list">
                <span 
                  v-for="tag in customTags" 
                  :key="tag.id"
                  :class="['tag', 'custom', { active: tag.active }]"
                  @click="toggleTag(tag)"
                >
                  {{ tag.name }}
                  <span class="remove-tag" @click.stop="removeTag(tag)">×</span>
                </span>
            </div>
            </div>
          </div>
          
          <div class="tag-combination">
            <h4>标签组合</h4>
            <div class="combination-controls">
              <select v-model="combinationType">
                <option value="AND">AND (且)</option>
                <option value="OR">OR (或)</option>
              </select>
              <button class="apply-btn" @click="applyTagCombination">
                应用筛选
              </button>
            </div>
            </div>
            </div>
          </div>

      <!-- 群体画像区域 -->
      <div v-if="currentView === 'group'" class="group-section">
        <div class="group-visualization">
          <div class="chart-section">
            <h3>年龄分布</h3>
            <div class="pie-chart">
              <svg width="200" height="200" viewBox="0 0 200 200">
                <circle cx="100" cy="100" r="80" fill="none" stroke="#E5E7EB" stroke-width="16"/>
                <circle cx="100" cy="100" r="80" fill="none" stroke="#4F46E5" stroke-width="16" 
                        stroke-dasharray="251.2" stroke-dashoffset="75.36" transform="rotate(-90 100 100)"/>
                <circle cx="100" cy="100" r="80" fill="none" stroke="#10B981" stroke-width="16" 
                        stroke-dasharray="251.2" stroke-dashoffset="150.72" transform="rotate(-90 100 100)"/>
                <circle cx="100" cy="100" r="80" fill="none" stroke="#F59E0B" stroke-width="16" 
                        stroke-dasharray="251.2" stroke-dashoffset="188.4" transform="rotate(-90 100 100)"/>
                <circle cx="100" cy="100" r="80" fill="none" stroke="#EF4444" stroke-width="16" 
                        stroke-dasharray="251.2" stroke-dashoffset="226.08" transform="rotate(-90 100 100)"/>
              </svg>
              <div class="pie-legend">
                <div class="legend-item">
                  <span class="legend-color" style="background: #4F46E5"></span>
                  <span>18-24岁 (25%)</span>
                </div>
                <div class="legend-item">
                  <span class="legend-color" style="background: #10B981"></span>
                  <span>25-30岁 (45%)</span>
                </div>
                <div class="legend-item">
                  <span class="legend-color" style="background: #F59E0B"></span>
                  <span>31-40岁 (20%)</span>
            </div>
                <div class="legend-item">
                  <span class="legend-color" style="background: #EF4444"></span>
                  <span>40岁以上 (10%)</span>
            </div>
          </div>
        </div>
      </div>

          <div class="tag-cloud-section">
            <h3>特征标签云</h3>
            <div class="tag-cloud">
              <span 
                v-for="tag in groupTags" 
                :key="tag.id"
                :class="['cloud-tag', `size-${tag.size}`]"
                :style="{ fontSize: tag.size * 2 + 12 + 'px' }"
              >
                {{ tag.name }}
              </span>
            </div>
          </div>
        </div>
      </div>
            </div>

    <!-- 对比模式下的第二列 -->
    <div v-if="compareMode && currentView === 'individual'" class="compare-section">
      <div class="profile-card">
        <div class="profile-header">
          <div class="avatar-section">
            <div class="avatar">{{ compareUser.avatar }}</div>
            <div class="user-info">
              <h3>{{ compareUser.nickname }}</h3>
              <p class="user-id">ID: {{ compareUser.id }}</p>
              <span :class="['value-tag', compareUser.valueLevel]">
                {{ getValueLevelText(compareUser.valueLevel) }}
              </span>
            </div>
          </div>
          <div class="basic-info">
            <div class="info-item">
              <span class="info-label">性别</span>
              <span class="info-value">{{ compareUser.gender }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">年龄</span>
              <span class="info-value">{{ compareUser.age }}岁</span>
            </div>
            <div class="info-item">
              <span class="info-label">地域</span>
              <span class="info-value">{{ compareUser.location }}</span>
            </div>
            </div>
        </div>
        
        <div class="behavior-section">
          <h4>行为特征</h4>
          <div class="behavior-grid">
            <div class="behavior-item">
              <span class="behavior-label">最近活跃</span>
              <span class="behavior-value">{{ compareUser.lastActive }}</span>
            </div>
            <div class="behavior-item">
              <span class="behavior-label">偏好渠道</span>
              <span class="behavior-value">{{ compareUser.preferredChannel }}</span>
          </div>
          <div class="behavior-item">
              <span class="behavior-label">内容倾向</span>
              <div class="content-preference">
                <div class="preference-bar">
                  <div class="video-pref" :style="{ width: compareUser.contentPreference.video + '%' }">
                    视频 {{ compareUser.contentPreference.video }}%
                  </div>
                  <div class="text-pref" :style="{ width: compareUser.contentPreference.text + '%' }">
                    图文 {{ compareUser.contentPreference.text }}%
                  </div>
            </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 添加标签模态框 -->
    <div v-if="showAddTagModal" class="modal-overlay" @click="showAddTagModal = false">
      <div class="modal-content" @click.stop>
        <h3>添加自定义标签</h3>
        <input 
          v-model="newTagName" 
          type="text" 
          placeholder="输入标签名称"
          @keyup.enter="addCustomTag"
        />
        <div class="modal-actions">
          <button class="cancel-btn" @click="showAddTagModal = false">取消</button>
          <button class="confirm-btn" @click="addCustomTag">确认</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'

// 视图状态
const currentView = ref('individual')
const compareMode = ref(false)
const searchQuery = ref('')
const currentUserIndex = ref(0)
const showAddTagModal = ref(false)
const newTagName = ref('')
const combinationType = ref('AND')

// 示例用户
const exampleUsers = reactive([
  { id: 'user001', name: '电商用户' },
  { id: 'user002', name: '视频用户' },
  { id: 'user003', name: '流失用户' }
])

// 当前用户数据
const currentUser = reactive({
  id: 'U2024001',
  nickname: '张小美',
  avatar: '👩',
  valueLevel: 'high',
  gender: '女',
  age: 28,
  location: '北京',
  lastActive: '3天前',
  preferredChannel: 'APP',
  contentPreference: {
    video: 60,
    text: 40
  }
})

// 对比用户数据
const compareUser = reactive({
  id: 'U2024002',
  nickname: '李小明',
  avatar: '👨',
  valueLevel: 'medium',
  gender: '男',
  age: 32,
  location: '上海',
  lastActive: '1天前',
  preferredChannel: '微信',
  contentPreference: {
    video: 30,
    text: 70
  }
})

// 预置标签
const presetTags = reactive([
  { id: 1, name: '新用户', active: false },
  { id: 2, name: '高价值', active: true },
  { id: 3, name: '流失风险', active: false }
])

// 自定义标签
const customTags = reactive([
  { id: 101, name: '科技爱好者', active: false },
  { id: 102, name: '周末活跃', active: true }
])

// 群体标签
const groupTags = reactive([
  { id: 1, name: '高消费力', size: 3 },
  { id: 2, name: '科技爱好者', size: 2 },
  { id: 3, name: '周末活跃', size: 4 },
  { id: 4, name: '母婴群体', size: 2 },
  { id: 5, name: '年轻妈妈', size: 3 },
  { id: 6, name: '商务人士', size: 2 },
  { id: 7, name: '大学生', size: 1 }
])

// 计算属性
const totalUsers = computed(() => 1000)
const getValueLevelText = (level) => {
  const texts = {
    high: '高潜力',
    medium: '普通',
    low: '休眠'
  }
  return texts[level] || '普通'
}

// 方法
const setView = (view) => {
  currentView.value = view
}

const toggleCompareMode = () => {
  compareMode.value = !compareMode.value
}

const generateRandomUser = () => {
  // 模拟随机生成用户
  const users = [
    { nickname: '年轻妈妈', avatar: '👩‍👧', valueLevel: 'high' },
    { nickname: '商务人士', avatar: '👨‍💼', valueLevel: 'medium' },
    { nickname: '大学生', avatar: '👨‍🎓', valueLevel: 'low' }
  ]
  const randomUser = users[Math.floor(Math.random() * users.length)]
  Object.assign(currentUser, randomUser)
  console.log('生成随机用户:', randomUser)
}

const searchUser = () => {
  console.log('搜索用户:', searchQuery.value)
}

const loadExampleUser = (user) => {
  console.log('加载示例用户:', user)
}

const previousUser = () => {
  if (currentUserIndex.value > 0) {
    currentUserIndex.value--
  }
}

const nextUser = () => {
  if (currentUserIndex.value < totalUsers.value - 1) {
    currentUserIndex.value++
  }
}

const toggleTag = (tag) => {
  tag.active = !tag.active
}

const removeTag = (tag) => {
  const index = customTags.findIndex(t => t.id === tag.id)
  if (index > -1) {
    customTags.splice(index, 1)
  }
}

const addCustomTag = () => {
  if (newTagName.value.trim()) {
    const newTag = {
      id: Date.now(),
      name: newTagName.value.trim(),
      active: false
    }
    customTags.push(newTag)
    newTagName.value = ''
    showAddTagModal.value = false
  }
}

const applyTagCombination = () => {
  const activeTags = [...presetTags, ...customTags].filter(tag => tag.active)
  console.log('应用标签组合:', { type: combinationType.value, tags: activeTags })
}
</script>

<style scoped>
.user-profile-container {
  padding: 24px;
  background: #F8FAFC;
  min-height: 100vh;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}

.header-left {
  text-align: center;
  flex: 1;
}

.header-left h1 {
  font-size: 28px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.header-left p {
  color: #718096;
  margin: 0;
}

.header-controls {
  display: flex;
  gap: 16px;
  align-items: center;
}

.generate-btn, .compare-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.generate-btn {
  background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
  color: white;
}

.compare-btn {
  background: #E2E8F0;
  color: #4A5568;
}

.compare-btn.active {
  background: #4F46E5;
  color: white;
}

.btn-icon {
  font-size: 16px;
}

.search-controls {
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin-bottom: 24px;
}

.search-section {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.search-box {
  display: flex;
  align-items: center;
  flex: 1;
  max-width: 400px;
}

.search-box input {
  flex: 1;
  padding: 12px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px 0 0 8px;
  font-size: 14px;
  outline: none;
}

.search-box input:focus {
  border-color: #4F46E5;
}

.search-btn {
  padding: 12px 16px;
  background: #4F46E5;
  color: white;
  border: none;
  border-radius: 0 8px 8px 0;
  cursor: pointer;
}

.example-users {
  display: flex;
  gap: 8px;
}

.example-btn {
  padding: 8px 16px;
  background: #F7FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.example-btn:hover {
  background: #4F46E5;
  color: white;
  border-color: #4F46E5;
}

.view-controls {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.view-tabs {
  display: flex;
  background: #E2E8F0;
  border-radius: 8px;
  padding: 4px;
}

.tab-btn {
  padding: 8px 16px;
  border: none;
  background: transparent;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
}

.tab-btn.active {
  background: white;
  color: #4F46E5;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.user-navigation {
  display: flex;
  align-items: center;
  gap: 12px;
}

.nav-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px 12px;
  background: #4F46E5;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 12px;
  cursor: pointer;
}

.user-counter {
  font-size: 14px;
  color: #718096;
}

.main-content {
  display: grid;
  grid-template-columns: 1fr;
  gap: 24px;
}

.main-content.compare-mode {
  grid-template-columns: 1fr 1fr;
}

.individual-section {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 24px;
}

.profile-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.profile-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}

.avatar-section {
  display: flex;
  align-items: center;
  gap: 16px;
}

.avatar {
  width: 60px;
  height: 60px;
  background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  color: white;
}

.user-info h3 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 4px 0;
}

.user-id {
  font-size: 14px;
  color: #718096;
  margin: 0 0 8px 0;
}

.value-tag {
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.value-tag.high {
  background: #DEF7EC;
  color: #03543F;
}

.value-tag.medium {
  background: #FEF3C7;
  color: #92400E;
}

.value-tag.low {
  background: #FDE8E8;
  color: #9B1C1C;
}

.basic-info {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.info-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-width: 120px;
}

.info-label {
  font-size: 14px;
  color: #718096;
}

.info-value {
  font-size: 14px;
  font-weight: 500;
  color: #1A202C;
}

.behavior-section h4 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 16px 0;
}

.behavior-grid {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.behavior-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px;
  background: #F7FAFC;
  border-radius: 8px;
}

.behavior-label {
  font-size: 14px;
  color: #4A5568;
}

.behavior-value {
  font-size: 14px;
  font-weight: 500;
  color: #1A202C;
}

.content-preference {
  flex: 1;
  max-width: 200px;
}

.preference-bar {
  display: flex;
  height: 20px;
  border-radius: 10px;
  overflow: hidden;
}

.video-pref {
  background: #4F46E5;
  color: white;
  font-size: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: width 0.3s;
}

.text-pref {
  background: #10B981;
  color: white;
  font-size: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: width 0.3s;
}

.tag-management {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.tag-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.tag-header h3 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.add-tag-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px 12px;
  background: #4F46E5;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 12px;
  cursor: pointer;
}

.tag-sections {
  margin-bottom: 20px;
}

.tag-section {
  margin-bottom: 16px;
}

.tag-section h4 {
  font-size: 14px;
  font-weight: 600;
  color: #4A5568;
  margin: 0 0 12px 0;
}

.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.tag {
  padding: 6px 12px;
  background: #F7FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}

.tag.active {
  background: #4F46E5;
  color: white;
  border-color: #4F46E5;
}

.tag.custom {
  background: #FEF3C7;
  border-color: #F59E0B;
}

.remove-tag {
  margin-left: 4px;
  font-weight: bold;
  color: #DC2626;
}

.tag-combination h4 {
  font-size: 14px;
  font-weight: 600;
  color: #4A5568;
  margin: 0 0 12px 0;
}

.combination-controls {
  display: flex;
  gap: 12px;
  align-items: center;
}

.combination-controls select {
  padding: 8px 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  background: white;
  font-size: 14px;
}

.apply-btn {
  padding: 8px 16px;
  background: #10B981;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
}

.group-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.group-visualization {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}

.chart-section h3, .tag-cloud-section h3 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 20px 0;
}

.pie-chart {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
}

.pie-legend {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: #4A5568;
}

.legend-color {
  width: 12px;
  height: 12px;
  border-radius: 2px;
}

.tag-cloud {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  justify-content: center;
}

.cloud-tag {
  padding: 8px 16px;
  background: #F7FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.2s;
  color: #4A5568;
}

.cloud-tag:hover {
  background: #4F46E5;
  color: white;
  transform: scale(1.05);
}

.compare-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  padding: 24px;
  min-width: 300px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.modal-content h3 {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 16px 0;
}

.modal-content input {
  width: 250px;
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
  margin-bottom: 16px;
}

.modal-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}

.cancel-btn, .confirm-btn {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
}

.cancel-btn {
  background: #E2E8F0;
  color: #4A5568;
}

.confirm-btn {
  background: #4F46E5;
  color: white;
}

@media (max-width: 1024px) {
  .individual-section {
    grid-template-columns: 1fr;
  }
  
  .group-visualization {
    grid-template-columns: 1fr;
  }
  
  .main-content.compare-mode {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .header-controls {
    width: 100%;
    justify-content: center;
  }
  
  .search-section {
    flex-direction: column;
    gap: 16px;
  }
  
  .view-controls {
    flex-direction: column;
    gap: 16px;
  }
}
</style>
