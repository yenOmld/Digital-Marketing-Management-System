<template>
  <div class="data-collection-container">
    <!-- 页面标题和工具栏 -->
    <div class="page-header">
      <div class="header-left">
        <h1>数据采集</h1>
        <p>精准引流获客平台 - 全方位数据采集与用户行为跟踪</p>
      </div>
      <div class="header-controls">
        <button class="btn-secondary" @click="exportData">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7,10 12,15 17,10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          导出数据
        </button>
        <button class="btn-primary" @click="showCreateRuleModal = true">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 5v14M5 12h14"/>
          </svg>
          新建采集规则
        </button>
      </div>
    </div>

    <!-- 数据概览卡片 -->
    <div class="overview-cards">
      <div class="overview-card">
        <div class="card-icon" style="background: #2C6FD1">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            <path d="M13 8H7"/>
            <path d="M17 12H7"/>
          </svg>
        </div>
        <div class="card-content">
          <h3>今日采集数据</h3>
          <div class="card-value">156,789</div>
          <div class="card-trend positive">↑12.5%</div>
        </div>
      </div>
      
      <div class="overview-card">
        <div class="card-icon" style="background: #38A169">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
        </div>
        <div class="card-content">
          <h3>活跃用户数</h3>
          <div class="card-value">45,632</div>
          <div class="card-trend positive">↑8.3%</div>
        </div>
      </div>
      
      <div class="overview-card">
        <div class="card-icon" style="background: #FF6B35">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
          </svg>
        </div>
        <div class="card-content">
          <h3>转化率</h3>
          <div class="card-value">15.8%</div>
          <div class="card-trend positive">↑2.1%</div>
        </div>
      </div>
      
      <div class="overview-card">
        <div class="card-icon" style="background: #805AD5">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M3 3v18h18"/>
            <path d="M18.7 8l-5.1 5.2-2.8-2.7L7 14.3"/>
          </svg>
        </div>
        <div class="card-content">
          <h3>数据源连接</h3>
          <div class="card-value">12/15</div>
          <div class="card-trend neutral">正常</div>
        </div>
      </div>
    </div>
    
    <!-- 主要内容区域 -->
    <div class="main-content">
      <!-- 左侧：数据源管理 -->
      <div class="left-panel">
      <!-- 数据源配置 -->
        <div class="panel-card">
          <div class="panel-header">
            <h3>数据源管理</h3>
            <button class="btn-secondary">配置</button>
          </div>
          
          <div class="data-sources">
            <div class="source-item active">
              <div class="source-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 2L2 7l10 5 10-5-10-5z"/>
                  <path d="M2 17l10 5 10-5"/>
                  <path d="M2 12l10 5 10-5"/>
                </svg>
              </div>
              <div class="source-info">
                <h4>网站流量数据</h4>
                <p>JavaScript SDK 埋点采集</p>
                <div class="source-stats">
                  <span>今日: 89,456条</span>
                  <span class="status-badge success">正常</span>
                </div>
              </div>
            </div>
            
            <div class="source-item">
              <div class="source-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                  <circle cx="9" cy="7" r="4"/>
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                  <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
              </div>
              <div class="source-info">
                <h4>社交媒体数据</h4>
                <p>微信、微博、抖音等平台</p>
                <div class="source-stats">
                  <span>今日: 34,567条</span>
                  <span class="status-badge success">正常</span>
                </div>
              </div>
            </div>
            
            <div class="source-item warning">
              <div class="source-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14,2 14,8 20,8"/>
                  <line x1="16" y1="13" x2="8" y2="13"/>
                  <line x1="16" y1="17" x2="8" y2="17"/>
                  <polyline points="10,9 9,9 8,9"/>
                </svg>
              </div>
              <div class="source-info">
                <h4>第三方API</h4>
                <p>CRM、ERP系统数据接入</p>
                <div class="source-stats">
                  <span>今日: 12,345条</span>
                  <span class="status-badge warning">延迟</span>
                </div>
            </div>
          </div>
            
            <div class="source-item">
              <div class="source-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
            </div>
              <div class="source-info">
                <h4>移动端数据</h4>
                <p>iOS/Android应用数据</p>
                <div class="source-stats">
                  <span>今日: 23,456条</span>
                  <span class="status-badge success">正常</span>
          </div>
            </div>
          </div>
        </div>
      </div>

        <!-- 采集规则配置 -->
        <div class="panel-card">
          <div class="panel-header">
        <h3>采集规则</h3>
            <button class="btn-secondary">管理</button>
          </div>
          
          <div class="rules-list">
            <div class="rule-item active">
            <div class="rule-header">
                <h4>用户行为追踪</h4>
                <span class="rule-status success">运行中</span>
              </div>
              <p class="rule-desc">监控用户浏览、点击、搜索等行为</p>
              <div class="rule-metrics">
                <div class="metric">
                  <span class="metric-label">采集量</span>
                  <span class="metric-value">89,456</span>
            </div>
                <div class="metric">
                  <span class="metric-label">成功率</span>
                  <span class="metric-value">98.5%</span>
            </div>
            </div>
          </div>
            
          <div class="rule-item">
            <div class="rule-header">
                <h4>页面访问统计</h4>
              <span class="rule-status">已停止</span>
            </div>
              <p class="rule-desc">统计页面PV、UV、停留时间</p>
              <div class="rule-metrics">
                <div class="metric">
                  <span class="metric-label">采集量</span>
                  <span class="metric-value">0</span>
                </div>
                <div class="metric">
                  <span class="metric-label">成功率</span>
                  <span class="metric-value">0%</span>
                </div>
              </div>
            </div>
            
            <div class="rule-item active">
              <div class="rule-header">
                <h4>转化漏斗分析</h4>
                <span class="rule-status success">运行中</span>
              </div>
              <p class="rule-desc">跟踪用户从访问到转化的完整路径</p>
              <div class="rule-metrics">
                <div class="metric">
                  <span class="metric-label">采集量</span>
                  <span class="metric-value">45,678</span>
            </div>
                <div class="metric">
                  <span class="metric-label">成功率</span>
                  <span class="metric-value">96.2%</span>
            </div>
          </div>
        </div>
          </div>
        </div>
      </div>

      <!-- 右侧：实时监控 -->
      <div class="right-panel">
        <!-- 实时数据流 -->
        <div class="panel-card">
          <div class="panel-header">
            <h3>实时数据流</h3>
            <div class="time-display">{{ currentTime }}</div>
          </div>
          
          <div class="realtime-stream">
            <div class="stream-item" v-for="item in realtimeData" :key="item.id">
              <div class="stream-icon" :class="item.type">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
              </div>
              <div class="stream-content">
                <div class="stream-title">{{ item.title }}</div>
                <div class="stream-desc">{{ item.description }}</div>
              </div>
              <div class="stream-time">{{ item.time }}</div>
            </div>
          </div>
        </div>

        <!-- 用户行为热力图 -->
        <div class="panel-card">
          <div class="panel-header">
            <h3>用户行为热力图</h3>
            <div class="heatmap-controls">
              <button class="btn-sm active">今日</button>
              <button class="btn-sm">本周</button>
              <button class="btn-sm">本月</button>
            </div>
          </div>
          
          <div class="heatmap-container">
            <div class="heatmap-grid">
              <div class="heatmap-cell" 
                   v-for="(cell, index) in heatmapData" 
                   :key="index"
                   :style="{ opacity: cell.intensity }">
              </div>
            </div>
            <div class="heatmap-legend">
              <span>低</span>
              <div class="legend-gradient"></div>
              <span>高</span>
            </div>
          </div>
        </div>

        <!-- 数据质量监控 -->
        <div class="panel-card">
          <div class="panel-header">
            <h3>数据质量监控</h3>
            <span class="quality-score">98.5%</span>
          </div>
          
          <div class="quality-metrics">
            <div class="quality-item">
              <div class="quality-label">数据完整性</div>
              <div class="quality-bar">
                <div class="quality-fill" style="width: 96%"></div>
              </div>
              <div class="quality-value">96%</div>
            </div>
            
            <div class="quality-item">
              <div class="quality-label">数据准确性</div>
              <div class="quality-bar">
                <div class="quality-fill" style="width: 98%"></div>
              </div>
              <div class="quality-value">98%</div>
            </div>
            
            <div class="quality-item">
              <div class="quality-label">数据及时性</div>
              <div class="quality-bar">
                <div class="quality-fill" style="width: 99%"></div>
              </div>
              <div class="quality-value">99%</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 新建采集规则弹窗 -->
    <div v-if="showCreateRuleModal" class="modal-overlay" @click="closeCreateRuleModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>新建采集规则</h3>
          <button class="modal-close" @click="closeCreateRuleModal">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
        
        <div class="modal-body">
          <div class="form-group">
            <label>规则名称</label>
            <input 
              v-model="newRule.name" 
              type="text" 
              placeholder="请输入规则名称"
              class="form-input"
            />
          </div>
          
          <div class="form-group">
            <label>规则类型</label>
            <select v-model="newRule.type" class="form-select">
              <option value="">请选择规则类型</option>
              <option value="pageview">页面访问统计</option>
              <option value="click">点击行为追踪</option>
              <option value="scroll">滚动行为追踪</option>
              <option value="form">表单提交追踪</option>
              <option value="conversion">转化漏斗分析</option>
              <option value="custom">自定义事件</option>
            </select>
          </div>
          
          <div class="form-group">
            <label>目标页面</label>
            <input 
              v-model="newRule.targetUrl" 
              type="text" 
              placeholder="请输入目标页面URL或选择器"
              class="form-input"
            />
          </div>
          
          <div class="form-group">
            <label>触发条件</label>
            <div class="trigger-options">
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.triggers.pageLoad" />
                <span>页面加载时</span>
              </label>
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.triggers.click" />
                <span>点击事件</span>
              </label>
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.triggers.scroll" />
                <span>滚动事件</span>
              </label>
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.triggers.timeout" />
                <span>停留时间</span>
              </label>
            </div>
          </div>
          
          <div class="form-group" v-if="newRule.triggers.timeout">
            <label>停留时间阈值（秒）</label>
            <input 
              v-model="newRule.timeoutThreshold" 
              type="number" 
              placeholder="30"
              class="form-input"
            />
          </div>
          
          <div class="form-group">
            <label>数据采集字段</label>
            <div class="field-options">
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.fields.userId" />
                <span>用户ID</span>
              </label>
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.fields.pageUrl" />
                <span>页面URL</span>
              </label>
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.fields.timestamp" />
                <span>时间戳</span>
              </label>
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.fields.userAgent" />
                <span>用户代理</span>
              </label>
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.fields.referrer" />
                <span>来源页面</span>
              </label>
              <label class="checkbox-item">
                <input type="checkbox" v-model="newRule.fields.sessionId" />
                <span>会话ID</span>
              </label>
            </div>
          </div>
          
          <div class="form-group">
            <label>规则描述</label>
            <textarea 
              v-model="newRule.description" 
              placeholder="请输入规则描述"
              class="form-textarea"
              rows="3"
            ></textarea>
          </div>
        </div>
        
        <div class="modal-footer">
          <button class="btn-cancel" @click="closeCreateRuleModal">取消</button>
          <button class="btn-confirm" @click="createNewRule">创建规则</button>
                 </div>
       </div>
     </div>

     <!-- 自定义提示弹窗 -->
     <div v-if="showAlertModal" class="alert-modal-overlay" @click="closeAlertModal">
       <div class="alert-modal-content" @click.stop>
         <div class="alert-icon" :class="alertType">
           <svg v-if="alertType === 'success'" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
             <path d="M20 6L9 17L4 12"/>
           </svg>
           <svg v-else-if="alertType === 'error'" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
             <circle cx="12" cy="12" r="10"/>
             <line x1="15" y1="9" x2="9" y2="15"/>
             <line x1="9" y1="9" x2="15" y2="15"/>
           </svg>
           <svg v-else-if="alertType === 'warning'" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
             <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
             <line x1="12" y1="9" x2="12" y2="13"/>
             <line x1="12" y1="17" x2="12.01" y2="17"/>
           </svg>
         </div>
         <div class="alert-message">{{ alertMessage }}</div>
         <button class="alert-close-btn" @click="closeAlertModal">确定</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

// 响应式数据
const currentTime = ref('')
const showCreateRuleModal = ref(false)
const showAlertModal = ref(false)
const alertMessage = ref('')
const alertType = ref('success') // success, error, warning
const newRule = ref({
  name: '',
  type: '',
  targetUrl: '',
  description: '',
  timeoutThreshold: 30,
  triggers: {
    pageLoad: false,
    click: false,
    scroll: false,
    timeout: false
  },
  fields: {
    userId: true,
    pageUrl: true,
    timestamp: true,
    userAgent: false,
    referrer: false,
    sessionId: false
  }
})

const realtimeData = ref([
  {
    id: 1,
    type: 'pageview',
    title: '页面访问',
    description: '用户访问了产品详情页',
    time: '刚刚'
  },
  {
    id: 2,
    type: 'click',
    title: '按钮点击',
    description: '用户点击了"立即咨询"按钮',
    time: '2分钟前'
  },
  {
    id: 3,
    type: 'search',
    title: '搜索行为',
    description: '用户搜索了"营销解决方案"',
    time: '5分钟前'
  },
  {
    id: 4,
    type: 'form',
    title: '表单提交',
    description: '用户提交了联系方式',
    time: '8分钟前'
  },
  {
    id: 5,
    type: 'social',
    title: '社交媒体',
    description: '用户通过微信分享页面',
    time: '12分钟前'
  }
])

const heatmapData = ref([])

// 生成热力图数据
const generateHeatmapData = () => {
  const data = []
  for (let i = 0; i < 168; i++) { // 7天 * 24小时
    data.push({
      intensity: Math.random() * 0.8 + 0.2
    })
  }
  heatmapData.value = data
}

// 更新时间
const updateTime = () => {
  const now = new Date()
  currentTime.value = now.toLocaleTimeString('zh-CN', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
}

// 定时器
let timeInterval

// 方法
const closeCreateRuleModal = () => {
  showCreateRuleModal.value = false
  resetNewRule()
}

const resetNewRule = () => {
  newRule.value = {
    name: '',
    type: '',
    targetUrl: '',
    description: '',
    timeoutThreshold: 30,
    triggers: {
      pageLoad: false,
      click: false,
      scroll: false,
      timeout: false
    },
    fields: {
      userId: true,
      pageUrl: true,
      timestamp: true,
      userAgent: false,
      referrer: false,
      sessionId: false
    }
  }
}

const createNewRule = () => {
  // 验证必填字段
  if (!newRule.value.name || !newRule.value.type) {
    showCustomAlert('请填写规则名称和规则类型', 'error')
    return
  }
  
  // 验证至少选择一个触发条件
  const hasTrigger = Object.values(newRule.value.triggers).some(trigger => trigger)
  if (!hasTrigger) {
    showCustomAlert('请至少选择一个触发条件', 'error')
    return
  }
  
  // 验证至少选择一个数据字段
  const hasField = Object.values(newRule.value.fields).some(field => field)
  if (!hasField) {
    showCustomAlert('请至少选择一个数据采集字段', 'error')
    return
  }
  
  // 创建新规则
  console.log('创建新规则:', newRule.value)
  
  // 这里可以调用API保存规则
  // 模拟成功创建
  showCustomAlert('规则创建成功！', 'success')
  
  // 关闭弹窗并重置表单
  closeCreateRuleModal()
}

const showCustomAlert = (message, type = 'success') => {
  alertMessage.value = message
  alertType.value = type
  showAlertModal.value = true
}

const closeAlertModal = () => {
  showAlertModal.value = false
}

// 导出数据
const exportData = () => {
  // 模拟导出数据功能
  showCustomAlert('数据导出功能开发中...', 'warning')
}

onMounted(() => {
  generateHeatmapData()
  updateTime()
  timeInterval = setInterval(updateTime, 1000)
})

onUnmounted(() => {
  if (timeInterval) {
    clearInterval(timeInterval)
  }
})
</script>

<style scoped>
.data-collection-container {
  padding: 24px;
  background: #F7FAFC;
  min-height: 100vh;
}

/* 页面标题和工具栏 */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 32px;
}

.header-left {
  text-align: center;
  flex: 1;
}

.header-left h1 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 700;
  font-size: 28px;
  color: #2D3748;
  margin: 0 0 8px 0;
}

.header-left p {
  color: #718096;
  font-size: 16px;
  margin: 0;
}

.header-controls {
  display: flex;
  gap: 12px;
  align-items: center;
}

.btn-primary {
  background: #2C6FD1;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 12px 20px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.3s ease;
}

.btn-primary:hover {
  background: #1E5AB9;
}

/* 概览卡片 */
.overview-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 32px;
}

.overview-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
  display: flex;
  align-items: center;
  gap: 16px;
}

.card-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.card-content h3 {
  font-size: 14px;
  color: #718096;
  margin: 0 0 8px 0;
  font-weight: 500;
}

.card-value {
  font-size: 24px;
  font-weight: 700;
  color: #2D3748;
  margin-bottom: 4px;
}

.card-trend {
  font-size: 12px;
  font-weight: 600;
}

.card-trend.positive {
  color: #38A169;
}

.card-trend.negative {
  color: #E53E3E;
}

.card-trend.neutral {
  color: #718096;
}

/* 主要内容区域 */
.main-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}

/* 面板卡片 */
.panel-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
  margin-bottom: 24px;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.panel-header h3 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 18px;
  color: #2D3748;
  margin: 0;
}

.btn-secondary {
  background: #F7FAFC;
  color: #2C6FD1;
  border: 1px solid #2C6FD1;
  border-radius: 6px;
  padding: 8px 16px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-secondary:hover {
  background: #EBF4FF;
}

/* 数据源管理 */
.data-sources {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.source-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  background: #F7FAFC;
  transition: all 0.3s ease;
}

.source-item:hover {
  border-color: #2C6FD1;
  background: #EBF4FF;
}

.source-item.active {
  border-color: #2C6FD1;
  background: #EBF4FF;
}

.source-item.warning {
  border-color: #D69E2E;
  background: #FEFCBF;
}

.source-icon {
  width: 40px;
  height: 40px;
  background: #E2E8F0;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #718096;
}

.source-item.active .source-icon {
  background: #2C6FD1;
  color: white;
}

.source-info h4 {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin: 0 0 4px 0;
}

.source-info p {
  font-size: 14px;
  color: #718096;
  margin: 0 0 8px 0;
}

.source-stats {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  color: #718096;
}

.status-badge {
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 600;
}

.status-badge.success {
  background: #C6F6D5;
  color: #22543D;
}

.status-badge.warning {
  background: #FEFCBF;
  color: #744210;
}

/* 采集规则 */
.rules-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.rule-item {
  padding: 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  background: #F7FAFC;
  transition: all 0.3s ease;
}

.rule-item:hover {
  border-color: #2C6FD1;
  background: #EBF4FF;
}

.rule-item.active {
  border-color: #2C6FD1;
  background: #EBF4FF;
}

.rule-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.rule-header h4 {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
  margin: 0;
}

.rule-status {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
  background: #E2E8F0;
  color: #718096;
}

.rule-status.success {
  background: #C6F6D5;
  color: #22543D;
}

.rule-desc {
  font-size: 14px;
  color: #718096;
  margin: 0 0 12px 0;
}

.rule-metrics {
  display: flex;
  gap: 24px;
}

.metric {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.metric-label {
  font-size: 12px;
  color: #718096;
}

.metric-value {
  font-size: 16px;
  font-weight: 600;
  color: #2D3748;
}

/* 实时数据流 */
.time-display {
  font-size: 14px;
  color: #718096;
  font-weight: 500;
}

.realtime-stream {
  max-height: 400px;
  overflow-y: auto;
}

.stream-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-bottom: 1px solid #E2E8F0;
}

.stream-item:last-child {
  border-bottom: none;
}

.stream-icon {
  width: 32px;
  height: 32px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.stream-icon.pageview {
  background: #2C6FD1;
}

.stream-icon.click {
  background: #38A169;
}

.stream-icon.search {
  background: #FF6B35;
}

.stream-icon.form {
  background: #805AD5;
}

.stream-icon.social {
  background: #D69E2E;
}

.stream-content {
  flex: 1;
}

.stream-title {
  font-size: 14px;
  font-weight: 600;
  color: #2D3748;
  margin-bottom: 2px;
}

.stream-desc {
  font-size: 12px;
  color: #718096;
}

.stream-time {
  font-size: 12px;
  color: #A0AEC0;
}

/* 热力图 */
.heatmap-controls {
  display: flex;
  gap: 8px;
}

.btn-sm {
  padding: 4px 12px;
  border: 1px solid #E2E8F0;
  background: #F7FAFC;
  color: #718096;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-sm.active,
.btn-sm:hover {
  background: #2C6FD1;
  color: white;
  border-color: #2C6FD1;
}

.heatmap-container {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.heatmap-grid {
  display: grid;
  grid-template-columns: repeat(24, 1fr);
  gap: 2px;
  height: 120px;
}

.heatmap-cell {
  background: #2C6FD1;
  border-radius: 2px;
  transition: opacity 0.3s ease;
}

.heatmap-legend {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: #718096;
}

.legend-gradient {
  flex: 1;
  height: 8px;
  background: linear-gradient(to right, #E2E8F0, #2C6FD1);
  border-radius: 4px;
}

/* 数据质量监控 */
.quality-score {
  font-size: 18px;
  font-weight: 700;
  color: #38A169;
}

.quality-metrics {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.quality-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.quality-label {
  width: 100px;
  font-size: 14px;
  color: #718096;
}

.quality-bar {
  flex: 1;
  height: 8px;
  background: #E2E8F0;
  border-radius: 4px;
  overflow: hidden;
}

.quality-fill {
  height: 100%;
  background: #38A169;
  border-radius: 4px;
  transition: width 0.3s ease;
}

.quality-value {
  width: 40px;
  font-size: 14px;
  font-weight: 600;
  color: #2D3748;
  text-align: right;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .overview-cards {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .main-content {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .overview-cards {
    grid-template-columns: 1fr;
  }
  
  .page-header {
    flex-direction: column;
    gap: 16px;
    align-items: flex-start;
  }
  
  .heatmap-grid {
    grid-template-columns: repeat(12, 1fr);
  }
}

/* 弹窗样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 24px 0 24px;
  border-bottom: 1px solid #E2E8F0;
  padding-bottom: 16px;
}

.modal-header h3 {
  font-family: 'Source Han Sans CN', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-weight: 600;
  font-size: 18px;
  color: #2D3748;
  margin: 0;
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  color: #718096;
  transition: all 0.3s ease;
}

.modal-close:hover {
  background: #F7FAFC;
  color: #2D3748;
}

.modal-body {
  padding: 24px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  font-size: 14px;
  font-weight: 600;
  color: #2D3748;
  margin-bottom: 8px;
}

.form-input,
.form-select,
.form-textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
  transition: all 0.3s ease;
  box-sizing: border-box;
}

.form-input:focus,
.form-select:focus,
.form-textarea:focus {
  outline: none;
  border-color: #2C6FD1;
  box-shadow: 0 0 0 3px rgba(44, 111, 209, 0.1);
}

.form-textarea {
  resize: vertical;
  min-height: 80px;
}

.trigger-options,
.field-options {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

.checkbox-item {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-size: 14px;
  color: #4A5568;
}

.checkbox-item input[type="checkbox"] {
  width: 16px;
  height: 16px;
  accent-color: #2C6FD1;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 0 24px 24px 24px;
  border-top: 1px solid #E2E8F0;
  padding-top: 16px;
}

.btn-cancel {
  background: #F7FAFC;
  color: #4A5568;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-cancel:hover {
  background: #EDF2F7;
}

.btn-confirm {
  background: #2C6FD1;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-confirm:hover {
  background: #1E5AB9;
}

@media (max-width: 768px) {
  .modal-content {
    width: 95%;
    margin: 20px;
  }
  
     .trigger-options,
   .field-options {
    grid-template-columns: 1fr;
   }
 }

/* 自定义提示弹窗样式 */
.alert-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 3000;
}

.alert-modal-content {
  background: white;
  border-radius: 12px;
  padding: 32px;
  max-width: 400px;
  width: 90%;
  text-align: center;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  animation: alertSlideIn 0.3s ease-out;
}

@keyframes alertSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

.alert-icon {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
  color: white;
}

.alert-icon.success {
  background: #38A169;
}

.alert-icon.error {
  background: #E53E3E;
}

.alert-icon.warning {
  background: #D69E2E;
}

.alert-message {
  font-size: 16px;
  color: #2D3748;
  margin-bottom: 24px;
  line-height: 1.5;
  font-weight: 500;
}

.alert-close-btn {
  background: #2C6FD1;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 10px 24px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  min-width: 80px;
}

.alert-close-btn:hover {
  background: #1E5AB9;
}

@media (max-width: 768px) {
  .alert-modal-content {
    margin: 20px;
    padding: 24px;
  }
}
</style>
