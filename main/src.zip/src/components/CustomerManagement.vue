<template>
  <div class="customer-management-container">
    <!-- 页面标题和工具栏 -->
    <div class="page-header">
      <div class="header-left">
      <h1>客户管理</h1>
        <p>管理客户信息、标签和关系，基于数据分析精准服务</p>
      </div>
      <div class="header-controls">
        <button class="import-btn" @click="showImportModal = true">
          <span class="btn-icon">📥</span>
          导入客户
        </button>
        <button class="export-btn" @click="exportCustomers">
          <span class="btn-icon">📤</span>
          导出数据
        </button>
      </div>
    </div>

    <!-- 筛选控制区 -->
    <div class="filter-toolbar">
      <div class="search-section">
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="搜索客户姓名、邮箱或电话"
          class="search-input"
        />
        </div>
      <div class="filter-section">
        <select v-model="levelFilter" class="filter-select">
          <option value="all">全部等级</option>
          <option value="vip">VIP客户</option>
          <option value="premium">高级客户</option>
          <option value="regular">普通客户</option>
        </select>
        <select v-model="statusFilter" class="filter-select">
          <option value="all">全部状态</option>
          <option value="active">活跃</option>
          <option value="inactive">不活跃</option>
          <option value="new">新客户</option>
        </select>
        <select v-model="tagFilter" class="filter-select">
          <option value="all">全部标签</option>
          <option value="high_value">高价值</option>
          <option value="potential">潜在客户</option>
          <option value="risk">流失风险</option>
        </select>
        </div>
      <button class="add-btn" @click="showAddCustomerModal = true">
        <span class="btn-icon">+</span>
        新增客户
      </button>
      </div>

    <!-- 客户看板 -->
    <div class="dashboard-section">
      <div class="status-cards">
        <div class="status-card total">
          <div class="status-icon">👥</div>
          <div class="status-info">
            <div class="status-count">{{ overviewData.totalCustomers }}</div>
            <div class="status-label">总客户数</div>
        </div>
        </div>
        <div class="status-card active">
          <div class="status-icon">✅</div>
          <div class="status-info">
            <div class="status-count">{{ overviewData.activeCustomers }}</div>
            <div class="status-label">活跃客户</div>
      </div>
        </div>
        <div class="status-card vip">
          <div class="status-icon">⭐</div>
          <div class="status-info">
            <div class="status-count">{{ overviewData.vipCustomers }}</div>
            <div class="status-label">VIP客户</div>
          </div>
        </div>
        <div class="status-card new">
          <div class="status-icon">🆕</div>
          <div class="status-info">
            <div class="status-count">{{ overviewData.newCustomers }}</div>
            <div class="status-label">新增客户</div>
          </div>
        </div>
      </div>

      <div class="metrics-cards">
        <div class="metric-card">
          <div class="metric-header">
            <span class="metric-label">客户满意度</span>
            <span class="metric-trend positive">↑2.1%</span>
        </div>
          <div class="metric-value">{{ overviewData.satisfaction }}%</div>
        </div>
        <div class="metric-card">
          <div class="metric-header">
            <span class="metric-label">平均消费</span>
            <span class="metric-trend positive">↑8.5%</span>
      </div>
          <div class="metric-value">¥{{ formatNumber(overviewData.avgSpending) }}</div>
    </div>
        <div class="metric-card">
          <div class="metric-header">
            <span class="metric-label">客户留存率</span>
            <span class="metric-trend positive">↑1.2%</span>
      </div>
          <div class="metric-value">{{ overviewData.retentionRate }}%</div>
        </div>
      </div>
    </div>

    <!-- 客户列表 -->
    <div class="customer-list-section">
      <div class="list-header">
        <div class="list-title-section">
          <label class="select-all-wrapper">
            <input 
              type="checkbox" 
              :checked="isAllSelected" 
              @change="toggleAllCustomers"
              class="select-all-checkbox"
            />
            <span class="custom-checkbox"></span>
          </label>
          <h2>客户列表</h2>
          <span v-if="selectedCustomers.length > 0" class="selected-count">
            已选择 {{ selectedCustomers.length }} 个客户
          </span>
        </div>
        <div class="list-actions">
          <button class="batch-btn" @click="toggleBatchActions" :class="{ active: showBatchActions }">
            <span class="btn-icon">📋</span>
            批量操作
          </button>
        </div>
      </div>
      
      <!-- 批量操作面板 -->
      <div v-if="showBatchActions && selectedCustomers.length > 0" class="batch-actions-panel">
        <div class="batch-actions-content">
          <button class="batch-action-btn delete" @click="showBatchDeleteConfirm = true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3,6 5,6 21,6"/>
              <path d="M19,6v14a2,2 0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2v2"/>
            </svg>
            删除选中
          </button>
          <button class="batch-action-btn level" @click="showBatchLevelModal = true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
            </svg>
            修改等级
          </button>
          <button class="batch-action-btn activate" @click="batchActivateCustomers">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="9,11 12,14 22,4"/>
              <path d="M21,12v7a2,2,0,0,1-2,2H5a2,2,0,0,1-2-2V5a2,2,0,0,1,2-2h11"/>
            </svg>
            批量激活
          </button>
          <button class="batch-action-btn deactivate" @click="batchDeactivateCustomers">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"/>
              <line x1="15" y1="9" x2="9" y2="15"/>
              <line x1="9" y1="9" x2="15" y2="15"/>
            </svg>
            批量停用
          </button>
        </div>
        <button class="batch-cancel-btn" @click="clearSelection">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
          取消选择
        </button>
      </div>
      
      <div class="customer-grid">
        <div 
          v-for="customer in filteredCustomers" 
          :key="customer.id"
          class="customer-card"
          :class="{ selected: selectedCustomers.includes(customer.id) }"
          @click="showCustomerDetail(customer)"
        >
          <div class="card-header">
            <div class="card-select-section">
              <label class="customer-select-wrapper" @click.stop>
                <input 
                  type="checkbox" 
                  :value="customer.id"
                  v-model="selectedCustomers"
                  class="customer-checkbox"
                />
                <span class="custom-checkbox small"></span>
              </label>
              <div class="customer-avatar" :class="getCustomerAvatarClass(customer)">
                <svg width="50" height="50" viewBox="0 0 100 100" class="avatar-svg">
                  <circle cx="50" cy="50" r="50" :fill="getAvatarBackground(customer)"/>
                  <circle cx="50" cy="35" r="15" fill="white" opacity="0.9"/>
                  <path d="M25 75 C25 65, 35 55, 50 55 C65 55, 75 65, 75 75 Z" fill="white" opacity="0.9"/>
                </svg>
              </div>
            </div>
            <div class="customer-level" :class="customer.level">
              {{ customer.levelText }}
            </div>
          </div>
          
          <div class="card-content">
            <h3 class="customer-name">{{ customer.name }}</h3>
            <p class="customer-id">ID: {{ customer.id }}</p>
            
            <div class="customer-meta">
              <span class="meta-item">
                <span class="meta-icon">📧</span>
                {{ customer.email }}
              </span>
              <span class="meta-item">
                <span class="meta-icon">📱</span>
                {{ customer.phone }}
              </span>
              <span class="meta-item">
                <span class="meta-icon">📍</span>
                {{ customer.location }}
              </span>
                </div>
            
                <div class="customer-tags">
              <span 
                v-for="tag in customer.tags" 
                :key="tag" 
                class="tag"
                :class="getTagClass(tag)"
              >
                {{ tag }}
              </span>
                </div>
            
            <div class="customer-stats">
              <div class="stat-item">
                <span class="stat-label">最近活动</span>
                <span class="stat-value">{{ customer.lastActivity }}</span>
                </div>
              <div class="stat-item">
                <span class="stat-label">消费金额</span>
                <span class="stat-value">¥{{ formatNumber(customer.totalSpending) }}</span>
                </div>
      </div>
    </div>

          <div class="card-actions">
            <button class="action-btn" @click.stop="viewDetail(customer)">
              查看详情
            </button>
            <button class="action-btn secondary" @click.stop="editCustomer(customer)">
              编辑
            </button>
            <button 
              :class="['action-btn', customer.status === 'active' ? 'success' : 'warning']"
              @click.stop="toggleStatus(customer)"
            >
              {{ customer.status === 'active' ? '活跃' : '不活跃' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 新增客户模态框 -->
    <div v-if="showAddCustomerModal" class="modal-overlay" @click="showAddCustomerModal = false">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>新增客户</h3>
          <button class="close-btn" @click="showAddCustomerModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>客户姓名</label>
            <input v-model="newCustomer.name" type="text" placeholder="输入客户姓名" />
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>邮箱</label>
              <input v-model="newCustomer.email" type="email" placeholder="输入邮箱地址" />
            </div>
            <div class="form-group">
              <label>电话</label>
              <input v-model="newCustomer.phone" type="tel" placeholder="输入电话号码" />
            </div>
          </div>
          <div class="form-group">
            <label>客户等级</label>
            <select v-model="newCustomer.level">
              <option value="regular">普通客户</option>
              <option value="premium">高级客户</option>
              <option value="vip">VIP客户</option>
            </select>
          </div>
          <div class="form-group">
            <label>标签</label>
            <div class="tag-selector">
              <label class="tag-option">
                <input type="checkbox" v-model="newCustomer.tags" value="高价值" />
                <span>高价值</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="newCustomer.tags" value="潜在客户" />
                <span>潜在客户</span>
              </label>
              <label class="tag-option">
                <input type="checkbox" v-model="newCustomer.tags" value="忠实客户" />
                <span>忠实客户</span>
              </label>
            </div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="cancel-btn" @click="showAddCustomerModal = false">取消</button>
          <button class="confirm-btn" @click="addCustomer">确认添加</button>
        </div>
      </div>
    </div>

         <!-- 导入客户模态框 -->
     <div v-if="showImportModal" class="modal-overlay" @click="showImportModal = false">
       <div class="modal-content" @click.stop>
         <div class="modal-header">
           <h3>导入客户数据</h3>
           <button class="close-btn" @click="showImportModal = false">×</button>
         </div>
         <div class="modal-body">
           <div class="upload-area">
             <div class="upload-icon">📁</div>
             <p>拖拽文件到此处或点击选择文件</p>
             <input type="file" accept=".csv,.xlsx" @change="handleFileUpload" />
           </div>
           <div class="import-tips">
             <h4>导入说明：</h4>
             <ul>
               <li>支持 CSV 和 Excel 格式</li>
               <li>文件大小不超过 10MB</li>
               <li>请确保数据格式正确</li>
             </ul>
           </div>
         </div>
         <div class="modal-actions">
           <button class="cancel-btn" @click="showImportModal = false">取消</button>
           <button class="confirm-btn" @click="importCustomers">开始导入</button>
         </div>
       </div>
     </div>

     <!-- 客户详情模态框 -->
     <div v-if="showCustomerDetailModal && selectedCustomer" class="modal-overlay" @click="showCustomerDetailModal = false">
       <div class="modal-content customer-detail-modal" @click.stop>
         <div class="modal-header">
           <h3>客户详情</h3>
           <button class="close-btn" @click="showCustomerDetailModal = false">×</button>
         </div>
         <div class="modal-body">
           <div class="customer-detail">
             <div class="detail-header">
               <div class="detail-avatar" :class="getCustomerAvatarClass(selectedCustomer)">
                 <svg width="60" height="60" viewBox="0 0 100 100" class="avatar-svg">
                   <circle cx="50" cy="50" r="50" :fill="getAvatarBackground(selectedCustomer)"/>
                   <circle cx="50" cy="35" r="15" fill="white" opacity="0.9"/>
                   <path d="M25 75 C25 65, 35 55, 50 55 C65 55, 75 65, 75 75 Z" fill="white" opacity="0.9"/>
                 </svg>
               </div>
               <div class="detail-info">
                 <h4>{{ selectedCustomer.name }}</h4>
                 <p class="customer-id">ID: {{ selectedCustomer.id }}</p>
                 <span class="customer-level" :class="selectedCustomer.level">
                   {{ selectedCustomer.levelText }}
                 </span>
               </div>
             </div>
             
             <div class="detail-section">
               <h5>基本信息</h5>
               <div class="detail-grid">
                 <div class="detail-item">
                   <span class="detail-label">邮箱</span>
                   <span class="detail-value">{{ selectedCustomer.email }}</span>
                 </div>
                 <div class="detail-item">
                   <span class="detail-label">电话</span>
                   <span class="detail-value">{{ selectedCustomer.phone }}</span>
                 </div>
                 <div class="detail-item">
                   <span class="detail-label">地区</span>
                   <span class="detail-value">{{ selectedCustomer.location }}</span>
                 </div>
                 <div class="detail-item">
                   <span class="detail-label">状态</span>
                   <span class="detail-value" :class="selectedCustomer.status">
                     {{ selectedCustomer.status === 'active' ? '活跃' : '不活跃' }}
                   </span>
                 </div>
               </div>
             </div>
             
             <div class="detail-section">
               <h5>标签</h5>
               <div class="detail-tags">
                 <span 
                   v-for="tag in selectedCustomer.tags" 
                   :key="tag" 
                   class="tag"
                   :class="getTagClass(tag)"
                 >
                   {{ tag }}
                 </span>
               </div>
             </div>
             
             <div class="detail-section">
               <h5>活动统计</h5>
               <div class="detail-stats">
                 <div class="stat-card">
                   <span class="stat-label">最近活动</span>
                   <span class="stat-value">{{ selectedCustomer.lastActivity }}</span>
                 </div>
                 <div class="stat-card">
                   <span class="stat-label">消费金额</span>
                   <span class="stat-value">¥{{ formatNumber(selectedCustomer.totalSpending) }}</span>
                 </div>
               </div>
             </div>
           </div>
         </div>
         <div class="modal-actions">
           <button class="cancel-btn" @click="showCustomerDetailModal = false">关闭</button>
           <button class="confirm-btn" @click="editCustomer(selectedCustomer)">编辑客户</button>
         </div>
       </div>
     </div>

     <!-- 编辑客户模态框 -->
     <div v-if="showEditCustomerModal" class="modal-overlay" @click="showEditCustomerModal = false">
       <div class="modal-content" @click.stop>
         <div class="modal-header">
           <h3>编辑客户</h3>
           <button class="close-btn" @click="showEditCustomerModal = false">×</button>
         </div>
         <div class="modal-body">
           <div class="form-group">
             <label>客户姓名</label>
             <input v-model="editCustomerData.name" type="text" placeholder="输入客户姓名" />
           </div>
           <div class="form-row">
             <div class="form-group">
               <label>邮箱</label>
               <input v-model="editCustomerData.email" type="email" placeholder="输入邮箱地址" />
             </div>
             <div class="form-group">
               <label>电话</label>
               <input v-model="editCustomerData.phone" type="tel" placeholder="输入电话号码" />
             </div>
           </div>
           <div class="form-group">
             <label>客户等级</label>
             <select v-model="editCustomerData.level">
               <option value="regular">普通客户</option>
               <option value="premium">高级客户</option>
               <option value="vip">VIP客户</option>
             </select>
           </div>
           <div class="form-group">
             <label>标签</label>
             <div class="tag-selector">
               <label class="tag-option">
                 <input type="checkbox" v-model="editCustomerData.tags" value="高价值" />
                 <span>高价值</span>
               </label>
               <label class="tag-option">
                 <input type="checkbox" v-model="editCustomerData.tags" value="潜在客户" />
                 <span>潜在客户</span>
               </label>
               <label class="tag-option">
                 <input type="checkbox" v-model="editCustomerData.tags" value="忠实客户" />
                 <span>忠实客户</span>
               </label>
               <label class="tag-option">
                 <input type="checkbox" v-model="editCustomerData.tags" value="流失风险" />
                 <span>流失风险</span>
               </label>
               <label class="tag-option">
                 <input type="checkbox" v-model="editCustomerData.tags" value="新客户" />
                 <span>新客户</span>
               </label>
             </div>
           </div>
         </div>
         <div class="modal-actions">
           <button class="cancel-btn" @click="showEditCustomerModal = false">取消</button>
           <button class="confirm-btn" @click="saveEditCustomer">保存修改</button>
         </div>
       </div>
    </div>

    <!-- 批量删除确认对话框 -->
    <div v-if="showBatchDeleteConfirm" class="modal-overlay" @click="showBatchDeleteConfirm = false">
      <div class="modal-content confirm-modal" @click.stop>
        <div class="modal-header">
          <h3>批量删除确认</h3>
          <button class="close-btn" @click="showBatchDeleteConfirm = false">×</button>
        </div>
        <div class="modal-body">
          <div class="confirm-content">
            <div class="confirm-icon warning">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                <line x1="12" y1="9" x2="12" y2="13"/>
                <line x1="12" y1="17" x2="12.01" y2="17"/>
              </svg>
            </div>
            <div class="confirm-message">
              <p>您确定要删除选中的 <strong>{{ selectedCustomers.length }}</strong> 个客户吗？</p>
              <p class="confirm-warning">此操作不可撤销，请谨慎操作。</p>
            </div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="cancel-btn" @click="showBatchDeleteConfirm = false">取消</button>
          <button class="confirm-btn danger" @click="confirmBatchDelete">确认删除</button>
        </div>
      </div>
    </div>

    <!-- 批量修改等级对话框 -->
    <div v-if="showBatchLevelModal" class="modal-overlay" @click="showBatchLevelModal = false">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>批量修改客户等级</h3>
          <button class="close-btn" @click="showBatchLevelModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>选择新的客户等级</label>
            <select v-model="batchTargetLevel" class="level-select">
              <option value="regular">普通客户</option>
              <option value="premium">高级客户</option>
              <option value="vip">VIP客户</option>
            </select>
          </div>
          <div class="batch-preview">
            <p>将为以下 <strong>{{ selectedCustomers.length }}</strong> 个客户修改等级：</p>
            <div class="preview-list">
              <span 
                v-for="customerId in selectedCustomers.slice(0, 5)" 
                :key="customerId"
                class="preview-customer"
              >
                {{ getCustomerById(customerId)?.name }}
              </span>
              <span v-if="selectedCustomers.length > 5" class="preview-more">
                ... 还有 {{ selectedCustomers.length - 5 }} 个
              </span>
            </div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="cancel-btn" @click="showBatchLevelModal = false">取消</button>
          <button class="confirm-btn" @click="confirmBatchLevelChange">确认修改</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'

// 页面状态
const searchQuery = ref('')
const levelFilter = ref('all')
const statusFilter = ref('all')
const tagFilter = ref('all')
const showAddCustomerModal = ref(false)
const showImportModal = ref(false)
const showCustomerDetailModal = ref(false)
const showEditCustomerModal = ref(false)
const selectedCustomer = ref(null)

// 批量操作相关状态
const selectedCustomers = ref([])
const showBatchActions = ref(false)
const showBatchDeleteConfirm = ref(false)
const showBatchLevelModal = ref(false)
const batchTargetLevel = ref('regular')

// 概览数据
const overviewData = reactive({
  totalCustomers: 12847,
  activeCustomers: 8392,
  vipCustomers: 1247,
  newCustomers: 847,
  satisfaction: 92.5,
  avgSpending: 1250,
  retentionRate: 85.3
})

// 客户数据
const customers = reactive([
  {
    id: 'C001',
    name: '张三',
    email: 'zhangsan@example.com',
    phone: '138****1234',
    location: '北京',
    level: 'vip',
    levelText: 'VIP',
    tags: ['高价值', '忠实客户'],
    lastActivity: '购买商品',
    totalSpending: 8500,
    status: 'active'
  },
  {
    id: 'C002',
    name: '李四',
    email: 'lisi@example.com',
    phone: '139****5678',
    location: '上海',
    level: 'regular',
    levelText: '普通',
    tags: ['潜在客户'],
    lastActivity: '浏览商品',
    totalSpending: 1200,
    status: 'active'
  },
  {
    id: 'C003',
    name: '王五',
    email: 'wangwu@example.com',
    phone: '137****9012',
    location: '广州',
    level: 'premium',
    levelText: '高级',
    tags: ['高价值', '新客户'],
    lastActivity: '注册账号',
    totalSpending: 3200,
    status: 'active'
  },
  {
    id: 'C004',
    name: '赵六',
    email: 'zhaoliu@example.com',
    phone: '136****3456',
    location: '深圳',
    level: 'regular',
    levelText: '普通',
    tags: ['流失风险'],
    lastActivity: '登录系统',
    totalSpending: 800,
    status: 'inactive'
  },
  {
    id: 'C005',
    name: '钱七',
    email: 'qianqi@example.com',
    phone: '135****7890',
    location: '杭州',
    level: 'vip',
    levelText: 'VIP',
    tags: ['高价值', '忠实客户'],
    lastActivity: '购买商品',
    totalSpending: 15600,
    status: 'active'
  },
  {
    id: 'C006',
    name: '孙八',
    email: 'sunba@example.com',
    phone: '134****2345',
    location: '成都',
    level: 'premium',
    levelText: '高级',
    tags: ['潜在客户'],
    lastActivity: '咨询客服',
    totalSpending: 2800,
    status: 'active'
  }
])

// 新增客户数据
const newCustomer = reactive({
  name: '',
  email: '',
  phone: '',
  level: 'regular',
  tags: []
})

// 编辑客户数据
const editCustomerData = reactive({
  name: '',
  email: '',
  phone: '',
  level: 'regular',
  tags: []
})

// 计算属性
const filteredCustomers = computed(() => {
  return customers.filter(customer => {
    const matchesSearch = customer.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                         customer.email.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                         customer.phone.includes(searchQuery.value)
    const matchesLevel = levelFilter.value === 'all' || customer.level === levelFilter.value
    const matchesStatus = statusFilter.value === 'all' || customer.status === statusFilter.value
    const matchesTag = tagFilter.value === 'all' || customer.tags.some(tag => {
      const tagMap = {
        high_value: '高价值',
        potential: '潜在客户',
        risk: '流失风险'
      }
      return tag === tagMap[tagFilter.value]
    })
    return matchesSearch && matchesLevel && matchesStatus && matchesTag
  })
})

const isAllSelected = computed(() => {
  const visibleIds = filteredCustomers.value.map(c => c.id)
  return visibleIds.length > 0 && visibleIds.every(id => selectedCustomers.value.includes(id))
})

// 方法
const formatNumber = (num) => {
  return num.toLocaleString()
}

const getTagClass = (tag) => {
  const classMap = {
    '高价值': 'high-value',
    '潜在客户': 'potential',
    '流失风险': 'risk',
    '忠实客户': 'loyal',
    '新客户': 'new'
  }
  return classMap[tag] || 'default'
}

// SVG头像相关方法
const getCustomerAvatarClass = (customer) => {
  if (!customer) return 'avatar-default'
  
  const classes = ['customer-avatar-svg']
  
  // 根据客户等级添加类
  classes.push(`avatar-${customer.level}`)
  
  // 根据状态添加类
  if (customer.status === 'inactive') {
    classes.push('avatar-inactive')
  }
  
  return classes.join(' ')
}

const getAvatarBackground = (customer) => {
  if (!customer) return '#E5E7EB'
  
  // 根据客户等级生成不同的背景色
  const levelColors = {
    vip: '#F59E0B',      // 金色
    premium: '#4F46E5',   // 紫色
    regular: '#10B981'    // 绿色
  }
  
  // 如果客户不活跃，使用灰色
  if (customer.status === 'inactive') {
    return '#9CA3AF'
  }
  
  return levelColors[customer.level] || '#E5E7EB'
}

const showCustomerDetail = (customer) => {
  console.log('查看客户详情:', customer)
}

const viewDetail = (customer) => {
  console.log('查看详情:', customer)
  // 显示客户详情模态框
  showCustomerDetailModal.value = true
  selectedCustomer.value = customer
}

const editCustomer = (customer) => {
  console.log('编辑客户:', customer)
  // 填充编辑表单
  Object.assign(editCustomerData, {
    name: customer.name,
    email: customer.email,
    phone: customer.phone,
    level: customer.level,
    tags: [...customer.tags]
  })
  selectedCustomer.value = customer
  showEditCustomerModal.value = true
}

const toggleStatus = (customer) => {
  customer.status = customer.status === 'active' ? 'inactive' : 'active'
  console.log('切换客户状态:', customer)
}

// 批量操作相关方法
const toggleBatchActions = () => {
  showBatchActions.value = !showBatchActions.value
  if (!showBatchActions.value) {
    clearSelection()
  }
}

const toggleAllCustomers = () => {
  const visibleIds = filteredCustomers.value.map(c => c.id)
  if (isAllSelected.value) {
    // 取消全选
    selectedCustomers.value = selectedCustomers.value.filter(id => !visibleIds.includes(id))
  } else {
    // 全选
    const newSelections = visibleIds.filter(id => !selectedCustomers.value.includes(id))
    selectedCustomers.value.push(...newSelections)
  }
}

const clearSelection = () => {
  selectedCustomers.value = []
  showBatchActions.value = false
}

const getCustomerById = (id) => {
  return customers.find(c => c.id === id)
}

const confirmBatchDelete = () => {
  // 删除选中的客户
  const selectedIds = [...selectedCustomers.value]
  selectedIds.forEach(id => {
    const index = customers.findIndex(c => c.id === id)
    if (index > -1) {
      customers.splice(index, 1)
    }
  })
  
  // 更新概览数据
  overviewData.totalCustomers -= selectedIds.length
  
  // 清理状态
  clearSelection()
  showBatchDeleteConfirm.value = false
  
  console.log(`成功删除 ${selectedIds.length} 个客户`)
}

const confirmBatchLevelChange = () => {
  const targetLevelText = batchTargetLevel.value === 'vip' ? 'VIP' : 
                         batchTargetLevel.value === 'premium' ? '高级' : '普通'
  
  // 更新选中客户的等级
  selectedCustomers.value.forEach(id => {
    const customer = customers.find(c => c.id === id)
    if (customer) {
      customer.level = batchTargetLevel.value
      customer.levelText = targetLevelText
    }
  })
  
  // 清理状态
  clearSelection()
  showBatchLevelModal.value = false
  
  console.log(`成功修改 ${selectedCustomers.value.length} 个客户等级为 ${targetLevelText}`)
}

const batchActivateCustomers = () => {
  let count = 0
  selectedCustomers.value.forEach(id => {
    const customer = customers.find(c => c.id === id)
    if (customer && customer.status !== 'active') {
      customer.status = 'active'
      count++
    }
  })
  
  // 更新概览数据
  overviewData.activeCustomers += count
  
  clearSelection()
  console.log(`成功激活 ${count} 个客户`)
}

const batchDeactivateCustomers = () => {
  let count = 0
  selectedCustomers.value.forEach(id => {
    const customer = customers.find(c => c.id === id)
    if (customer && customer.status !== 'inactive') {
      customer.status = 'inactive'
      count++
    }
  })
  
  // 更新概览数据
  overviewData.activeCustomers -= count
  
  clearSelection()
  console.log(`成功停用 ${count} 个客户`)
}

const batchOperation = () => {
  toggleBatchActions()
}

const exportCustomers = () => {
  console.log('导出客户数据')
}

const addCustomer = () => {
  if (newCustomer.name && newCustomer.email) {
    const customerData = {
      id: `C${String(customers.length + 1).padStart(3, '0')}`,
      name: newCustomer.name,
      email: newCustomer.email,
      phone: newCustomer.phone,
      location: '未知',
      level: newCustomer.level,
      levelText: newCustomer.level === 'vip' ? 'VIP' : 
                 newCustomer.level === 'premium' ? '高级' : '普通',
      tags: [...newCustomer.tags],
      lastActivity: '新增客户',
      totalSpending: 0,
      status: 'active'
    }
    customers.unshift(customerData)
    
    // 重置表单
    Object.assign(newCustomer, {
      name: '',
      email: '',
      phone: '',
      level: 'regular',
      tags: []
    })
    showAddCustomerModal.value = false
  }
}

const handleFileUpload = (event) => {
  const file = event.target.files[0]
  console.log('上传文件:', file)
}

const importCustomers = () => {
  console.log('导入客户数据')
  showImportModal.value = false
}

const saveEditCustomer = () => {
  if (selectedCustomer.value && editCustomerData.name && editCustomerData.email) {
    // 更新客户信息
    Object.assign(selectedCustomer.value, {
      name: editCustomerData.name,
      email: editCustomerData.email,
      phone: editCustomerData.phone,
      level: editCustomerData.level,
      levelText: editCustomerData.level === 'vip' ? 'VIP' : 
                 editCustomerData.level === 'premium' ? '高级' : '普通',
      tags: [...editCustomerData.tags]
    })
    
    // 重置表单
    Object.assign(editCustomerData, {
      name: '',
      email: '',
      phone: '',
      level: 'regular',
      tags: []
    })
    selectedCustomer.value = null
    showEditCustomerModal.value = false
  }
}
</script>

<style scoped>
.customer-management-container {
  padding: 24px;
  background: #F8FAFC;
  min-height: 100vh;
}

/* 页面标题和工具栏 */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}

.header-left {
  text-align: center;
  flex: 1;
}

.header-left h1 {
  font-size: 28px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.header-left p {
  color: #718096;
  margin: 0;
}

.header-controls {
  display: flex;
  gap: 16px;
  align-items: center;
}

.import-btn, .export-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.import-btn {
  background: #4F46E5;
  color: white;
}

.export-btn {
  background: #10B981;
  color: white;
}

.btn-icon {
  font-size: 16px;
}

/* 筛选控制区 */
.filter-toolbar {
  display: flex;
  gap: 24px;
  align-items: center;
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin-bottom: 24px;
}

.search-section {
  flex: 1;
  max-width: 300px;
}

.search-input {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
}

.search-input:focus {
  border-color: #4F46E5;
}

.filter-section {
  display: flex;
  gap: 12px;
}

.filter-select {
  padding: 12px 16px;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  background: white;
  font-size: 14px;
  color: #1A202C;
}

.add-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #10B981;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
}

.add-btn:hover {
  background: #059669;
}

/* 客户看板 */
.dashboard-section {
  margin-bottom: 32px;
}

.status-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 24px;
}

.status-card {
  display: flex;
  align-items: center;
  gap: 16px;
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.status-icon {
  font-size: 24px;
}

.status-info {
  flex: 1;
}

.status-count {
  font-size: 24px;
  font-weight: 700;
  color: #1A202C;
  margin-bottom: 4px;
}

.status-label {
  font-size: 14px;
  color: #718096;
}

.metrics-cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.metric-card {
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.metric-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.metric-label {
  font-size: 14px;
  color: #718096;
}

.metric-trend {
  font-size: 12px;
  font-weight: 500;
  padding: 4px 8px;
  border-radius: 6px;
}

.metric-trend.positive {
  background: #DEF7EC;
  color: #03543F;
}

.metric-value {
  font-size: 28px;
  font-weight: 700;
  color: #1A202C;
  margin-bottom: 4px;
}

/* 客户列表 */
.customer-list-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E2E8F0;
}

.list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.list-title-section {
  display: flex;
  align-items: center;
  gap: 16px;
}

.list-title-section h2 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.selected-count {
  font-size: 14px;
  color: #4F46E5;
  background: #EBF4FF;
  padding: 4px 12px;
  border-radius: 6px;
  font-weight: 500;
}

.select-all-wrapper {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.select-all-checkbox,
.customer-checkbox {
  position: absolute;
  opacity: 0;
  pointer-events: none;
}

.custom-checkbox {
  width: 20px;
  height: 20px;
  border: 2px solid #E2E8F0;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
  position: relative;
}

.custom-checkbox.small {
  width: 16px;
  height: 16px;
}

.select-all-checkbox:checked + .custom-checkbox,
.customer-checkbox:checked + .custom-checkbox {
  background: #4F46E5;
  border-color: #4F46E5;
}

.select-all-checkbox:checked + .custom-checkbox::after,
.customer-checkbox:checked + .custom-checkbox::after {
  content: '';
  position: absolute;
  width: 6px;
  height: 10px;
  border: solid white;
  border-width: 0 2px 2px 0;
  transform: rotate(45deg);
  top: 1px;
}

.custom-checkbox.small::after {
  width: 4px;
  height: 8px;
  top: 0px;
}

.batch-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #4F46E5;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
}

.batch-btn.active {
  background: #4338CA;
  box-shadow: 0 2px 8px rgba(79, 70, 229, 0.3);
}

.batch-btn:hover {
  background: #4338CA;
}

/* 批量操作面板 */
.batch-actions-panel {
  background: #F7FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  animation: slideDown 0.3s ease;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.batch-actions-content {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.batch-action-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.batch-action-btn.delete {
  background: #FEE2E2;
  color: #DC2626;
}

.batch-action-btn.delete:hover {
  background: #FECACA;
}

.batch-action-btn.level {
  background: #FEF3C7;
  color: #D97706;
}

.batch-action-btn.level:hover {
  background: #FDE68A;
}

.batch-action-btn.activate {
  background: #DEF7EC;
  color: #059669;
}

.batch-action-btn.activate:hover {
  background: #BCF5E1;
}

.batch-action-btn.deactivate {
  background: #F3F4F6;
  color: #6B7280;
}

.batch-action-btn.deactivate:hover {
  background: #E5E7EB;
}

.batch-cancel-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  background: white;
  color: #6B7280;
  border: 1px solid #E2E8F0;
  padding: 8px 12px;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
}

.batch-cancel-btn:hover {
  background: #F9FAFB;
  border-color: #D1D5DB;
}

.customer-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 20px;
}

.customer-card {
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  padding: 20px;
  background: #F8FAFC;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}

.customer-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.customer-card.selected {
  border-color: #4F46E5;
  background: #EBF4FF;
  box-shadow: 0 2px 8px rgba(79, 70, 229, 0.2);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.card-select-section {
  display: flex;
  align-items: center;
  gap: 12px;
}

.customer-select-wrapper {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.customer-avatar {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid transparent;
  transition: all 0.2s ease;
}

.customer-avatar.customer-avatar-svg {
  border: 2px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.customer-avatar.avatar-vip {
  border-color: #FEF3C7;
  box-shadow: 0 2px 8px rgba(245, 158, 11, 0.3);
}

.customer-avatar.avatar-premium {
  border-color: #E0E7FF;
  box-shadow: 0 2px 8px rgba(79, 70, 229, 0.3);
}

.customer-avatar.avatar-regular {
  border-color: #DEF7EC;
  box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
}

.customer-avatar.avatar-inactive {
  border-color: #F3F4F6;
  box-shadow: 0 2px 8px rgba(156, 163, 175, 0.3);
  opacity: 0.7;
}

.avatar-svg {
  width: 100%;
  height: 100%;
  border-radius: 50%;
}

.customer-level {
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.customer-level.vip {
  background: #FEF3C7;
  color: #92400E;
}

.customer-level.premium {
  background: #DBEAFE;
  color: #1E40AF;
}

.customer-level.regular {
  background: #E5E7EB;
  color: #374151;
}

.customer-name {
  font-size: 18px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 4px 0;
}

.customer-id {
  font-size: 14px;
  color: #718096;
  margin: 0 0 16px 0;
}

.customer-meta {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #718096;
}

.meta-icon {
  font-size: 16px;
}

.customer-tags {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.tag {
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.tag.high-value {
  background: #DEF7EC;
  color: #03543F;
}

.tag.potential {
  background: #DBEAFE;
  color: #1E40AF;
}

.tag.risk {
  background: #FDE8E8;
  color: #9B1C1C;
}

.tag.loyal {
  background: #FEF3C7;
  color: #92400E;
}

.tag.new {
  background: #E0E7FF;
  color: #3730A3;
}

.tag.default {
  background: #E5E7EB;
  color: #374151;
}

.customer-stats {
  display: flex;
  gap: 20px;
  margin-bottom: 16px;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.stat-label {
  font-size: 12px;
  color: #718096;
  margin-bottom: 4px;
}

.stat-value {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

.card-actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  padding: 6px 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  background: white;
  color: #4A5568;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.action-btn:hover {
  background: #F7FAFC;
}

.action-btn.secondary {
  border-color: #4F46E5;
  color: #4F46E5;
}

.action-btn.warning {
  border-color: #DC2626;
  color: #DC2626;
}

.action-btn.success {
  border-color: #10B981;
  color: #10B981;
}

/* 模态框 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  border-bottom: 1px solid #E2E8F0;
}

.modal-header h3 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  color: #718096;
  cursor: pointer;
}

.modal-body {
  padding: 24px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  font-size: 14px;
  font-weight: 500;
  color: #4A5568;
  margin-bottom: 8px;
}

.form-group input,
.form-group select {
  width: 100%;
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.tag-selector {
  display: flex;
  gap: 16px;
}

.tag-option {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.modal-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  padding: 24px;
  border-top: 1px solid #E2E8F0;
}

.cancel-btn, .confirm-btn {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
}

.cancel-btn {
  background: #E2E8F0;
  color: #4A5568;
}

.confirm-btn {
  background: #4F46E5;
  color: white;
}

.confirm-btn.danger {
  background: #DC2626;
}

.confirm-btn.danger:hover {
  background: #B91C1C;
}

/* 确认对话框样式 */
.confirm-modal {
  max-width: 480px;
}

.confirm-content {
  display: flex;
  align-items: flex-start;
  gap: 16px;
  text-align: left;
}

.confirm-icon {
  flex-shrink: 0;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.confirm-icon.warning {
  background: #FEF3C7;
  color: #D97706;
}

.confirm-message {
  flex: 1;
}

.confirm-message p {
  margin: 0 0 8px 0;
  color: #1A202C;
  font-size: 16px;
}

.confirm-warning {
  color: #DC2626;
  font-size: 14px;
  font-weight: 500;
}

/* 批量预览样式 */
.batch-preview {
  background: #F7FAFC;
  border-radius: 8px;
  padding: 16px;
  margin-top: 16px;
}

.batch-preview p {
  margin: 0 0 12px 0;
  color: #4A5568;
  font-size: 14px;
}

.preview-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.preview-customer {
  background: #EBF4FF;
  color: #4F46E5;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
}

.preview-more {
  background: #E5E7EB;
  color: #6B7280;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
}

.level-select {
  width: 100%;
  padding: 12px;
  border: 1px solid #E2E8F0;
  border-radius: 6px;
  font-size: 14px;
  background: white;
}

.upload-area {
  border: 2px dashed #E2E8F0;
  border-radius: 8px;
  padding: 40px;
  text-align: center;
  margin-bottom: 20px;
}

.upload-icon {
  font-size: 48px;
  margin-bottom: 16px;
}

.upload-area p {
  color: #718096;
  margin: 0;
}

.upload-area input[type="file"] {
  display: none;
}

.import-tips {
  background: #F7FAFC;
  border-radius: 8px;
  padding: 16px;
}

.import-tips h4 {
  font-size: 14px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 8px 0;
}

.import-tips ul {
  margin: 0;
  padding-left: 20px;
  color: #718096;
  font-size: 14px;
}

.import-tips li {
  margin-bottom: 4px;
}

/* 客户详情模态框 */
.customer-detail-modal {
  max-width: 600px;
}

.customer-detail {
  padding: 0;
}

.detail-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid #E2E8F0;
}

.detail-avatar {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 3px solid transparent;
  transition: all 0.2s ease;
}

.detail-avatar.customer-avatar-svg {
  border: 3px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.detail-avatar.avatar-vip {
  border-color: #FEF3C7;
  box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
}

.detail-avatar.avatar-premium {
  border-color: #E0E7FF;
  box-shadow: 0 4px 12px rgba(79, 70, 229, 0.4);
}

.detail-avatar.avatar-regular {
  border-color: #DEF7EC;
  box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
}

.detail-avatar.avatar-inactive {
  border-color: #F3F4F6;
  box-shadow: 0 4px 12px rgba(156, 163, 175, 0.4);
  opacity: 0.7;
}

.detail-info h4 {
  font-size: 20px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 4px 0;
}

.detail-info .customer-id {
  font-size: 14px;
  color: #718096;
  margin: 0 0 8px 0;
}

.detail-section {
  margin-bottom: 24px;
}

.detail-section h5 {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
  margin: 0 0 12px 0;
}

.detail-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.detail-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.detail-label {
  font-size: 12px;
  color: #718096;
  font-weight: 500;
}

.detail-value {
  font-size: 14px;
  color: #1A202C;
  font-weight: 500;
}

.detail-value.active {
  color: #10B981;
}

.detail-value.inactive {
  color: #DC2626;
}

.detail-tags {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.detail-stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.detail-stats .stat-card {
  background: #F7FAFC;
  padding: 16px;
  border-radius: 8px;
  text-align: center;
}

.detail-stats .stat-label {
  font-size: 12px;
  color: #718096;
  margin-bottom: 4px;
  display: block;
}

.detail-stats .stat-value {
  font-size: 16px;
  font-weight: 600;
  color: #1A202C;
}

@media (max-width: 1024px) {
  .status-cards {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .metrics-cards {
    grid-template-columns: 1fr;
  }
  
  .customer-grid {
    grid-template-columns: 1fr;
  }
  
  .detail-grid {
    grid-template-columns: 1fr;
  }
  
  .detail-stats {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .header-controls {
    width: 100%;
    justify-content: center;
  }
  
  .filter-toolbar {
    flex-direction: column;
    gap: 16px;
  }
  
  .filter-section {
    width: 100%;
    justify-content: space-between;
  }
  
  .status-cards {
    grid-template-columns: 1fr;
  }
  
  .form-row {
    grid-template-columns: 1fr;
  }
  
  .tag-selector {
    flex-direction: column;
    gap: 8px;
  }
}
</style>
