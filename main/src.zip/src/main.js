import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import { createRouter, createWebHashHistory } from 'vue-router'
import Login from './components/Login.vue'
import Layout from './components/Layout.vue'
import Dashboard from './components/Dashboard.vue'
import DataCollection from './components/DataCollection.vue'
import UserProfile from './components/UserProfile.vue'
import Marketing from './components/Marketing.vue'
import DataAnalysis from './components/DataAnalysis.vue'
import CustomerManagement from './components/CustomerManagement.vue'
import ContentManagement from './components/ContentManagement.vue'
import Reports from './components/Reports.vue'
import Settings from './components/Settings.vue'

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: Login },
  { 
    path: '/dashboard', 
    component: Layout,
    children: [
      { path: '', component: Dashboard }
    ]
  },
  { 
    path: '/data-collection', 
    component: Layout,
    children: [
      { path: '', component: DataCollection }
    ]
  },
  { 
    path: '/user-profile', 
    component: Layout,
    children: [
      { path: '', component: UserProfile }
    ]
  },
  { 
    path: '/marketing', 
    component: Layout,
    children: [
      { path: '', component: Marketing }
    ]
  },
  { 
    path: '/data-analysis', 
    component: Layout,
    children: [
      { path: '', component: DataAnalysis }
    ]
  },
  { 
    path: '/customer-management', 
    component: Layout,
    children: [
      { path: '', component: CustomerManagement }
    ]
  },
  { 
    path: '/content-management', 
    component: Layout,
    children: [
      { path: '', component: ContentManagement }
    ]
  },
  { 
    path: '/reports', 
    component: Layout,
    children: [
      { path: '', component: Reports }
    ]
  },
  { 
    path: '/settings', 
    component: Layout,
    children: [
      { path: '', component: Settings }
    ]
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

const app = createApp(App)
app.use(router)
app.mount('#app')
